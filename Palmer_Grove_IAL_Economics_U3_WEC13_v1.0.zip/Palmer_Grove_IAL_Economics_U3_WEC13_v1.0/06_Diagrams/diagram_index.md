# Diagram index

| Diagram | Lesson | Reading |
|---|---|---|
| Short-run costs | L04 | MC cuts AVC and AC at their minima. |
| LRAC | L05 | Falls, then the minimum efficient scale, then diseconomies. |
| AR and MR | L03 | MR is steeper and hits zero first. |
| Monopoly | L06 and L10 | Output where MR = MC. Price from AR. |
| Perfect competition | L07 | Short-run profit, then long-run tangency at minimum AC. |
| Monopolistic competition | L08 | Short-run profit, then AR tangent to AC, with spare capacity. |
| Natural monopoly | L10 | LRAC still falling where it meets demand. |
| Labour market | L12 | Wage where demand meets supply. |
| Minimum wage | L13 | Employment read from demand at the floor. |
| Monopsony | L11 | Hire where MRP = MCL. Wage from the supply curve. |
