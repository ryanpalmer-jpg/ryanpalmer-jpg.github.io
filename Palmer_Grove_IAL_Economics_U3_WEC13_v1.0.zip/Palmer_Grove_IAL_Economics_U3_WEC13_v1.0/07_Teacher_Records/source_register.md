# Source register  ·  Unit 3

Access date: 12 October 2026.

| Document | Use |
|---|---|
| Pearson Edexcel IAL Economics specification, Issue 2, June 2018, Unit 3 | Every requirement in the coverage file. Paper: 2 hours, 80 marks. |
| WEC13/01 Summer 2025 mark scheme | Bicycle sales, contestability, firms remaining small, natural monopoly, protection of employees and suppliers. |
| WEC13/01 January 2025 mark scheme | 4-firm ratio 34.5%, organic growth, monopsony, competition policy, takeovers. |
| WEC13/01 October 2024 mark scheme | AstraZeneca total cost, dynamic efficiency, Lidl's organic growth, labour-market intervention, collusion. |
| WEC13/01 June 2025 examiner report | Internal economies, sales maximisation, derived demand, the cost-table method, contestability confused with competition, lists of points staying in Level 2. |

Pearson questions in the lessons are the questions printed in those mark schemes. They are not reproduced as whole papers. Hypothetical firms in the practice papers are invented.
