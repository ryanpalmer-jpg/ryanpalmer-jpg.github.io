# Limitations

- Not every WEC13 series was opened. The lessons use June 2025, January 2025, October 2024 and the June 2025 examiner report.
- Units 1 and 2 are separate packs. This paper can still draw on them, as the specification allows.
- Unit 4 is not in this zip.
- The 12/8 and 8/6 splits are the level pattern used in these mark schemes, not a formula printed on a future paper.
- Slide images used in checking are rasters, not a PowerPoint export.
