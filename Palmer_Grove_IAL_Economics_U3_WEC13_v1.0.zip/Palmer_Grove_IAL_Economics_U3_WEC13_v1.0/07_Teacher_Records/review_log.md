# Review log  ·  Unit 3 v1.0

Teaching: 13 lessons. Each explanation slide carries one idea in sentences. Past-paper questions come after the explanation.

Numbers rechecked in code: June 2025 bicycle change −8.33%; January 2025 concentration ratio 34.5%; October 2024 AstraZeneca cost change £3,756 million; Paper A concentration 70%, fixed cost £40 million, average cost £18; Paper B concentration 83% and a 15% fall in barista employment.

Visual: 301 slides rasterised from the PowerPoint coordinates, with no overflow warnings. Diagrams were then looked at. Monopoly reads price from AR and marks Q. Perfect competition shows a flat price, then long-run tangency at minimum AC. Monopolistic competition shows short-run profit and a long-run tangency to the left of minimum AC. Natural monopoly keeps falling LRAC where it meets demand. The labour market crosses once. The minimum wage is above that crossing, with employment on demand and a surplus out to supply. Monopsony hires where MRP meets MCL and reads the wage from supply. The long-run monopolistic tangency and the minimum-wage marker were corrected after that inspection. This was not Microsoft PowerPoint.

Answers are not in the pupil question file. Harbour Coffee is not in the lessons.
