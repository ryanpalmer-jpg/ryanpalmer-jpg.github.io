# Diagram index

All diagrams are native PowerPoint shapes inside the teacher decks. There is no separate generative image.

| ID | Lesson slide | What it must show |
|---|---|---|
| U1_D01 | U1_L02 PPF slides | Concave frontier, inside / on / outside, movement, outward shift, inward shift |
| U1_D02 | U1_L12 tax and subsidy | Parallel specific-tax shift, wedge, subsidy shift down |
| U1_D03 | U1_L13 | MSC above MPC; MSB above MPB; two optima; welfare loss described |
| U1_D04 | U1_L15 and U1_L10 | Maximum price below equilibrium with excess demand; minimum price with excess supply |
| U1_D05 | U1_L06 and U1_L09 | Demand shift right; supply shift right |
| U1_D06 | U1_L11 | Consumer surplus above price; producer surplus below price |

Hand-drawing tasks are in 05_Revision/U1_diagram_practice.pdf.
