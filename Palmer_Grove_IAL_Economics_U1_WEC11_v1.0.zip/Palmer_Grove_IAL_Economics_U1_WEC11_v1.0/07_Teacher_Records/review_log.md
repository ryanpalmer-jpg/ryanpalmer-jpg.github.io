# Review log  ·  Unit 1 v1.0

## Economics
Definitions were checked against Issue 2 wording: opportunity cost, the four externality types, public goods, moral hazard, government failure, specific and ad valorem taxes. The negative production externality curve was corrected so MSC lies above MPC. Tax and subsidy arithmetic was recalculated in code from the equations, not copied from the first draft.

## Assessment
Paper structure matches the specification: 6 + 20 + 34 + 20 = 80, Units 1 and 2 timing 1 hour 45 minutes. Command words match Appendix 6. 20-mark and 14-mark splits follow the January 2025 WEC11 descriptors that were read, and are described as a guide. No generated answer is presented as an examiner script.

## Teaching
Sixteen lessons follow the prerequisite order. Each has a diagnostic or a retrieval link, a worked piece, and an independent question whose answer is outside the pupil PDF. KAA and EV are labelled as a teaching structure.

## Language
British spelling (specialisation, labour, judgement). Short classroom sentences on slides. Examination wording on questions.

## Visual
Every slide was rasterised at 110 dpi with Liberation Sans from the PPTX coordinates. Title, PPF, externality, card and route slides were inspected. This was not Microsoft PowerPoint and not LibreOffice, because neither could be installed in the build environment. Native PowerPoint shapes are used for diagrams, so a teacher can move labels. The raster PDF is a viewing copy, not a second editable master.

## Numerical agreement
`checked_numbers()` asserts the lesson examples, both papers, the diagnostic PED and the topic-check XED.
