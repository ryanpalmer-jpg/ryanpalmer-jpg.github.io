# Limitations

- Units 2, 3 and 4 are not in this zip. Unit 1 is taught so that those units can assume it.
- Not every WEC11 series was opened. The assessment design uses the specification plus the January 2025 mark scheme and June 2024 examiner comments that were actually read.
- The sample assessment materials booklet was not downloaded as a separate file.
- Slide PDFs are rasterised. They are not a PowerPoint export. Fonts on a school computer will be Calibri if installed. The build machine substituted Liberation Sans for the visual check.
- On-click animation was not used. Diagrams are static and complete, which also works when the deck is printed.
- Model essays are illustrative. A pupil can earn the top level with a different valid route.
- Hypothetical data are labelled. No real official series was republished.
