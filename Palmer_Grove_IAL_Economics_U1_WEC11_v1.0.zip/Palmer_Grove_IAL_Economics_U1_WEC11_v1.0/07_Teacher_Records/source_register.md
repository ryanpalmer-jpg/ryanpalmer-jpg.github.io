# Source register

Access date for all Pearson files below: 12 October 2026.

| Document | Unit | Series | Code | Location | Used for | Limitation |
|---|---|---|---|---|---|---|
| IAL Economics specification, Issue 2, June 2018 | All | Specification | YEC11 / XEC11 / WEC11–14 | qualifications.pearson.com specification PDF, saved at ial_econ/sources/ial-econ-spec-2018.pdf | Content, command words, quantitative skills, paper structure | No later issue was identified on the live PDF. UK GCE specifications were not used. |
| WEC11/01 mark scheme January 2025 | 1 | January 2025 | WEC11_01_2501_MS | qualifications.pearson.com wec11-01-rms-20250116.pdf | Level splits: 20-mark 12 KAA / 8 EV; a 14-mark item’s 8/6 pattern; diagram and context caps | The whole paper was not re-keyed question by question. Indicative content was not copied into our questions. |
| WEC11/01 examiner report June 2024 | 1 | June 2024 | Principal Examiner Feedback | qualifications.pearson.com wec11-01-pef-20240815.pdf, search extracts | Recurring errors: maximum-price shortage omitted; diminishing marginal utility confused with falling total utility; circular definitions of non-rivalry | Full report not reproduced. |
| WEC11 mark schemes June 2024, January 2025, March 2025 (selected items) | 1 | 2024–2025 | WEC11 | Pearson exam-material PDFs cited in the build log | Confirm that Draw questions can be marked from the diagram alone, and that 4-mark explain items use a short chain | Not every series from 2019 to 2026 was opened. |
| Supplied Palmer Grove decks | 3 | Teacher materials | — | Palmer_Grove_IAL_Unit_3_Monopoly_and_Contestability_Lesson.pptx and Monopsony lesson | Visual system: navy, teal, route slide, model-then-your-turn | Those decks are Unit 3. They were not reused as Unit 1 content. |

Sample assessment materials are referenced by the specification (Appendix 6 and the SAM booklet). The SAM PDF was not separately downloaded in this build. Command-word definitions were taken from the specification itself.
