# Four-unit map

Unit 1 WEC11 is authored in this zip.

Unit 2 WEC12, Unit 3 WEC13 and Unit 4 WEC14 are mapped only at specification-overview level and are NOT STARTED.

| Unit | Code | Paper | Status |
|---|---|---|---|
| 1 Markets in action | WEC11 | 1h45, 80 marks, Section B present | v1.0 in this zip |
| 2 Macroeconomic performance and policy | WEC12 | Same shape as Unit 1 | NOT STARTED |
| 3 Business behaviour | WEC13 | 2h, no Section B, two essays from three | NOT STARTED. Prerequisite: Unit 1 demand, costs preview, surplus. |
| 4 Developments in the global economy | WEC14 | Same shape as Unit 3 | NOT STARTED. Prerequisite: Units 1 and 2. |

Unit 2 content headlines from Issue 2: measures of performance, AD, AS, national income and the multiplier, growth, objectives and policies.
Unit 3 headlines: business types, revenue costs and profit, market structures and contestability, labour markets, government intervention.
Unit 4 headlines: globalisation, trade, balance of payments and exchange rates, poverty and inequality, the state, growth and development.
