# CAPE Economics practice bank (500 items)

Original multiple-choice questions for classroom quizzes and online assessment tools. They are aligned to the revised CAPE Economics syllabus **CXC A20/U2/26**, effective for examinations from **May–June 2027**.

They are **not** CXC past-paper questions, specimen questions, or an official paper. Do not present the file as a CXC examination.

## There is no Unit 3

The revised syllabus has **two units**, not three. Each unit has three modules (about 50 hours each).

| Unit | Module | Questions |
|---|---|---|
| 1 Microeconomics | 1 Methodology: Demand and Supply | 85 |
| 1 Microeconomics | 2 Market Structure, Market Failure and Intervention | 85 |
| 1 Microeconomics | 3 Distribution Theory | 80 |
| 2 Macroeconomics | 1 Models of the Macroeconomy | 85 |
| 2 Macroeconomics | 2 Macroeconomic Problems and Policies | 85 |
| 2 Macroeconomics | 3 Growth, Sustainable Development and Global Relations | 80 |

Total: **500**. Each item is worth 1 mark and has one best answer.

## Files

| File | Use |
|---|---|
| `cape_economics_500.json` | Full bank: stem, options, key, explanation, syllabus topic, difficulty, and a numeric key on calculation items |
| `cape_economics_500.csv` | Same fields for spreadsheets |
| `cape_economics_500_simple.csv` | `question, A, B, C, D, answer, explanation` for simple importers |
| `cape_economics_500_moodle.xml` | Moodle XML, grouped by unit and module. Option order is already set; shuffling inside Moodle is off so the stored letter stays correct |
| `CAPE_Economics_500.pdf` | Printable questions plus a short answer key |

## Item fields (JSON)

`id`, `unit`, `unit_title`, `module`, `module_title`, `topic`, `syllabus_ref`, `difficulty`, `cognitive`, `type`, `stem`, `options` (A–D), `answer`, `explanation`, `marks`, `numeric_value`, `numeric_unit`, `source_note`.

`syllabus_ref` is unit.module.topic (for example `1.2.2` is Unit 1, Module 2, Market Failure). It is a topic code, not a claim that the wording is an official specific-objective statement.

Calculation items name the method in the stem (simple percentage elasticity, not the midpoint method, unless a question says otherwise). Place names and figures are fictional. Currency is written as EC dollars so items can be marked without relying on a live exchange rate.

## What was not copied

Past papers were used only to see that Paper 01 is a one-mark, four-option paper. No CXC question has been reproduced. Extended-response Papers 02 and 032 are not in this bank, because those items are not machine-marked.
