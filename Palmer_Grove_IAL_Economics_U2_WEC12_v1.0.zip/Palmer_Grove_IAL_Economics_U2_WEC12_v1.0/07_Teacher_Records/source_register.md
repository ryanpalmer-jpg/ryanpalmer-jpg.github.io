# Source register  ·  Unit 2

Access date: 12 October 2026.

| Document | Use | Limitation |
|---|---|---|
| Pearson Edexcel IAL Economics specification, Issue 2, June 2018 | Every lettered Unit 2 requirement, the 80-mark paper and Appendix 6 command words | Not UK GCE Economics A or B, and not the pre-2018 WEC01 course. |
| WEC12/01 mark scheme, June 2025 | Question stems and mark points used in the lessons | The question paper itself is not republished. |
| WEC12/01 mark scheme, January 2025 | Question stems and mark points, including China infrastructure and Turkey productivity | Section D is not a costs-of-inflation essay. |
| WEC12/01 mark scheme, June 2022 | Angola, the costs of growth, and the costs of high inflation | Indicative content is a guide, not a required list. |
| WEC12/01 mark scheme, January 2020 | Multiplier, migration, reflationary policy and the 9-mark country cap | Older than the 2024 and 2025 papers. |
| WEC12/01 principal examiner report, June 2024 | Traps named in the lessons | Sample scripts in that PDF are mostly images and are not reprinted here. |

Pearson questions in the lessons are labelled and taken from these mark schemes. Original questions are labelled Original IAL-style practice. Hypothetical data are labelled. Whole papers are not republished.
