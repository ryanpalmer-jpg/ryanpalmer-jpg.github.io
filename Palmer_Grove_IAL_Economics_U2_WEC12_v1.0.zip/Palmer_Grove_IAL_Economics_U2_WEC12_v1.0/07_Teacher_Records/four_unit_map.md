# Four-unit map

| Unit | Code | Status |
|---|---|---|
| 1 Markets in action | WEC11 | Published v1.0, but those lessons are shorter than this unit and are due the same past-paper treatment. |
| 2 Macroeconomic performance and policy | WEC12 | This zip. Eight lessons linked to the mark schemes listed in the source register. |
| 3 Business behaviour | WEC13 | NOT STARTED. The Unit 3 model decks are the pattern for lessons, not this unit’s content. |
| 4 Developments in the global economy | WEC14 | NOT STARTED. |
