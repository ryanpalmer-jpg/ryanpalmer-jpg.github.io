# Limitations

- Units 3 and 4 are not in this zip. The published Unit 1 lessons are shorter than these and do not yet have the same past-paper scans.
- Not every WEC12 series from 2019 to 2026 was opened. The lessons use June 2025, January 2025, June 2022, January 2020 and the June 2024 examiner report.
- A 20-mark guide of 12 marks for knowledge, application and analysis and 8 for evaluation, and a 14-mark guide of about 8 and 6, follows the level grids in those schemes. It is not a formula printed on the question paper.
- Slide PDFs are raster viewing copies, not a PowerPoint export.
- The multiplier assumes spare capacity unless the answer says otherwise.
- The full fiscal-debt analysis is Unit 4.
