# Review log  ·  Unit 2 v1.0

Economics: the Nepal, Angola, CPI, multiplier, Japan output-gap and Selva figures were recalculated against the mark schemes or the locked original arithmetic. Classical LRAS is vertical. Keynesian LRAS is flat then steep, with AD1 on the flat section. A higher base rate is drawn as AD shifting left along a classical LRAS. Axes are the price level and real output.

Assessment: both original papers sum to 80. Lake County is not in the lessons. Pearson stems in the lessons are attributed. Answers are illustrative.

Visual: 202 slides rasterised at 110 dpi from the PowerPoint coordinates, with Liberation Sans. No overflow warnings. Inspected the title, a past-paper scan, the Nepal steps, a model-essay paragraph, demand-pull, cost-push, short-run AD/SRAS, classical LRAS, AD shifting left along classical LRAS, Keynesian LRAS and the Phillips curve. This was not Microsoft PowerPoint.

Teaching: 8 lessons. Past-paper scans, mark-scheme splits and model paragraphs are in the teacher decks. Answers are not in the pupil PDF.
