# Diagram index

Native PowerPoint shapes in the teacher decks.

| ID | Where | Required reading |
|---|---|---|
| U2_D01 | U2_L02, U2_L05 | AD shifts right. Price level and real output rise in the short run. |
| U2_D02 | U2_L02, U2_L06 | SRAS shifts left. Price level rises, real output falls. January 2025 Q8. |
| U2_D03 | U2_L06 | Classical LRAS vertical. AD1 and AD2 meet it at the same real output. |
| U2_D04 | U2_L06 | Keynesian LRAS. AD1 meets the flat section. The June 2025 draw needs only one gap. |
| U2_D05 | U2_L07 | Short-run Phillips curve, inflation against unemployment. |
| U2_D06 | U2_L06, U2_L08 | AD shifts left along a classical LRAS. A higher base rate. |
