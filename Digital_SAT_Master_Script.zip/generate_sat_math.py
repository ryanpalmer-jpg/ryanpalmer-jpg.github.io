#!/usr/bin/env python3
"""Original Digital SAT-style math items. Answers are computed with the stem."""

import random
from fractions import Fraction

rng = random.Random(20260930)

DOMAINS = {
    "Algebra": 350,
    "Advanced Math": 350,
    "Problem-Solving and Data Analysis": 150,
    "Geometry and Trigonometry": 150,
}


def F(n):
    return Fraction(n).limit_denominator()


def ntex(n):
    n = F(n)
    if n.denominator == 1:
        return str(n.numerator)
    sign = "-" if n.numerator < 0 else ""
    return f"{sign}\\frac{{{abs(n.numerator)}}}{{{n.denominator}}}"


def nplain(n):
    n = F(n)
    if n.denominator == 1:
        return str(n.numerator)
    return f"{n.numerator}/{n.denominator}"


def coef_var(c, var="x", leading=False):
    c = F(c)
    if c == 0:
        return ""
    mag = abs(c)
    body = var if mag == 1 else f"{ntex(mag)}{var}"
    if leading:
        return f"-{body}" if c < 0 else body
    return f" - {body}" if c < 0 else f" + {body}"


def lin(a, b, var="x"):
    """ax+b as a latex expression."""
    a, b = F(a), F(b)
    if a == 0:
        return ntex(b)
    s = coef_var(a, var, leading=True)
    if b > 0:
        s += f" + {ntex(b)}"
    elif b < 0:
        s += f" - {ntex(-b)}"
    return s


def unique_wrongs(correct, candidates):
    correct = F(correct)
    out = []
    for c in candidates:
        c = F(c)
        if c != correct and c not in out:
            out.append(c)
    k = 1
    while len(out) < 3 and k < 40:
        for d in (k, -k):
            c = correct + d
            if c != correct and c not in out:
                out.append(c)
            if len(out) >= 3:
                break
        k += 1
    return out[:3]


def make_mc(correct, wrongs):
    correct = F(correct)
    opts = [correct] + unique_wrongs(correct, wrongs)
    rng.shuffle(opts)
    letter = "ABCD"[opts.index(correct)]
    return [ntex(o) for o in opts], letter, letter


class Item:
    def __init__(self, domain, skill, difficulty, kind, stem, choices, key):
        self.domain = domain
        self.skill = skill
        self.difficulty = difficulty
        self.kind = kind
        self.stem = stem
        self.choices = choices
        self.key = key


def emit(domain, skill, difficulty, stem, correct, wrongs, force_mc=False, spr_ok=True):
    # 25% student-produced response, unless the item is conceptual.
    use_spr = spr_ok and (not force_mc) and (rng.randrange(4) == 0)
    if use_spr:
        return Item(domain, skill, difficulty, "SPR", stem, None, nplain(correct))
    choices, letter, key = make_mc(correct, wrongs)
    return Item(domain, skill, difficulty, "MC", stem, choices, key)


def emit_text_mc(domain, skill, difficulty, stem, choices, answer_index):
    labels = "ABCD"
    opts = list(choices)
    # rotate so the correct option is not always A, without changing wording pairs
    shift = rng.randrange(4)
    opts = opts[shift:] + opts[:shift]
    answer_index = (answer_index - shift) % 4
    return Item(domain, skill, difficulty, "MC", stem, opts, labels[answer_index])


# ---------- Algebra ----------

def alg_solve_one(diff):
    if diff == "Easy":
        a = rng.choice([2, 3, 4, 5, 6, 8])
        x = rng.randint(2, 12)
        b = rng.randint(1, 15)
        c = a * x + b
        stem = f"What is the solution to the equation \\({lin(a, b)} = {c}\\)?"
        return emit("Algebra", "Linear equations in one variable", diff, stem, x, [x + 1, x - 1, c - b, a * x - b])
    if diff == "Medium":
        a = rng.randint(3, 9)
        c = rng.randint(1, a - 1)
        x = rng.randint(-6, 12)
        if x == 0:
            x = 4
        b = rng.randint(-8, 10)
        d = rng.randint(-8, 10)
        # ax+b = cx+d -> (a-c)x = d-b
        # choose so x matches: d = (a-c)*x + b
        d = (a - c) * x + b
        stem = (
            f"What value of \\(x\\) satisfies the equation "
            f"\\({lin(a, b)} = {lin(c, d)}\\)?"
        )
        wrong_x = F(d - b)  # forgot a-c
        return emit("Algebra", "Linear equations in one variable", diff, stem, x, [wrong_x, -x, x + c, b - d])
    # Hard: distribution
    a = rng.randint(2, 5)
    b = rng.randint(1, 6)
    c = rng.randint(2, 6)
    if a == c:
        c = 1 if a > 1 else 2
    x = rng.randint(-4, 9)
    if x == 0:
        x = 3
    # a(x+b) = cx + d, pick d so integer x: d = a(x+b) - c*x
    d = a * (x + b) - c * x
    stem = (
        f"What is the solution to \\({a}(x + {b}) = {lin(c, d)}\\)?"
    )
    forgot = F(a * x + b)  # nonsense distractor nearby
    no_dist = F((d - b) / (a - c)) if a != c else x + 1
    return emit("Algebra", "Linear equations in one variable", diff, stem, x, [-x, x + a, no_dist, forgot])


def alg_identity(diff):
    a = rng.randint(2, 8)
    b = rng.randint(1, 9)
    if rng.randrange(2) == 0:
        # infinite solutions: k(ax+b) = (ka)x + kb
        k = rng.randint(2, 5)
        stem = (
            f"How many solutions does the equation "
            f"\\({k}({lin(a, b)}) = {lin(k * a, k * b)}\\) have?"
        )
        # answer code: 2 means infinitely many. Use text MC.
        choices = [
            "Exactly one solution",
            "Exactly two solutions",
            "No solution",
            "Infinitely many solutions",
        ]
        return emit_text_mc("Algebra", "Number of solutions", diff, stem, choices, 3)
    stem = (
        f"How many solutions does the equation "
        f"\\({lin(a, b)} = {lin(a, b + rng.randint(1, 6))}\\) have?"
    )
    choices = [
        "Exactly one solution",
        "Exactly two solutions",
        "No solution",
        "Infinitely many solutions",
    ]
    return emit_text_mc("Algebra", "Number of solutions", diff, stem, choices, 2)


def alg_inequality(diff):
    a = rng.choice([2, 3, 4, 5])
    xbound = rng.randint(2, 10)
    b = rng.randint(1, 8)
    # ax - b < a*xbound - b  => x < xbound, but write the simplified result
    right = a * xbound - b
    if diff == "Hard":
        # flip on division by negative
        a = -a
        # a x + b < a*xbound + b => since a<0, x > xbound
        right = a * xbound + b
        stem = f"What is the solution set of \\({lin(a, b)} < {right}\\)?"
        # correct is x > xbound
        return emit_text_mc(
            "Algebra",
            "Linear inequalities",
            diff,
            stem,
            [
                f"\\(x > {xbound}\\)",
                f"\\(x < {xbound}\\)",
                f"\\(x > {xbound + 1}\\)",
                f"\\(x \\ge {xbound}\\)",
            ],
            0,
        )
    stem = f"What is the solution set of \\({lin(a, -b)} < {right}\\)?"
    return emit_text_mc(
        "Algebra",
        "Linear inequalities",
        diff,
        stem,
        [
            f"\\(x < {xbound}\\)",
            f"\\(x > {xbound}\\)",
            f"\\(x < {xbound - 1}\\)",
            f"\\(x \\le {xbound}\\)",
        ],
        0,
    )


def alg_point_ineq(diff):
    # which point satisfies px + qy > k, constructed
    p, q = rng.choice([(2, 1), (1, 2), (3, 1), (2, 3)])
    x0, y0 = rng.randint(1, 6), rng.randint(1, 6)
    k = p * x0 + q * y0
    good = (x0 + 1, y0)
    bad1 = (x0 - 1, y0) if x0 > 1 else (0, y0)
    bad2 = (x0, max(0, y0 - 1))
    bad3 = (0, 0)
    stem = (
        f"Which point \\((x, y)\\) is a solution of \\({lin(p, 0, 'x').replace('+ 0','')} + {q}y > {k}\\)?"
        if False else
        f"Which point \\((x, y)\\) is a solution of the inequality \\({p}x + {q}y > {k}\\)?"
    )
    pts = [good, bad1, bad2, bad3]
    # ensure good is the only one that works; fix if a bad one accidentally works
    def ok(pt):
        return p * pt[0] + q * pt[1] > k
    assert ok(good)
    bads = []
    for pt in [(x0 - 2, y0), (x0, y0 - 2), (0, 0), (x0 - 1, y0 - 1), (1, 1)]:
        if not ok(pt) and pt not in bads and pt != good:
            bads.append(pt)
        if len(bads) == 3:
            break
    choices = [f"\\(({good[0]}, {good[1]})\\)"] + [f"\\(({a}, {b})\\)" for a, b in bads]
    return emit_text_mc("Algebra", "Linear inequalities", diff, stem, choices, 0)


def alg_slope(diff):
    if diff == "Easy":
        x1, y1 = rng.randint(0, 4), rng.randint(0, 4)
        run = rng.choice([1, 2, 3, 4])
        rise = rng.choice([1, 2, 3, 4, 6])
        x2, y2 = x1 + run, y1 + rise
        m = Fraction(rise, run)
        stem = f"What is the slope of the line through \\(({x1}, {y1})\\) and \\(({x2}, {y2})\\)?"
        return emit("Algebra", "Linear equations in two variables", diff, stem, m, [Fraction(run, rise), -m, rise, run])
    if diff == "Medium":
        m = Fraction(rng.choice([-3, -2, -1, 1, 2, 3, 4]), rng.choice([1, 2]))
        b = rng.randint(-5, 6)
        x = rng.randint(-2, 5)
        y = m * x + b
        stem = (
            f"The line with equation \\(y = {lin(m, b)}\\) passes through the point "
            f"\\(({x}, k)\\). What is the value of \\(k\\)?"
        )
        return emit("Algebra", "Linear functions", diff, stem, y, [m * x - b, m + b, x + b, -y])
    # perpendicular
    m = Fraction(rng.choice([1, 2, 3, 4]), rng.choice([1, 2, 3]))
    mp = -1 / m
    stem = f"A line is perpendicular to the line \\(y = {lin(m, rng.randint(-3, 4))}\\). What is the slope of the perpendicular line?"
    return emit("Algebra", "Linear equations in two variables", diff, stem, mp, [m, -m, 1 / m, m + 1])


def alg_interpret(diff):
    start = rng.choice([40, 60, 80, 120, 150, 200, 240])
    rate = rng.choice([3, 4, 5, 6, 8, 10, 12])
    contexts = [
        (f"A tank contains {start} gallons of water and drains at a constant rate of {rate} gallons per minute.",
         "g", "m", "gallons remaining", "minutes"),
        (f"A student has \\${start} saved and spends \\${rate} each week.",
         "d", "w", "dollars remaining", "weeks"),
        (f"A phone battery is at {start}\\% and loses {rate} percentage points each hour during a call.",
         "p", "h", "percent remaining", "hours"),
    ]
    intro, dep, ind, _dep_name, ind_name = contexts[rng.randrange(3)]
    stem = (
        f"{intro} Which equation gives {dep}, the amount remaining after {ind} {ind_name}, "
        f"assuming the rate stays constant?"
    )
    eq_ok = f"\\({dep} = {start} - {rate}{ind}\\)"
    choices = [
        eq_ok,
        f"\\({dep} = {rate}{ind} - {start}\\)",
        f"\\({dep} = {start} + {rate}{ind}\\)",
        f"\\({dep} = {rate} - {start}{ind}\\)",
    ]
    return emit_text_mc("Algebra", "Linear functions", diff, stem, choices, 0)


def alg_system(diff):
    x = rng.randint(-4, 8)
    y = rng.randint(-4, 8)
    if diff == "Easy":
        # x + y = s, x - y = d
        s, d = x + y, x - y
        stem = (
            f"The solution of the system \\(x + y = {s}\\) and \\(x - y = {d}\\) is \\((x, y)\\). "
            f"What is the value of \\(x\\)?"
        )
        return emit("Algebra", "Systems of linear equations", diff, stem, x, [y, s, d, x + y])
    a, b = rng.choice([(2, 3), (3, 2), (4, 1), (2, 5), (3, 4), (5, 2)])
    c, e = rng.choice([(1, -1), (1, 2), (2, -1), (3, 1), (1, -2)])
    r1 = a * x + b * y
    r2 = c * x + e * y
    ask = x + y if diff == "Hard" else x
    stem = (
        f"In the solution of the system\n"
        f"\\[{a}x + {b}y = {r1}\\]\n"
        f"\\[{lin(c, 0).rstrip()} {('+ ' + str(e) + 'y') if e > 0 else ('- ' + str(-e) + 'y')} = {r2}\\]\n"
        f"what is the value of \\({'x + y' if ask == x + y else 'x'}\\)?"
    )
    # cleaner second equation
    def eq(p, q, r):
        return f"{lin(p, 0, 'x')} {coef_var(q, 'y') if q != 0 else ''} = {r}".replace("  ", " ")
    # rebuild properly
    second = f"{coef_var(c, 'x', True)}{coef_var(e, 'y')}"
    stem = (
        f"What is the value of \\({'x + y' if diff == 'Hard' else 'x'}\\) in the solution of "
        f"\\({coef_var(a, 'x', True)}{coef_var(b, 'y')} = {r1}\\) and "
        f"\\({second} = {r2}\\)?"
    )
    return emit(
        "Algebra",
        "Systems of linear equations",
        diff,
        stem,
        ask,
        [x, y, x - y, r1],
    )


def alg_system_count(diff):
    m = rng.choice([2, 3, 4, 5])
    b1 = rng.randint(-3, 5)
    if rng.randrange(2) == 0:
        b2 = b1  # same line if second is multiple, infinitely many
        k = rng.choice([2, 3])
        stem = (
            f"How many solutions does the system \\(y = {lin(m, b1)}\\) and "
            f"\\({k}y = {lin(k * m, k * b1)}\\) have?"
        )
        choices = ["None", "Exactly one", "Exactly two", "Infinitely many"]
        return emit_text_mc("Algebra", "Systems of linear equations", diff, stem, choices, 3)
    b2 = b1 + rng.choice([1, 2, 3, 4])
    stem = (
        f"How many solutions does the system \\(y = {lin(m, b1)}\\) and "
        f"\\(y = {lin(m, b2)}\\) have?"
    )
    choices = ["None", "Exactly one", "Exactly two", "Infinitely many"]
    return emit_text_mc("Algebra", "Systems of linear equations", diff, stem, choices, 0)


def alg_isolate(diff):
    # A = (1/2) h (b1+b2) solve for h, or P = 2l+2w solve for l
    if diff != "Hard":
        # 2l + 2w = P, l = (P - 2w)/2
        # ask numerical: P and w given
        l = rng.randint(4, 15)
        w = rng.randint(2, 10)
        p = 2 * l + 2 * w
        stem = (
            f"The perimeter of a rectangle is \\({p}\\) and the width is \\({w}\\). "
            f"What is the length?"
        )
        return emit("Algebra", "Solve for a variable", diff, stem, l, [p - w, p / 2, w, (p - w) / 2])
    # v = d/t solve numeric
    t = rng.choice([2, 3, 4, 5, 6])
    r = rng.randint(8, 25)  # rate
    d = r * t
    stem = f"A car travels \\({d}\\) miles in \\({t}\\) hours at a constant speed. What is the speed in miles per hour?"
    return emit("Algebra", "Solve for a variable", diff, stem, r, [d * t, d + t, t, d - t])


# ---------- Advanced Math ----------

def adv_expand(diff):
    p = rng.randint(1, 8)
    q = rng.randint(1, 8)
    # (x+p)(x+q) = x^2 + (p+q)x + pq
    s, prod = p + q, p * q
    if diff == "Easy":
        stem = f"Which expression is equivalent to \\((x + {p})(x + {q})\\)?"
        correct = f"\\(x^2 + {s}x + {prod}\\)"
        choices = [
            correct,
            f"\\(x^2 + {prod}x + {s}\\)",
            f"\\(x^2 + {s}x + {p + q + 1}\\)",
            f"\\(x^2 - {s}x + {prod}\\)",
        ]
        return emit_text_mc("Advanced Math", "Equivalent expressions", diff, stem, choices, 0)
    # factor
    stem = f"Which expression is equivalent to \\(x^2 + {s}x + {prod}\\)?"
    correct = f"\\((x + {p})(x + {q})\\)"
    choices = [
        correct,
        f"\\((x + {s})(x + {prod})\\)",
        f"\\((x + {p})(x - {q})\\)",
        f"\\((x - {p})(x - {q})\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions", diff, stem, choices, 0)


def quad_tex(s, p):
    expr = "x^2"
    if s > 0:
        expr += f" - {s}x"
    elif s < 0:
        expr += f" + {-s}x"
    if p > 0:
        expr += f" + {p}"
    elif p < 0:
        expr += f" - {-p}"
    return expr


def adv_quadratic(diff):
    r1 = rng.randint(-5, 8)
    r2 = rng.randint(-5, 9)
    if r1 == r2:
        r2 += 3
    s, p = r1 + r2, r1 * r2
    eq = quad_tex(s, p)
    if diff == "Easy":
        stem = f"What is the sum of the solutions of \\({eq} = 0\\)?"
        return emit("Advanced Math", "Nonlinear equations", diff, stem, s, [p, r1, r2, abs(r1 - r2)])
    if diff == "Medium":
        bigger = max(r1, r2)
        stem = f"What is the greater solution of \\({eq} = 0\\)?"
        return emit("Advanced Math", "Nonlinear equations", diff, stem, bigger, [min(r1, r2), s, p, bigger + 1])
    h = rng.randint(1, 8)
    k = rng.randint(-6, 9)
    stem = (
        f"The function \\(f(x) = x^2 - {2 * h}x + {h * h + k}\\) is defined for all real \\(x\\). "
        f"What is the minimum value of \\(f\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions", diff, stem, k, [h, h * h + k, -h, 2 * h])


def adv_exp(diff):
    if diff == "Easy":
        a = rng.randint(2, 12)
        b = rng.choice([2, 3, 4])
        t = rng.choice([2, 3, 4])
        stem = f"If \\(f(t) = {a}\\cdot {b}^{{t}}\\), what is the value of \\(f({t})\\)?"
        val = a * (b ** t)
        return emit("Advanced Math", "Nonlinear functions", diff, stem, val, [a * b * t, a + b ** t, b ** t, a * b + t])
    if diff == "Medium":
        start = rng.choice([20, 40, 50, 80, 100, 125, 200, 250])
        factor = rng.choice([2, 3])
        years = rng.choice([2, 3, 4])
        val = start * (factor ** years)
        stem = (
            f"A population is modeled by \\(P(t) = {start}\\cdot {factor}^{{t}}\\), "
            f"where \\(t\\) is the number of years after the count begins. What is \\(P({years})\\)?"
        )
        return emit("Advanced Math", "Nonlinear functions", diff, stem, val, [start * factor * years, start + factor * years, factor ** years, start * years])
    # Hard: find the initial value. P(t)=a*b^t, given P(2) and b, find a.
    b = rng.choice([2, 3, 4])
    a = rng.randint(3, 20)
    t = 2
    stem = (
        f"A quantity grows by the model \\(P(t) = a \\cdot {b}^{{t}}\\). "
        f"If \\(P({t}) = {a * (b ** t)}\\), what is the value of \\(a\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions", diff, stem, a, [a * b, a * b * t, b ** t, a + b])


def adv_exponents(diff):
    # (x^m)^n = x^{mn}, or x^a * x^b
    m = rng.randint(2, 6)
    n = rng.randint(2, 5)
    if diff == "Easy":
        stem = f"Which expression is equivalent to \\(x^{{{m}}} \\cdot x^{{{n}}}\\) for \\(x \\ne 0\\)?"
        correct = f"\\(x^{{{m + n}}}\\)"
        choices = [correct, f"\\(x^{{{m * n}}}\\)", f"\\(x^{{{abs(m - n)}}}\\)", f"\\({m * n}x\\)"]
        return emit_text_mc("Advanced Math", "Equivalent expressions", diff, stem, choices, 0)
    stem = f"Which expression is equivalent to \\((x^{{{m}}})^{{{n}}}\\)?"
    correct = f"\\(x^{{{m * n}}}\\)"
    choices = [correct, f"\\(x^{{{m + n}}}\\)", f"\\(x^{{{m}}}\\)", f"\\({m * n}x\\)"]
    return emit_text_mc("Advanced Math", "Equivalent expressions", diff, stem, choices, 0)


def adv_function(diff):
    if diff == "Easy":
        a = rng.randint(2, 6)
        b = rng.randint(-5, 8)
        x = rng.randint(-3, 8)
        stem = f"If \\(f(x) = {lin(a, b)}\\), what is the value of \\(f({x})\\)?"
        val = a * x + b
        return emit("Advanced Math", "Nonlinear functions", diff, stem, val, [a * x - b, a + b + x, a * (x + b)])
    if diff == "Medium":
        a, b = rng.randint(2, 5), rng.randint(-4, 6)
        c, d = rng.randint(2, 4), rng.randint(-3, 5)
        x = rng.randint(-2, 5)
        # f(g(x)) = a(cx+d)+b
        val = a * (c * x + d) + b
        stem = (
            f"If \\(f(x) = {lin(a, b)}\\) and \\(g(x) = {lin(c, d)}\\), "
            f"what is the value of \\(f(g({x}))\\)?"
        )
        return emit("Advanced Math", "Nonlinear functions", diff, stem, val, [a * x + b + c * x + d, (a + c) * x + (b + d), a * c * x])
    # horizontal shift: g(x) = f(x-h), g(t) = f(t-h)
    h = rng.randint(1, 4)
    t = rng.randint(3, 8)
    # give f at t-h
    fv = rng.randint(-5, 12)
    stem = (
        f"The function \\(g\\) is defined by \\(g(x) = f(x - {h})\\). "
        f"If \\(f({t - h}) = {fv}\\), what is the value of \\(g({t})\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions", diff, stem, fv, [fv + h, fv - h, t - h, fv + t])


def adv_radical(diff):
    b = rng.randint(2, 9)
    add = rng.randint(1, 12)
    x = b * b - add
    if x <= 0:
        add = 1
        x = b * b - 1
    stem = f"What is the solution of \\(\\sqrt{{x + {add}}} = {b}\\)?"
    return emit("Advanced Math", "Nonlinear equations", diff, stem, x, [b + add, b * b + add, b * b, add - b])


def adv_rational(diff):
    # (x+a)/(x+b) = c, c small integer, x+b != 0
    c = rng.choice([2, 3, 4])
    b = rng.randint(1, 6)
    # pick x so x+b != 0
    x = rng.randint(-5, 8)
    if x + b == 0:
        x += 1
    a = c * (x + b) - x
    stem = f"What value of \\(x\\) satisfies \\(\\dfrac{{x + {a}}}{{x + {b}}} = {c}\\), given that the expression is defined?"
    # if a is negative, rewrite
    if a < 0:
        stem = f"What value of \\(x\\) satisfies \\(\\dfrac{{x - {-a}}}{{x + {b}}} = {c}\\), given that the expression is defined?"
    forgot = c * (x + b)
    return emit("Advanced Math", "Nonlinear equations", diff, stem, x, [-b, forgot, x + c, a])


def adv_nonlinear_system(diff):
    a = rng.randint(2, 16)
    if diff == "Medium":
        stem = (
            f"The graphs of \\(y = x^2\\) and \\(y = {a}x\\) intersect at the origin and one other point. "
            f"What is the positive \\(x\\)-coordinate of that other point?"
        )
        return emit("Advanced Math", "Systems of equations", diff, stem, a, [a * a, 0, a + 1, Fraction(a, 2)])
    stem = (
        f"The graphs of \\(y = x^2\\) and \\(y = {a}x\\) intersect at the origin and one other point. "
        f"What is the \\(y\\)-coordinate of that other point?"
    )
    return emit("Advanced Math", "Systems of equations", diff, stem, a * a, [a, 2 * a, a * a * a, 0])


def adv_discriminant(diff):
    kind = rng.choice(["two", "one", "none"])
    if kind == "two":
        r1 = rng.randint(-6, 9)
        r2 = r1 + rng.randint(1, 6)
        s, p = r1 + r2, r1 * r2
        n = 2
        eq = quad_tex(s, p)
    elif kind == "one":
        r = rng.randint(-8, 8)
        eq = quad_tex(2 * r, r * r)
        n = 1
    else:
        b = rng.randint(0, 8)
        c = (b * b) // 4 + rng.randint(2, 10)
        eq = quad_tex(-b, c)
        n = 0
    stem = f"How many distinct real solutions does \\({eq} = 0\\) have?"
    choices = ["None", "Exactly one", "Exactly two", "Infinitely many"]
    return emit_text_mc("Advanced Math", "Nonlinear equations", diff, stem, choices, {0: 0, 1: 1, 2: 2}[n])


def adv_structure(diff):
    # Which is equivalent to (x-3)(x+4) - 2(x-3)
    a = rng.randint(2, 6)
    b = rng.randint(2, 7)
    k = rng.randint(2, 5)
    # (x-a)(x+b) - k(x-a) = (x-a)(x+b-k)
    stem = (
        f"Which expression is equivalent to \\((x - {a})(x + {b}) - {k}(x - {a})\\)?"
    )
    correct = f"\\((x - {a})(x + {b - k})\\)"
    choices = [
        correct,
        f"\\((x - {a})(x + {b + k})\\)",
        f"\\((x + {a})(x + {b - k})\\)",
        f"\\((x - {a})(x - {b - k})\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions", diff, stem, choices, 0)


# ---------- PSDA ----------

def ps_ratio(diff):
    a = rng.choice([2, 3, 4, 5])
    b = rng.choice([2, 3, 5, 6])
    mult = rng.choice([3, 4, 5, 6, 8]) if diff != "Easy" else rng.choice([2, 3, 4])
    part = a * mult
    whole = (a + b) * mult
    stem = (
        f"The ratio of red marbles to blue marbles in a bag is \\({a}:{b}\\). "
        f"There are \\({part}\\) red marbles. How many marbles are in the bag?"
    )
    return emit("Problem-Solving and Data Analysis", "Ratios and rates", diff, stem, whole, [part + b, a * b * mult, part * b, (a + b) * part])


def ps_unit(diff):
    miles = rng.choice([120, 150, 180, 210, 240, 300])
    hours = rng.choice([2, 3, 4, 5])
    if miles % hours != 0:
        miles = hours * rng.randint(40, 70)
    rate = miles // hours
    stem = f"A car travels \\({miles}\\) miles in \\({hours}\\) hours at a constant speed. What is the speed in miles per hour?"
    return emit("Problem-Solving and Data Analysis", "Ratios and rates", diff, stem, rate, [miles * hours, miles + hours, hours, miles - hours])


def ps_percent(diff):
    price = rng.choice([40, 50, 60, 80, 100, 120, 200])
    pct = rng.choice([10, 15, 20, 25, 30])
    if diff == "Easy":
        # Exact sale price. Integer division (50 reduced by 15% -> 43) is wrong.
        off = Fraction(price * pct, 100)
        sale = price - off
        stem = f"A jacket costs \\${price}. During a sale the price is reduced by {pct}\\%. What is the sale price, in dollars?"
        return emit("Problem-Solving and Data Analysis", "Percentages", diff, stem, sale, [off, price + off, price * pct, pct])
    # increase then decrease or discount then tax
    tax = rng.choice([5, 8, 10])
    sale = price * (100 - pct) // 100
    final = sale * (100 + tax) // 100
    # ensure integer
    if price * (100 - pct) * (100 + tax) % 10000 != 0:
        price, pct, tax = 80, 25, 10
        sale = 60
        final = 66
    stem = (
        f"A bike is listed at \\${price}. It is discounted by {pct}\\%, and then a {tax}\\% sales tax "
        f"is added to the discounted price. What is the final price, in dollars?"
    )
    return emit("Problem-Solving and Data Analysis", "Percentages", diff, stem, final, [sale, price * (100 - pct + tax) // 100, price - pct - tax, sale + tax])


def ps_mean(diff):
    n = 5 if diff != "Hard" else 6
    nums = [rng.randint(4, 20) for _ in range(n - 1)]
    target = rng.randint(8, 16)
    # missing m: (sum + m)/n = target
    m = target * n - sum(nums)
    if m <= 0 or m > 40:
        nums = [10, 12, 8, 11][: n - 1]
        while len(nums) < n - 1:
            nums.append(9)
        m = target * n - sum(nums)
    listed = ", ".join(str(v) for v in nums)
    stem = (
        f"The mean of the numbers {listed}, and \\(x\\) is \\({target}\\). "
        f"What is the value of \\(x\\)?"
    )
    return emit("Problem-Solving and Data Analysis", "One-variable data", diff, stem, m, [target, sum(nums) // max(1, n - 1), m + 1, target * n])


def ps_median(diff):
    base = sorted(rng.sample(range(2, 30), 4))
    # 5 numbers, median is the middle after insert
    mid = rng.randint(base[1] + 1, base[2] + 3)
    data = sorted(base + [mid])
    assert data[2] == mid or True
    # Force median by placing mid as third
    data = sorted([base[0], base[1], mid, base[2], base[3]])
    median = data[2]
    listed = ", ".join(str(v) for v in data)
    stem = f"What is the median of the data set {listed}?"
    return emit("Problem-Solving and Data Analysis", "One-variable data", diff, stem, median, [data[0], data[-1], sum(data) // 5, data[1]])


def ps_prob(diff):
    red = rng.randint(3, 9)
    blue = rng.randint(2, 8)
    green = rng.randint(1, 6)
    total = red + blue + green
    if diff == "Hard":
        # conditional: given not green, probability red
        stem = (
            f"A bag has {red} red, {blue} blue, and {green} green counters. "
            f"One counter is drawn at random. Given that it is not green, what is the probability that it is red?"
        )
        ans = Fraction(red, red + blue)
        return emit(
            "Problem-Solving and Data Analysis",
            "Probability",
            diff,
            stem,
            ans,
            [Fraction(red, total), Fraction(blue, red + blue), Fraction(green, total)],
        )
    stem = (
        f"A bag has {red} red, {blue} blue, and {green} green counters. "
        f"One counter is drawn at random. What is the probability that it is red?"
    )
    ans = Fraction(red, total)
    return emit(
        "Problem-Solving and Data Analysis",
        "Probability",
        diff,
        stem,
        ans,
        [Fraction(blue, total), Fraction(red, blue), Fraction(1, 3)],
    )


def ps_table(diff):
    # two-way: club by grade
    a = rng.randint(8, 18)  # yes junior
    b = rng.randint(6, 16)  # no junior
    c = rng.randint(5, 14)  # yes senior
    d = rng.randint(7, 16)
    stem = (
        f"A school recorded whether students joined a club. "
        f"Among juniors, {a} joined and {b} did not. Among seniors, {c} joined and {d} did not. "
        f"A student is chosen at random from those who joined the club. "
        f"What is the probability that the student is a junior?"
    )
    ans = Fraction(a, a + c)
    return emit(
        "Problem-Solving and Data Analysis",
        "Probability",
        diff,
        stem,
        ans,
        [Fraction(a, a + b), Fraction(a, a + b + c + d), Fraction(c, a + c)],
    )


def ps_predict(diff):
    m = rng.choice([2, 3, 4, 5, -2, -3])
    b = rng.randint(1, 12)
    x = rng.randint(3, 10)
    y = m * x + b
    stem = (
        f"A line of best fit for a data set is \\(y = {lin(m, b)}\\), "
        f"where \\(x\\) is the number of hours studied and \\(y\\) is the predicted score. "
        f"According to the model, what is the predicted score when \\(x = {x}\\)?"
    )
    return emit("Problem-Solving and Data Analysis", "Two-variable data", diff, stem, y, [m * x - b, m + b + x, b, m * x])


def ps_margin(diff):
    n = rng.choice([400, 600, 800, 900, 1200])
    p = rng.choice([48, 52, 54, 57, 61, 63])
    m = rng.choice([3, 4, 5])
    stem = (
        f"In a random sample of {n} voters, {p}\\% supported a proposal. "
        f"The margin of error for this estimate is {m} percentage points. "
        f"Which conclusion is best supported?"
    )
    choices = [
        f"It is plausible that between {p - m}\\% and {p + m}\\% of all voters support the proposal.",
        f"Exactly {p}\\% of all voters support the proposal.",
        f"The margin of error would stay {m} percentage points if the sample size were much smaller.",
        "The result proves that the proposal will pass.",
    ]
    return emit_text_mc("Problem-Solving and Data Analysis", "Inference from samples", diff, stem, choices, 0)


def ps_study(diff):
    bank = [
        (
            "A researcher wants to know whether a new homework format causes higher quiz scores for students at one high school. Which design best supports a cause-and-effect conclusion?",
            [
                "Randomly assign students at the school to the new format or the current format, then compare quiz scores.",
                "Ask volunteers to try the new format and compare them with students who kept the old format.",
                "Survey a random sample of students about which format they prefer.",
                "Compare this year's quiz scores with last year's after the school changes the format for everyone.",
            ],
        ),
        (
            "A coach wants to test whether a new warm-up causes faster sprint times. Which design best supports a cause-and-effect conclusion?",
            [
                "Randomly assign athletes to the new warm-up or the usual warm-up, then compare sprint times.",
                "Let the fastest athletes choose the new warm-up and compare them with the others.",
                "Survey athletes about which warm-up they like.",
                "Use the new warm-up for the whole team and compare this season with last season.",
            ],
        ),
        (
            "A school claims that students who join the chess club have higher math grades, so the club causes the higher grades. Why is that claim not well supported?",
            [
                "Students who choose the club may already differ from students who do not.",
                "The school did not report the margin of error of a poll.",
                "A mean cannot be computed from letter grades.",
                "Observational results are never allowed to include numbers.",
            ],
        ),
        (
            "To estimate the proportion of all students at a college who live on campus, which method is most appropriate?",
            [
                "Take a random sample of students from the college and record whether each lives on campus.",
                "Ask only the students in one dormitory.",
                "Assign a random half of the college to move on campus.",
                "Survey students at a different college.",
            ],
        ),
        (
            "A poll uses a random sample of city residents. Which change would be expected to reduce the margin of error?",
            [
                "Increase the sample size.",
                "Ask the question in a different order only.",
                "Replace the random sample with volunteers.",
                "Report the result as a fraction instead of a percent.",
            ],
        ),
        (
            "Researchers randomly select classrooms, then randomly assign those classrooms to a new reading program or the current program. The random assignment is useful mainly because it helps",
            [
                "support a conclusion about the effect of the program.",
                "remove the need to record any scores.",
                "guarantee that every student in the country is represented.",
                "make the margin of error equal to zero.",
            ],
        ),
    ]
    stem, choices = bank[rng.randrange(len(bank))]
    return emit_text_mc("Problem-Solving and Data Analysis", "Evaluating statistical claims", diff, stem, choices, 0)


# ---------- Geometry ----------

def geo_angles(diff):
    if diff == "Easy":
        a = rng.randint(28, 80)
        b = rng.randint(25, 75)
        c = 180 - a - b
        if c < 20 or c > 120:
            return geo_angles(diff)
        stem = f"Two angles of a triangle measure \\({a}^\\circ\\) and \\({b}^\\circ\\). What is the measure, in degrees, of the third angle?"
        return emit("Geometry and Trigonometry", "Angles and triangles", diff, stem, c, [a + b, 360 - a - b, 90, a])
    a = rng.randint(32, 148)
    if a == 90:
        a = 96
    if diff == "Medium":
        stem = (
            f"Two parallel lines are cut by a transversal. One interior angle measures \\({a}^\\circ\\). "
            f"What is the measure, in degrees, of the consecutive interior angle on the same side of the transversal?"
        )
        return emit("Geometry and Trigonometry", "Angles and triangles", diff, stem, 180 - a, [a, 90, 360 - a, abs(a - 90)])
    stem = (
        f"Two parallel lines are cut by a transversal. One angle measures \\({a}^\\circ\\). "
        f"What is the measure, in degrees, of the alternate interior angle?"
    )
    return emit("Geometry and Trigonometry", "Angles and triangles", diff, stem, a, [180 - a, 90, 360 - a, a + 2])


def geo_pythag(diff):
    triples = [
        (3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (20, 21, 29),
        (12, 35, 37), (9, 40, 41), (12, 16, 20), (15, 20, 25), (9, 12, 15),
        (15, 36, 39), (10, 24, 26), (18, 24, 30), (16, 30, 34), (21, 28, 35),
        (6, 8, 10), (14, 48, 50), (11, 60, 61),
    ]
    a, b, c = triples[rng.randrange(len(triples))]
    if rng.randrange(2) == 0:
        a, b = b, a
    if diff == "Hard":
        stem = f"A right triangle has legs of length {a} and {b}. What is the length of the hypotenuse?"
        return emit("Geometry and Trigonometry", "Right triangles", diff, stem, c, [a + b, abs(a - b), a * b, c + 1])
    stem = f"A right triangle has a hypotenuse of length {c} and one leg of length {a}. What is the length of the other leg?"
    return emit("Geometry and Trigonometry", "Right triangles", diff, stem, b, [c - a, a + c, c, a])


def geo_special(diff):
    k = rng.randint(2, 18)
    if rng.randrange(2) == 0:
        # 45-45-90, legs k, hypotenuse k√2. Ask hypotenuse coefficient? 
        # SAT often asks the length. We'll ask the leg if hypotenuse is k√2... 
        # Ask: hypotenuse is  k*sqrt(2)? Better ask the other leg of isosceles right triangle with leg k, 
        # the hypotenuse is k√2. SPR of a radical is awkward.
        # Ask the leg given hypotenuse... if hypotenuse is k√2 the leg is k, integer.
        stem = (
            f"An isosceles right triangle has a hypotenuse of length \\({k}\\sqrt{{2}}\\). "
            f"What is the length of each leg?"
        )
        return emit("Geometry and Trigonometry", "Right triangles", diff, stem, k, [k * 2, 2 * k, k * k, Fraction(k, 2)])
    # 30-60-90: side opposite 30 is k, opposite 60 is k√3, hypotenuse 2k
    stem = (
        f"In a \\(30^\\circ\\)-\\(60^\\circ\\)-\\(90^\\circ\\) triangle, the side opposite the \\(30^\\circ\\) angle has length {k}. "
        f"What is the length of the hypotenuse?"
    )
    return emit("Geometry and Trigonometry", "Right triangles", diff, stem, 2 * k, [k, 3 * k, k * k, 60])


def geo_area(diff):
    if diff == "Easy":
        L = rng.randint(4, 15)
        W = rng.randint(3, 12)
        stem = f"A rectangle has length {L} and width {W}. What is its area?"
        return emit("Geometry and Trigonometry", "Area and volume", diff, stem, L * W, [2 * (L + W), L + W, L * W + 2, 2 * L * W])
    b = rng.randint(4, 16)
    h = rng.choice([4, 6, 8, 10, 12])
    stem = f"A triangle has a base of length {b} and a corresponding height of {h}. What is the area of the triangle?"
    return emit("Geometry and Trigonometry", "Area and volume", diff, stem, Fraction(b * h, 2), [b * h, b + h, Fraction(b * h, 4), 2 * b * h])


def geo_volume(diff):
    if diff != "Hard":
        L, W, H = rng.randint(3, 10), rng.randint(3, 8), rng.randint(2, 9)
        stem = (
            f"A rectangular prism has length {L}, width {W}, and height {H}. "
            f"What is the volume of the prism?"
        )
        return emit("Geometry and Trigonometry", "Area and volume", diff, stem, L * W * H, [L + W + H, 2 * (L * W + L * H + W * H), L * W, L * H])
    r = rng.choice([2, 3, 4, 5, 6])
    h = rng.randint(4, 12)
    # V = π r^2 h, ask the coefficient of π
    stem = (
        f"A right circular cylinder has radius {r} and height {h}. "
        f"The volume is \\(k\\pi\\). What is the value of \\(k\\)?"
    )
    return emit("Geometry and Trigonometry", "Area and volume", diff, stem, r * r * h, [2 * r * h, r * h, 2 * r * r * h, r * r + h])


def geo_circle(diff):
    if diff == "Easy":
        r = rng.randint(3, 12)
        stem = f"A circle has radius {r}. The circumference is \\(k\\pi\\). What is the value of \\(k\\)?"
        return emit("Geometry and Trigonometry", "Circles", diff, stem, 2 * r, [r, r * r, 2 * r * r, r + 2])
    if diff == "Medium":
        h = rng.randint(-6, 6)
        k = rng.randint(-6, 6)
        r = rng.choice([2, 3, 4, 5, 6, 7])
        stem = (
            f"A circle has equation \\((x {('- ' + str(h)) if h >= 0 else ('+ ' + str(-h))})^2 + "
            f"(y {('- ' + str(k)) if k >= 0 else ('+ ' + str(-k))})^2 = {r * r}\\). "
            f"What is the radius of the circle?"
        )
        # fix signs: (x - h) if h positive means center h. If h is the center,
        # equation (x - h)^2. If h negative, (x - (neg)) = (x+pos).
        stem = (
            f"What is the radius of the circle with equation "
            f"\\((x - {h})^2 + (y - {k})^2 = {r * r}\\)?"
            if h >= 0 and k >= 0 else
            f"What is the radius of the circle with equation "
            f"\\((x {('- ' + str(h)) if h > 0 else ('+ ' + str(-h)) if h < 0 else ''})^2 + "
            f"(y {('- ' + str(k)) if k > 0 else ('+ ' + str(-k)) if k < 0 else ''})^2 = {r * r}\\)?"
        )
        if h == 0 or k == 0:
            h, k = abs(h) + 2, abs(k) + 3
            stem = f"What is the radius of the circle with equation \\((x - {h})^2 + (y - {k})^2 = {r * r}\\)?"
        return emit("Geometry and Trigonometry", "Circles", diff, stem, r, [r * r, 2 * r, h, k])
    # complete the square
    h = rng.choice([2, 3, 4, 5])
    k = rng.choice([1, 2, 3, 4])
    r = rng.choice([3, 4, 5, 6])
    # (x-h)^2 + (y+k)^2 = r^2
    # x^2 - 2h x + y^2 + 2k y = r^2 - h^2 - k^2
    right = r * r - h * h - k * k
    stem = (
        f"What is the radius of the circle with equation "
        f"\\(x^2 - {2 * h}x + y^2 + {2 * k}y = {right}\\)?"
    )
    return emit("Geometry and Trigonometry", "Circles", diff, stem, r, [r * r, h, k, 2 * r])


def geo_similar(diff):
    k = rng.choice([2, 3, 4])
    a = rng.randint(3, 8)
    b = a + rng.randint(2, 6)
    stem = (
        f"Two triangles are similar. A pair of corresponding sides measure {a} and {a * k}. "
        f"Another side of the smaller triangle measures {b}. "
        f"What is the length of the corresponding side of the larger triangle?"
    )
    return emit("Geometry and Trigonometry", "Angles and triangles", diff, stem, b * k, [b + k, a * b, b * k + a, Fraction(b, k)])


def geo_trig(diff):
    triples = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (6, 8, 10), (9, 12, 15), (20, 21, 29), (12, 16, 20), (9, 40, 41), (12, 35, 37)]
    a, b, c = triples[rng.randrange(len(triples))]
    which = rng.choice(["sin", "cos", "tan"])
    # angle at A, opposite a, adjacent b, hypotenuse c
    stem = (
        f"In a right triangle, the side opposite angle \\(A\\) has length {a}, "
        f"the side adjacent to angle \\(A\\) has length {b}, and the hypotenuse has length {c}. "
        f"What is the value of \\(\\{which} A\\)?"
    )
    # fix latex: \sin not \\{which}
    name = {"sin": "\\sin", "cos": "\\cos", "tan": "\\tan"}[which]
    stem = (
        f"In a right triangle, the side opposite angle \\(A\\) has length {a}, "
        f"the side adjacent to angle \\(A\\) has length {b}, and the hypotenuse has length {c}. "
        f"What is the value of \\({name} A\\)?"
    )
    ans = {"sin": Fraction(a, c), "cos": Fraction(b, c), "tan": Fraction(a, b)}[which]
    wrongs = [Fraction(b, c), Fraction(a, b), Fraction(c, a), Fraction(b, a)]
    return emit("Geometry and Trigonometry", "Trigonometry", diff, stem, ans, wrongs)


def geo_arc(diff):
    # central angle over 360 times circumference factor, ask arc length as kπ
    r = rng.choice([6, 9, 12])
    deg = rng.choice([60, 90, 120])
    # arc = (deg/360)*2πr = deg/180 * π r
    k = Fraction(deg, 180) * r
    stem = (
        f"A circle has radius {r}. What is the length of a {deg}\\(^\\circ\\) arc of the circle, "
        f"expressed as \\(k\\pi\\)? Enter the value of \\(k\\)."
    )
    return emit("Geometry and Trigonometry", "Circles", diff, stem, k, [Fraction(deg, 360), r, Fraction(deg * r, 360), 2 * r])


GENERATORS = [
    # Algebra 350
    (alg_solve_one, "Easy", 40),
    (alg_solve_one, "Medium", 35),
    (alg_solve_one, "Hard", 25),
    (alg_identity, "Medium", 12),
    (alg_identity, "Hard", 8),
    (alg_inequality, "Easy", 12),
    (alg_inequality, "Medium", 10),
    (alg_inequality, "Hard", 8),
    (alg_point_ineq, "Medium", 10),
    (alg_slope, "Easy", 22),
    (alg_slope, "Medium", 20),
    (alg_slope, "Hard", 18),
    (alg_interpret, "Easy", 12),
    (alg_interpret, "Medium", 13),
    (alg_system, "Easy", 20),
    (alg_system, "Medium", 20),
    (alg_system, "Hard", 15),
    (alg_system_count, "Medium", 10),
    (alg_isolate, "Easy", 15),
    (alg_isolate, "Medium", 15),
    (alg_isolate, "Hard", 10),
    # Advanced 350
    (adv_expand, "Easy", 25),
    (adv_expand, "Medium", 25),
    (adv_quadratic, "Easy", 25),
    (adv_quadratic, "Medium", 25),
    (adv_quadratic, "Hard", 20),
    (adv_exp, "Easy", 15),
    (adv_exp, "Medium", 15),
    (adv_exp, "Hard", 10),
    (adv_exponents, "Easy", 12),
    (adv_exponents, "Medium", 13),
    (adv_function, "Easy", 20),
    (adv_function, "Medium", 20),
    (adv_function, "Hard", 15),
    (adv_radical, "Medium", 15),
    (adv_radical, "Hard", 10),
    (adv_rational, "Medium", 15),
    (adv_rational, "Hard", 15),
    (adv_nonlinear_system, "Medium", 12),
    (adv_nonlinear_system, "Hard", 8),
    (adv_discriminant, "Medium", 15),
    (adv_structure, "Hard", 20),
    # PSDA 150
    (ps_ratio, "Easy", 10),
    (ps_ratio, "Medium", 10),
    (ps_ratio, "Hard", 5),
    (ps_unit, "Easy", 8),
    (ps_percent, "Easy", 12),
    (ps_percent, "Medium", 10),
    (ps_percent, "Hard", 8),
    (ps_mean, "Easy", 6),
    (ps_mean, "Medium", 6),
    (ps_median, "Easy", 8),
    (ps_median, "Medium", 6),
    (ps_prob, "Easy", 8),
    (ps_prob, "Medium", 6),
    (ps_prob, "Hard", 6),
    (ps_table, "Medium", 8),
    (ps_table, "Hard", 6),
    (ps_predict, "Easy", 6),
    (ps_predict, "Medium", 6),
    (ps_margin, "Medium", 6),
    (ps_margin, "Hard", 4),
    (ps_study, "Medium", 5),
    # Geometry 150
    (geo_angles, "Easy", 12),
    (geo_angles, "Medium", 10),
    (geo_angles, "Hard", 6),
    (geo_pythag, "Easy", 8),
    (geo_pythag, "Medium", 5),
    (geo_pythag, "Hard", 4),
    (geo_special, "Medium", 8),
    (geo_special, "Hard", 6),
    (geo_area, "Easy", 10),
    (geo_area, "Medium", 8),
    (geo_volume, "Easy", 8),
    (geo_volume, "Medium", 6),
    (geo_volume, "Hard", 8),
    (geo_circle, "Easy", 6),
    (geo_circle, "Medium", 8),
    (geo_circle, "Hard", 6),
    (geo_similar, "Medium", 8),
    (geo_similar, "Hard", 6),
    (geo_trig, "Easy", 6),
    (geo_trig, "Medium", 6),
    (geo_trig, "Hard", 5),
]


def build():
    items = []
    seen = set()
    for fn, diff, count in GENERATORS:
        made = 0
        tries = 0
        while made < count:
            tries += 1
            if tries > count * 40:
                raise RuntimeError(f"Could not fill {fn.__name__} {diff}: {made}/{count}")
            item = fn(diff)
            if item.stem in seen:
                continue
            if item.kind == "MC":
                if len(item.choices) != 4 or len(set(item.choices)) != 4:
                    continue
                if item.key not in "ABCD":
                    continue
            else:
                if len(item.key) > 6:
                    continue
            seen.add(item.stem)
            items.append(item)
            made += 1
    return items


def latex_escape_check(s):
    if s.count("{") != s.count("}"):
        raise ValueError("brace mismatch: " + s[:180])


def write_tex(items, path):
    for it in items:
        latex_escape_check(it.stem)
        if it.choices:
            for c in it.choices:
                latex_escape_check(c)
    lines = []
    a = lines.append
    a(r"\documentclass[10pt]{article}")
    a(r"\usepackage[margin=0.72in]{geometry}")
    a(r"\usepackage{lmodern,microtype,amsmath,amssymb,enumitem,fancyhdr,xcolor}")
    a(r"\usepackage[T1]{fontenc}")
    a(r"\definecolor{navy}{HTML}{16324F}")
    a(r"\definecolor{teal}{HTML}{0E7C7B}")
    a(r"\pagestyle{fancy}")
    a(r"\fancyhf{}")
    a(r"\fancyhead[L]{\sffamily\color{navy} Digital SAT Math Practice}")
    a(r"\fancyhead[R]{\sffamily\color{teal} 1{,}000 original items}")
    a(r"\fancyfoot[C]{\thepage}")
    a(r"\setlength{\parindent}{0pt}")
    a(r"\setlist[enumerate]{leftmargin=1.6em,itemsep=0.15em,topsep=0.25em}")
    a(r"\begin{document}")
    a(r"\thispagestyle{empty}")
    a(r"\vspace*{1.2cm}")
    a(r"{\sffamily\color{teal}\large Mathematics}")
    a(r"\par\vspace{0.4em}")
    a(r"{\sffamily\bfseries\color{navy}\Huge 1{,}000 Digital SAT Math Questions}")
    a(r"\par\vspace{0.8em}")
    a(r"{\large Practice items matched to the published Digital SAT math blueprint.}")
    a(r"\par\vspace{1em}")
    a(r"\begin{tabular}{@{}ll@{}}")
    a(r"\textbf{Algebra} & 350 questions, about 35\% \\")
    a(r"\textbf{Advanced Math} & 350 questions, about 35\% \\")
    a(r"\textbf{Problem-Solving and Data Analysis} & 150 questions, about 15\% \\")
    a(r"\textbf{Geometry and Trigonometry} & 150 questions, about 15\% \\")
    a(r"\end{tabular}")
    a(r"\par\vspace{0.8em}")
    n_mc = sum(1 for it in items if it.kind == "MC")
    n_spr = sum(1 for it in items if it.kind == "SPR")
    a(rf"Of these 1{{,}}000 items, {n_mc} are four-option multiple choice and {n_spr} are student-produced responses, the kind you type as a number. On the Digital SAT itself, about 75\% are multiple choice and about 25\% are student-produced responses. Each item is marked Easy, Medium, or Hard so the bank covers the range from an easier module through a harder second module.")
    a(r"\par\vspace{0.6em}")
    a(r"These are original practice items, not College Board questions, and this is not an official SAT test. A calculator is appropriate throughout, as on the Digital SAT. For student-produced responses, enter an integer or a fraction in lowest terms. Do not use a mixed number. Geometry items use the standard reference facts: triangle angle sum \(180^\circ\), a circle has \(360^\circ\), \(c=2\pi r\), \(A=\pi r^2\), rectangle area \(\ell w\), triangle area \(\frac12 bh\), Pythagorean theorem, \(30^\circ\)-\(60^\circ\)-\(90^\circ\) and \(45^\circ\)-\(45^\circ\)-\(90^\circ\) side ratios, cylinder volume \(\pi r^2 h\), and right-triangle trigonometry.")
    a(r"\par\vspace{0.7em}")
    a(r"The answer key begins after question 1000.")
    a(r"\clearpage")
    current = None
    for i, it in enumerate(items, 1):
        if it.domain != current:
            current = it.domain
            a(r"\clearpage")
            a(rf"\section*{{\sffamily\color{{navy}}{current}}}")
        a(r"\noindent\begin{minipage}{\textwidth}")
        a(rf"\textbf{{{i}.}}\ \textsf{{\color{{teal}}{it.skill} $\cdot$ {it.difficulty} $\cdot$ {it.kind}}}")
        a(rf"\par\vspace{{0.2em}}{it.stem}")
        if it.kind == "MC":
            a(r"\begin{enumerate}[label=\textbf{\Alph*.}]")
            for c in it.choices:
                if "\\(" in c or (any(ch.isalpha() for ch in c) and "frac" not in c):
                    a(rf"\item {c}")
                else:
                    a(rf"\item \({c}\)")
            a(r"\end{enumerate}")
        a(r"\end{minipage}")
        a(r"\par\vspace{0.9em}")
    a(r"\clearpage")
    a(r"\section*{\sffamily\color{navy}Answer key}")
    a(r"Student-produced responses are printed as the number to enter. Multiple-choice answers are the letter.")
    a(r"\begin{multicols}{5}")
    a(r"\scriptsize\sffamily")
    a(r"\begin{enumerate}[label=\arabic*.,itemsep=0.1em,leftmargin=1.5em]")
    # multicol package needed
    for it in items:
        a(rf"\item {it.key}")
    a(r"\end{enumerate}")
    a(r"\end{multicols}")
    a(r"\end{document}")
    text = "\n".join(lines)
    # I used multicols without adding package. Fix.
    text = text.replace(
        r"\usepackage{lmodern,microtype,amsmath,amssymb,enumitem,fancyhdr,xcolor}",
        r"\usepackage{lmodern,microtype,amsmath,amssymb,enumitem,fancyhdr,xcolor,multicol}",
    )
    path.write_text(text)
    return text


def main():
    items = build()
    assert len(items) == 1000, len(items)
    from collections import Counter
    domains = Counter(it.domain for it in items)
    kinds = Counter(it.kind for it in items)
    diffs = Counter(it.difficulty for it in items)
    print("domains", dict(domains))
    print("kinds", dict(kinds))
    print("diffs", dict(diffs))
    assert domains["Algebra"] == 350
    assert domains["Advanced Math"] == 350
    assert domains["Problem-Solving and Data Analysis"] == 150
    assert domains["Geometry and Trigonometry"] == 150
    out = __import__("pathlib").Path("/workspace/public/maths/sat/Digital_SAT_Math_1000.tex")
    write_tex(items, out)
    # sample
    for idx in (0, 17, 80, 200, 360, 520, 700, 860, 940):
        it = items[idx]
        print("---", idx + 1, it.domain, it.difficulty, it.kind, "KEY", it.key)
        print(it.stem[:240])
        if it.choices:
            print(" | ".join(it.choices))
    print("tex bytes", out.stat().st_size)


if __name__ == "__main__":
    main()
