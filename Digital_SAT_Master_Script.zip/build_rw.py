#!/usr/bin/env python3
"""1,000 original Digital SAT Reading and Writing practice items."""

import random
from collections import Counter

SEED = 20261001
QUOTAS = [
    ("Craft and Structure", "Words in Context", 160),
    ("Craft and Structure", "Text Structure and Purpose", 85),
    ("Craft and Structure", "Cross-Text Connections", 35),
    ("Information and Ideas", "Central Ideas and Details", 60),
    ("Information and Ideas", "Command of Evidence (Textual)", 75),
    ("Information and Ideas", "Command of Evidence (Quantitative)", 70),
    ("Information and Ideas", "Inferences", 55),
    ("Standard English Conventions", "Boundaries", 140),
    ("Standard English Conventions", "Form, Structure, and Sense", 120),
    ("Expression of Ideas", "Rhetorical Synthesis", 110),
    ("Expression of Ideas", "Transitions", 90),
]

STEMS = {
    "Words in Context": "Which choice completes the text with the most logical and precise word or phrase?",
    "Boundaries": "Which choice completes the text so that it conforms to the conventions of Standard English?",
    "Form, Structure, and Sense": "Which choice completes the text so that it conforms to the conventions of Standard English?",
    "Transitions": "Which choice completes the text with the most logical transition?",
    "Rhetorical Synthesis": "Which choice most effectively uses relevant information from the notes to accomplish this goal?",
}


def Q(domain, skill, difficulty, parts, stem, choices, correct, family=""):
    assert len(choices) == 4, (skill, choices)
    assert correct in choices, (skill, correct, choices)
    assert len(set(choices)) == 4, (skill, choices)
    return {
        "domain": domain,
        "skill": skill,
        "difficulty": difficulty,
        "parts": parts,
        "stem": stem,
        "choices": list(choices),
        "correct": correct,
        "family": family,
    }


def last_name(person):
    return person.split()[-1]


def take(items, n, label):
    if len(items) < n:
        raise SystemExit(f"{label}: have {len(items)}, need {n}")
    return items[:n]


# ---------------------------------------------------------------------------
# Boundaries
# ---------------------------------------------------------------------------

FANBOYS = [
    ("The harbor froze overnight", "ferry service was suspended until noon", "so"),
    ("Lina revised the model twice", "the same error remained", "but"),
    ("The trail was steep", "the crew kept the heavier packs for the last mile", "yet"),
    ("Jonah finished the glaze", "his sister prepared the kiln", "and"),
    ("The committee could delay the vote", "it could adopt the draft as written", "or"),
    ("The archive closed at four", "the reading room stayed open until six", "but"),
    ("Rain soaked the clay court", "the match was moved indoors", "so"),
    ("The first sample was contaminated", "the second sample was usable", "but"),
    ("Maya copied the figures", "Omar checked each total against the log", "and"),
    ("The road was closed for repairs", "drivers followed the river route", "so"),
    ("The poem is brief", "it took the class a full period to unpack the last image", "yet"),
    ("Students may revise the essay", "they may submit the draft unchanged", "or"),
    ("The lamp flickered", "the electrician replaced the wiring that afternoon", "so"),
    ("The mural was finished", "the wall still needed a sealant", "but"),
    ("Priya tuned the violin", "her accompanist adjusted the piano bench", "and"),
    ("The pond had frozen", "the ducks remained near the open inlet", "yet"),
    ("The shop can order the part", "the mechanic can adapt a similar one", "or"),
    ("Clouds covered the ridge", "the survey team postponed the photographs", "so"),
    ("The novel sold steadily", "the author declined every interview", "but"),
    ("The baker heated the oven", "the apprentice weighed the flour", "and"),
    ("The instructions were simple", "several teams still assembled the frame backward", "yet"),
    ("Visitors may tour the garden", "they may remain in the gallery", "or"),
    ("The battery drained quickly", "the crew switched on the spare pack", "so"),
    ("The painting looked dark in the crate", "it brightened after cleaning", "but"),
    ("Elena labeled the jars", "Chris entered the dates in the notebook", "and"),
    ("The speaker apologized for the delay", "the audience stayed in their seats", "and"),
    ("The soil was dry", "the seedlings wilted by noon", "so"),
    ("The map was old", "it still showed the turn the crew needed", "yet"),
]

RELATED = [
    ("Jonah collects postage stamps", "his sister collects coins"),
    ("The museum opens at ten", "the library opens at noon"),
    ("Rosa studies local soils", "her brother studies coastal birds"),
    ("The north gallery displays portraits", "the south gallery displays landscapes"),
    ("This bus stops at the campus gate", "the express bus stops at the station"),
    ("The red notebook holds the sketches", "the blue notebook holds the measurements"),
    ("Tuesday's lecture is on glaciers", "Thursday's lecture is on rivers"),
    ("The choir rehearses in the chapel", "the orchestra rehearses in the hall"),
    ("Plot A was planted with wheat", "plot B was planted with barley"),
    ("The first letter is dated 1864", "the second letter is dated 1867"),
    ("Lane keeps the attendance log", "Pat keeps the equipment log"),
    ("The upstairs lab stores the microscopes", "the downstairs lab stores the samples"),
    ("One path follows the creek", "the other path follows the fence"),
    ("The morning paper printed the speech", "the evening paper printed the replies"),
    ("Table 1 lists the sites", "table 2 lists the dates"),
    ("The poet lived in Lisbon", "the translator lived in Porto"),
    ("Group 1 read the article silently", "group 2 heard the article read aloud"),
    ("The east window faces the courtyard", "the west window faces the street"),
    ("Camila coaches the novice team", "Luis coaches the advanced team"),
    ("The 2018 survey covered four schools", "the 2022 survey covered six schools"),
    ("The clay bowls were made in the spring", "the glazed tiles were made in the fall"),
    ("Alicia wrote the introduction", "Ben wrote the conclusion"),
    ("The hawks nested on the cliff", "the herons nested in the marsh"),
    ("Shift one ends at three", "shift two ends at eleven"),
]

THEREFORE = [
    ("The kiln was heated too quickly", "the glaze blistered"),
    ("The trail markers had been removed", "the hikers lost the route"),
    ("Salt had been left on the steel", "the tools rusted"),
    ("The room was not ventilated", "the fumes lingered"),
    ("The seedlings received no water for a week", "most of them wilted"),
    ("The alarm was never set", "the gate stayed open all night"),
    ("A page was missing from the score", "the quartet stopped in the third movement"),
    ("The filter had not been cleaned", "the pump overheated"),
    ("The invitation went out late", "several guests never arrived"),
    ("The lens was cracked", "the photographs came out blurred"),
    ("Ice had formed on the step", "the entrance was closed"),
]

HOWEVER = [
    ("The trail is steep at the start", "the last mile is nearly flat"),
    ("The first draft was disorganized", "the revision was clear"),
    ("The sky looked clear at dawn", "rain began before noon"),
    ("The device is small", "it stores a large archive"),
    ("The recipe looks complicated", "it uses only four ingredients"),
    ("Attendance fell in March", "it rose again in April"),
    ("The outer wall is plain", "the interior is richly painted"),
    ("The sample was tiny", "the pattern in it was consistent"),
    ("The novel begins quietly", "its final chapter is abrupt"),
    ("The bridge looks delicate", "it carries heavy traffic every day"),
    ("The instructions filled one page", "the assembly still took an hour"),
]

APPOSITIVES = [
    ("The violin", "a gift from her aunt", "was stored in a felt case"),
    ("Ada Lovelace", "a mathematician in Victorian London", "wrote notes on Babbage's engine"),
    ("The courtyard", "once a stable yard", "is now a reading garden"),
    ("Mr. Okonkwo", "the night archivist", "keeps the key to the stacks"),
    ("The sycamore", "the oldest tree on the block", "shades the entire porch"),
    ("Lake Meret", "a reservoir built in 1954", "supplies the town's drinking water"),
    ("Captain Ruiz", "commander of the second expedition", "kept a daily log"),
    ("The pamphlet", "printed on cheap paper", "was handed out at the station"),
    ("Dr. Shah", "the only surgeon on duty", "finished the operation after midnight"),
    ("The bridge", "designed by a student team", "won the city design prize"),
    ("Nova Cafe", "a former ticket booth", "sits beside the theater door"),
    ("The chronicle", "copied by hand in 1420", "names every donor"),
    ("Professor Nguyen", "chair of the history department", "introduced the speaker"),
    ("The kiln", "built of local brick", "stands behind the studio"),
    ("Ellis Island", "a major immigration station", "processed millions of arrivals"),
    ("The score", "marked in pencil", "showed the conductor's cuts"),
    ("Harlem", "the neighborhood where she grew up", "appears in nearly every poem"),
    ("The compass", "inherited from a ship's pilot", "still points true"),
    ("June 6, 1944", "the date of the Normandy landings", "is underlined in the diary"),
    ("The mosaic", "assembled from broken tiles", "covers the station wall"),
]

RESTRICTIVE = [
    ("Paintings that were water-damaged were removed", "Paintings ________ were removed from the exhibit, while the undamaged ones stayed.",
     "that were water-damaged", ", which were water-damaged,", ", that were water-damaged,", "which were water-damaged"),
    ("Students who submit the form by Friday will be registered", "________ will be registered, but those who miss the deadline will not.",
     "Students who submit the form by Friday", "Students, who submit the form by Friday,", "Students who, submit the form by Friday", "Students, that submit the form by Friday,"),
    ("Tools that were left outside rusted", "________ rusted, although the tools stored in the shed did not.",
     "Tools that were left outside", "Tools, which were left outside,", "Tools, that were left outside,", "Tools which, were left outside"),
    ("Visitors who have tickets may enter", "________ may enter before noon, and visitors without tickets must wait.",
     "Visitors who have tickets", "Visitors, who have tickets,", "Visitors, that have tickets,", "Visitors who, have tickets"),
    ("Samples that failed the first test were discarded", "________ were discarded, but the samples that passed were kept.",
     "Samples that failed the first test", "Samples, which failed the first test,", "Samples, that failed the first test,", "The samples, failing the first test,"),
    ("Houses that sit on the flood plain were elevated", "________ were elevated, whereas the houses on higher ground were left as they stood.",
     "Houses that sit on the flood plain", "Houses, which sit on the flood plain,", "Houses, that sit on the flood plain,", "Houses which sit, on the flood plain"),
    ("Players who arrived late missed the briefing", "________ missed the briefing, while the players who arrived on time attended it.",
     "Players who arrived late", "Players, who arrived late,", "Players, that arrived late,", "Players who, arrived late"),
    ("Letters that mention the strike were filed separately", "________ were filed separately from the letters that never mention it.",
     "Letters that mention the strike", "Letters, which mention the strike,", "Letters, that mention the strike,", "Letters which, mention the strike"),
    ("Routes that cross the marsh are closed", "________ are closed after heavy rain, but the ridge route stays open.",
     "Routes that cross the marsh", "Routes, which cross the marsh,", "Routes, that cross the marsh,", "Routes which cross, the marsh"),
    ("Volunteers who speak Spanish staffed the desk", "________ staffed the desk, and the other volunteers worked in the storeroom.",
     "Volunteers who speak Spanish", "Volunteers, who speak Spanish,", "Volunteers, that speak Spanish,", "Volunteers who, speak Spanish"),
    ("Files that lack a date were set aside", "________ were set aside so the archivist could date them later.",
     "Files that lack a date", "Files, which lack a date,", "Files, that lack a date,", "Files which, lack a date"),
    ("Bikes that have lights may be ridden after dusk", "________ may be ridden after dusk, unlike bikes without lights.",
     "Bikes that have lights", "Bikes, which have lights,", "Bikes, that have lights,", "Bikes which, have lights"),
    ("Plots that received compost produced more seedlings", "________ produced more seedlings than the plots that received none.",
     "Plots that received compost", "Plots, which received compost,", "Plots, that received compost,", "Plots which received, compost"),
    ("Speeches that ran past the limit were cut", "________ were cut, while the shorter speeches were left intact.",
     "Speeches that ran past the limit", "Speeches, which ran past the limit,", "Speeches, that ran past the limit,", "Speeches which, ran past the limit"),
    ("Jars that cracked in the kiln were recycled", "________ were recycled, and the intact jars were sold.",
     "Jars that cracked in the kiln", "Jars, which cracked in the kiln,", "Jars, that cracked in the kiln,", "Jars which, cracked in the kiln"),
    ("Passengers who missed the call remained on the platform", "________ remained on the platform until the next train.",
     "Passengers who missed the call", "Passengers, who missed the call,", "Passengers, that missed the call,", "Passengers who, missed the call"),
]

COLON_LISTS = [
    ("The field kit contained three tools", "a wrench, a file, and a clamp"),
    ("Mara packed only what she needed", "a pencil, a notebook, and a map"),
    ("The recipe calls for three spices", "cumin, coriander, and cinnamon"),
    ("The scholarship covers three costs", "tuition, housing, and books"),
    ("The display features four objects", "a compass, a sextant, a logbook, and a flag"),
    ("The chorus will sing three songs", "a hymn, a work song, and a lullaby"),
    ("The grant supports two activities", "fieldwork and laboratory analysis"),
    ("The box held the entire correspondence", "letters, postcards, and telegrams"),
    ("The course has one prerequisite", "a passing grade in introductory biology"),
    ("The mural uses three pigments", "ochre, indigo, and chalk white"),
    ("The agreement set two conditions", "public access and annual maintenance"),
    ("The sampler stitched three motifs", "a vine, a star, and a small house"),
    ("The new policy changed one rule", "the deadline for senior projects"),
    ("The traveler carried two books", "a phrase book and a slim book of poems"),
    ("The experiment varied one factor", "the amount of light"),
    ("The memorial lists three names", "Alvarez, Chen, and Brooks"),
]

POSSESSIVES = [
    ("Both painters contributed to the show. The exhibit featured the two ________ sketches, one from each painter.",
     "artists'", "artist's", "artists", "artists's"),
    ("One chemist kept a private record. She stored the reaction in the ________ notebook.",
     "chemist's", "chemists", "chemists'", "chemists's"),
    ("The three students turned in a single shared paper. The teacher graded the ________ report before noon.",
     "students'", "student's", "students", "students's"),
    ("Each child wrote a separate card. The teacher hung every ________ card on the wall.",
     "child's", "children", "childs", "childrens'"),
    ("Two cities issued a joint statement. The ________ statement was read at both city halls.",
     "cities'", "city's", "cities", "citys'"),
    ("The team of one coach prepared a plan. The ________ plan filled a single page.",
     "coach's", "coaches'", "coaches", "coach"),
    ("Several workers left their helmets in a row. The supervisor collected the ________ helmets after the shift.",
     "workers'", "worker's", "workers", "workers's"),
    ("One company owned the warehouse. The sign on the door showed the ________ name.",
     "company's", "companies", "companies'", "companys'"),
    ("The two poets read from a book they wrote together. Listeners praised the ________ collaboration.",
     "poets'", "poet's", "poets", "poets's"),
    ("A single runner dropped a shoe. A volunteer returned the ________ shoe to the finish line.",
     "runner's", "runners", "runners'", "runners's"),
    ("All of the teachers shared one lounge. A notice on the board listed the ________ meeting time.",
     "teachers'", "teacher's", "teachers", "teachers's"),
    ("One family donated the piano. A small plaque thanks the ________ gift.",
     "family's", "families", "families'", "familys"),
    ("The two editors marked the same page. The ________ notes appear in the margin.",
     "editors'", "editor's", "editors", "editors's"),
    ("One athlete set the record. The newspaper printed the ________ time on the front page.",
     "athlete's", "athletes", "athletes'", "athletes's"),
]


DASHES = [
    ("The kiln", "an old brick model", "was heated too quickly"),
    ("The archive", "a former schoolhouse", "opens only on Thursdays"),
    ("Her violin", "a gift from her uncle", "needed a new bridge"),
    ("The harbor", "once a fishing port", "now handles mostly ferries"),
    ("The essay", "her first published piece", "appeared in the spring issue"),
    ("The trail", "a former rail bed", "stays muddy after rain"),
    ("The clock", "stopped since April", "was left on the mantel"),
    ("The novel", "set in a single afternoon", "ends before supper"),
    ("The lab", "two rooms above the shop", "shares a sink with the bakery"),
    ("The mural", "painted in 1938", "covers the east wall"),
    ("The recipe", "copied from a torn card", "calls for cold butter"),
    ("The footbridge", "closed since the flood", "still appears on the old map"),
    ("The garden", "once a parking lot", "now grows tomatoes"),
    ("The letter", "written in pencil", "names the missing date"),
]

PREDICATES = [
    ("Jonah finished the glaze", "checked the kiln temperature"),
    ("The archivist opened the folder", "copied the date onto a card"),
    ("Lina revised the caption", "sent the file to the printer"),
    ("The crew measured the wall", "marked the studs with chalk"),
    ("Maya tuned the violin", "rosined the bow"),
    ("The baker scored the loaf", "slid it onto the stone"),
    ("Omar printed the chart", "taped it beside the door"),
    ("The guide filled the bottles", "handed one to each hiker"),
    ("The editor cut the last line", "read the paragraph aloud"),
    ("The nurse logged the dose", "initialed the chart"),
    ("The mechanic tightened the bolt", "wiped oil off the rim"),
    ("The student underlined the claim", "wrote a question in the margin"),
    ("The gardener mulched the beds", "coiled the hose"),
    ("The clerk stamped the form", "returned the copy"),
]

SV_GAPS = [
    ("The bundle of maps", "is", "stored in the cedar chest"),
    ("The list of guests", "is", "posted beside the kiln"),
    ("Each of the swimmers", "has", "a spare cap in the bag"),
    ("The collection of maps", "is", "kept in one drawer"),
    ("Neither of the gates", "is", "open after dusk"),
    ("The pile of invoices", "has", "grown taller this week"),
    ("Everybody on the two crews", "has", "the revised schedule"),
    ("The fleet of vans", "is", "parked behind the barn"),
    ("One of the hinges", "is", "still missing from the tin"),
    ("The series of workshops", "begins", "next Monday in Room B"),
    ("The pair of boots", "was", "found under the bench"),
    ("Not one of the fuses", "works", "in this string of lights"),
    ("The news about the trains", "was", "posted before dawn"),
    ("A group of neighbors", "is", "meeting at the library"),
]


def boundaries():
    out = []
    diff_cycle = ["Easy", "Medium", "Hard"]
    for i, (c1, c2, conj) in enumerate(FANBOYS):
        choices = [f", {conj} ", f" {conj} ", ", ", f"; {conj} "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", diff_cycle[i % 3],
            [f"{c1}________{c2}."],
            STEMS["Boundaries"],
            choices, f", {conj} ",
            family="comma and a coordinating conjunction",
        ))
    for i, (c1, c2) in enumerate(RELATED):
        choices = ["; ", ", ", ": ", " or "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", diff_cycle[i % 3],
            [f"{c1}________{c2}."],
            STEMS["Boundaries"],
            choices, "; ",
            family="semicolon between independent clauses",
        ))
    for i, (c1, c2) in enumerate(THEREFORE):
        choices = ["; therefore, ", ", therefore, ", "; therefore ", " therefore, "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Medium" if i % 2 == 0 else "Hard",
            [f"{c1}________{c2}."],
            STEMS["Boundaries"],
            choices, "; therefore, ",
            family="semicolon with therefore",
        ))
    for i, (c1, c2) in enumerate(HOWEVER):
        choices = ["; however, ", ", however, ", "; however ", " however, "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Medium" if i % 2 == 0 else "Hard",
            [f"{c1}________{c2}."],
            STEMS["Boundaries"],
            choices, "; however, ",
            family="semicolon with however",
        ))
    for i, (noun, extra, rest) in enumerate(APPOSITIVES):
        shown = [f", {extra}, ", f" {extra} ", f", {extra} ", f" {extra}, "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Medium" if i % 2 == 0 else "Hard",
            [f"{noun}________{rest}."],
            STEMS["Boundaries"],
            shown, shown[0],
            family="commas around a nonrestrictive phrase",
        ))
    for i, (why, stimulus, a, b, c, d) in enumerate(RESTRICTIVE):
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Hard",
            [stimulus],
            STEMS["Boundaries"],
            [a, b, c, d], a,
            family="restrictive information, no extra commas",
        ))
    for i, (lead, listing) in enumerate(COLON_LISTS):
        shown = [": ", "; ", ", and ", ". "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Medium",
            [f"{lead}________{listing}."],
            STEMS["Boundaries"],
            shown, ": ",
            family="colon before a list",
        ))
    for i, (stimulus, a, b, c, d) in enumerate(POSSESSIVES):
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Hard" if i % 2 else "Medium",
            [stimulus],
            STEMS["Boundaries"],
            [a, b, c, d], a,
            family="possessive form",
        ))
    for i, (noun, extra, rest) in enumerate(DASHES):
        shown = [f"--- {extra} ---", f"--- {extra}", f"{extra} ---", f"--- {extra},"]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Hard" if i % 2 else "Medium",
            [f"{noun} ________ {rest}."],
            STEMS["Boundaries"],
            shown, shown[0],
            family="dashes around extra information",
        ))
    for i, (c1, c2) in enumerate(PREDICATES):
        choices = [" and ", ", and ", "; ", ", "]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Medium" if i % 2 == 0 else "Hard",
            [f"{c1}________{c2}."],
            STEMS["Boundaries"],
            choices, " and ",
            family="no comma in a compound predicate",
        ))
    for i, (subj, verb, rest) in enumerate(SV_GAPS):
        choices = [verb, f", {verb}", f"{verb},", f"; {verb}"]
        out.append(Q(
            "Standard English Conventions", "Boundaries", "Easy" if i % 2 == 0 else "Medium",
            [f"{subj} ________ {rest}."],
            STEMS["Boundaries"],
            choices, verb,
            family="no comma between subject and verb",
        ))
    return out


# ---------------------------------------------------------------------------
# Form, structure, and sense
# ---------------------------------------------------------------------------

SVA = [
    ("The bundle of letters", "is", "Today, the bundle of letters ________ stored in the attic."),
    ("The list of supplies", "is", "Today, the list of supplies ________ posted on the door."),
    ("Each of the players", "has", "Each of the players ________ brought a spare jersey."),
    ("Every one of the samples", "was", "Yesterday, every one of the samples ________ labeled before noon."),
    ("The collection of essays", "is", "The collection of essays ________ kept in a single volume."),
    ("Neither of the routes", "is", "Neither of the routes ________ open after dark."),
    ("The box of nails", "was", "The box of nails ________ left on the bench yesterday."),
    ("Everybody in the two sections", "has", "Everybody in the two sections ________ received the new schedule."),
    ("The set of instructions", "is", "The set of instructions ________ taped inside the lid."),
    ("Each of the paintings", "was", "Each of the paintings ________ photographed last week."),
    ("The row of houses", "was", "In 1920 the row of houses ________ painted the same color."),
    ("One of the gears", "is", "One of the gears ________ still missing from the box."),
    ("The stack of reports", "has", "The stack of reports ________ grown taller this month."),
    ("Every specimen in the drawers", "was", "Every specimen in the drawers ________ checked twice."),
    ("The series of lectures", "begins", "The series of lectures ________ next Monday."),
    ("Nobody among the finalists", "was", "Nobody among the finalists ________ told the result early."),
    ("The bunch of keys", "is", "The bunch of keys ________ hanging by the side door."),
    ("Each of the chapters", "has", "Each of the chapters ________ been revised at least once."),
    ("The fleet of buses", "is", "The fleet of buses ________ parked behind the station tonight."),
    ("Half of the cake", "is", "Half of the cake ________ still on the plate."),
    ("The number of applicants", "has", "The number of applicants ________ increased this year."),
    ("A group of friends", "is", "A group of friends ________ meeting at the library today."),
    ("The pair of gloves", "was", "The pair of gloves ________ found under the seat."),
    ("Mathematics", "is", "Mathematics ________ required for the engineering major."),
    ("The news about the flights", "was", "The news about the flights ________ posted this morning."),
    ("Two-thirds of the pie", "remains", "Two-thirds of the pie ________ in the tin."),
    ("The committee of students", "meets", "The committee of students ________ every Thursday."),
    ("Not one of the bulbs", "works", "Not one of the bulbs ________ in this string."),
]

NEITHER = [
    ("Yesterday, neither the lead editor nor the interns ________ aware of the missing caption.", "were", ["was", "is", "are"]),
    ("Yesterday, neither the interns nor the lead editor ________ available for the interview.", "was", ["were", "are", "have been"]),
    ("Last night, neither the coach nor the players ________ ready when the bus arrived.", "were", ["was", "is", "has been"]),
    ("Last night, neither the players nor the coach ________ willing to cancel the trip.", "was", ["were", "are", "be"]),
    ("In 2019, neither the mayor nor the council members ________ present at the opening.", "were", ["was", "is", "are"]),
    ("In 2019, neither the council members nor the mayor ________ prepared to sign the order.", "was", ["were", "are", "have been"]),
    ("This morning, either the interns or the director ________ answering the main phone.", "is", ["are", "were", "have been"]),
    ("This morning, either the director or the interns ________ sorting the mail.", "are", ["is", "was", "has been"]),
    ("At noon, neither the violin nor the flutes ________ in tune.", "were", ["was", "is", "are"]),
    ("At noon, neither the flutes nor the violin ________ ready for the downbeat.", "was", ["were", "are", "been"]),
    ("Last spring, neither the oak nor the elms ________ pruned.", "were", ["was", "is", "are"]),
    ("Last spring, neither the elms nor the oak ________ marked on the map.", "was", ["were", "are", "have been"]),
    ("Today, either the chart or the photographs ________ needed in the meeting.", "are", ["is", "was", "has been"]),
    ("Today, either the photographs or the chart ________ sufficient for the briefing.", "is", ["are", "were", "have been"]),
]

ITS = [
    ("The novel lost ________ dust jacket on the way to the archive.", "its", ["it's", "their", "theirs"]),
    ("The laptop lost ________ charge before the presentation ended.", "its", ["it's", "their", "theirs"]),
    ("The city published ________ budget on the public website.", "its", ["it's", "their", "theirs"]),
    ("The company changed ________ logo after the merger.", "its", ["it's", "their", "theirs"]),
    ("The poem earned ________ place in the anthology.", "its", ["it's", "their", "theirs"]),
    ("The telescope kept ________ focus throughout the night.", "its", ["it's", "their", "theirs"]),
    ("The university updated ________ catalog in August.", "its", ["it's", "their", "theirs"]),
    ("The river altered ________ course after the flood.", "its", ["it's", "their", "theirs"]),
    ("The orchestra postponed ________ opening concert.", "its", ["it's", "their", "theirs"]),
    ("The phone dropped ________ signal inside the tunnel.", "its", ["it's", "their", "theirs"]),
    ("The museum expanded ________ hours on Sundays.", "its", ["it's", "their", "theirs"]),
    ("The engine lost ________ power on the hill.", "its", ["it's", "their", "theirs"]),
    ("The newspaper corrected ________ headline the next day.", "its", ["it's", "their", "theirs"]),
    ("The tree shed ________ leaves earlier than usual.", "its", ["it's", "their", "theirs"]),
]

THEY = [
    ("When visitors enter the hall, ________ should leave bags at the desk.", "they", ["you", "he or she", "it"]),
    ("If the players miss the bus, ________ will have to walk to the field.", "they", ["you", "he", "it"]),
    ("After the students finish the lab, ________ must wipe the benches.", "they", ["you", "one", "it"]),
    ("Because the drivers know the route, ________ do not need a guide.", "they", ["you", "he or she", "it"]),
    ("Once the guests find their seats, ________ may open the programs.", "they", ["you", "one", "it"]),
    ("If the interns complete the count, ________ can leave at four.", "they", ["you", "he", "it"]),
    ("When the musicians reach the chorus, ________ should watch the conductor.", "they", ["you", "he or she", "it"]),
    ("After the hikers cross the bridge, ________ will see the cabin.", "they", ["you", "one", "it"]),
    ("If the authors approve the edits, ________ will sign the form.", "they", ["you", "he", "it"]),
    ("When the jurors leave the room, ________ may not discuss the case.", "they", ["you", "he or she", "it"]),
    ("Once the cooks taste the soup, ________ can adjust the salt.", "they", ["you", "one", "it"]),
    ("If the neighbors hear the alarm, ________ should call the office.", "they", ["you", "he", "it"]),
]

MODS = [
    ("________, the chemist recorded the temperature every ten minutes.",
     "Walking into the lab",
     ["Stored overnight in the freezer", "Boiling at 100 degrees Celsius", "Printed in the lab manual"]),
    ("________, the archivist noticed a date written in pencil.",
     "Opening the ledger",
     ["Written in faded ink", "Bound in cracked leather", "Shelved beside the maps"]),
    ("________, the conductor stopped the orchestra at measure 40.",
     "Hearing a wrong entrance",
     ["Tuned before the concert", "Left on the music stand", "Composed in 1891"]),
    ("________, the gardener moved the seedlings into the shade.",
     "Seeing the wilted leaves",
     ["Planted in sandy soil", "Watered only once a week", "Labeled with wooden stakes"]),
    ("________, the editor cut the last paragraph.",
     "Rereading the conclusion",
     ["Published in the morning edition", "Set in a narrow column", "Quoted by several readers"]),
    ("________, the mechanic found a loose bolt.",
     "Inspecting the wheel",
     ["Manufactured in 2014", "Covered in road dust", "Sold with a spare tire"]),
    ("________, the guide asked the group to stay on the path.",
     "Spotting a nest beside the trail",
     ["Built of cedar planks", "Marked on the older map", "Closed during winter"]),
    ("________, the student circled the unfamiliar term.",
     "Reading the assignment",
     ["Assigned on Monday", "Printed in small type", "Discussed in the previous class"]),
    ("________, the nurse checked the chart again.",
     "Entering the room",
     ["Filled out in blue ink", "Clipped to the bed rail", "Updated by the night shift"]),
    ("________, the photographer waited for the cloud to pass.",
     "Raising the camera",
     ["Loaded with fresh film", "Left on the tripod", "Purchased at a local shop"]),
    ("________, the baker reduced the oven temperature.",
     "Watching the crust darken",
     ["Mixed with cold butter", "Scored across the top", "Left to rise for an hour"]),
    ("________, the pilot requested a new altitude.",
     "Noticing ice on the wing",
     ["Filed before departure", "Printed on the flight plan", "Cleared by the tower"]),
    ("________, the librarian set the fragile book on a cushion.",
     "Removing it from the case",
     ["Printed in 1780", "Missing its title page", "Cataloged under poetry"]),
    ("________, the coach called a timeout.",
     "Seeing the players lose their positions",
     ["Drawn up during halftime", "Posted on the locker-room wall", "Used in last week's game"]),
    ("________, the researcher discarded the cracked slide.",
     "Looking through the microscope",
     ["Stored in a wooden box", "Labeled with yesterday's date", "Ordered from the supplier"]),
    ("________, the sailor secured the loose line.",
     "Feeling the deck shift",
     ["Coiled beside the mast", "Replaced last season", "Marked with a red thread"]),
]

TENSE = [
    ("In 1911 the expedition reached the pole and ________ a marker in the ice.", "left", ["leaves", "will leave", "has left"]),
    ("In 1865 the legislature passed the bill and ________ funds for the bridge.", "approved", ["approves", "will approve", "has approved"]),
    ("Yesterday the crew opened the crate and ________ each item against the list.", "checked", ["checks", "will check", "has checked"]),
    ("In 1998 the city closed the plant and ________ the site into a park.", "turned", ["turns", "will turn", "has turned"]),
    ("Last spring the class planted the garden and ________ it through June.", "tended", ["tends", "will tend", "has tended"]),
    ("In 1848 the family boarded the ship and ________ weeks later.", "arrived", ["arrives", "will arrive", "has arrived"]),
    ("Yesterday morning the baker mixed the dough and ________ it near the oven.", "set", ["sets", "will set", "has set"]),
    ("In 2004 the lab published the paper and ________ the raw data online.", "posted", ["posts", "will post", "has posted"]),
    ("Last night the actor forgot a line and ________ until the prompt came.", "paused", ["pauses", "will pause", "has paused"]),
    ("In 1972 the council banned the dye and ________ local workshops to comply.", "required", ["requires", "will require", "has required"]),
    ("Yesterday the storm knocked out the power and ________ several roads.", "flooded", ["floods", "will flood", "has flooded"]),
    ("In 1901 the inventor tested the device and ________ a patent.", "filed", ["files", "will file", "has filed"]),
    ("Last winter the pipes froze and ________ before the plumber arrived.", "burst", ["bursts", "will burst", "has burst"]),
    ("In 2016 the school adopted the policy and ________ it to every family.", "sent", ["sends", "will send", "has sent"]),
    ("Yesterday afternoon the jury returned and ________ a verdict.", "delivered", ["delivers", "will deliver", "has delivered"]),
    ("In 1888 the newspaper printed the letter and ________ an apology the next day.", "ran", ["runs", "will run", "has run"]),
]

PARALLEL = [
    ("The internship requires students to arrive on time, to keep a daily log, and ________.",
     "to submit a weekly summary", ["submitting a weekly summary", "a weekly summary is submitted", "they submit a weekly summary"]),
    ("The coach told the team to stretch, to hydrate, and ________.",
     "to listen for the whistle", ["listening for the whistle", "the whistle should be heard", "they listen for the whistle"]),
    ("Her goals are to finish the draft, to cite the sources, and ________.",
     "to cut repeated points", ["cutting repeated points", "repeated points are cut", "she cuts repeated points"]),
    ("The plan calls for raising the wall, widening the gate, and ________.",
     "replacing the roof", ["to replace the roof", "the roof is replaced", "replacement of roofing"]),
    ("A good summary identifies the claim, names the evidence, and ________.",
     "states the limit of the study", ["stating the limit of the study", "the limit is stated", "it will state the limit"]),
    ("The director asked the cast to speak clearly, to hold their marks, and ________.",
     "to watch the cues", ["watching the cues", "cues are watched", "they watched the cues"]),
    ("The manual says to disconnect the power, to wait one minute, and ________.",
     "to remove the panel", ["removing the panel", "the panel is removed", "you removed the panel"]),
    ("Successful notes are dated, legible, and ________.",
     "specific", ["they have specificity", "being specific", "with specifics included"]),
    ("The course trains students in reading closely, writing clearly, and ________.",
     "citing sources", ["to cite sources", "they cite sources", "citation of a source is done"]),
    ("The chef told the apprentices to wash the greens, to dry them, and ________.",
     "to dress the salad", ["dressing the salad", "the salad is dressed", "they dressed the salad"]),
    ("We can store the prints, lend them to the school, or ________.",
     "archive them", ["archiving them", "they are archived", "to archive them"]),
    ("The speech should open with the question, present the evidence, and ________.",
     "end with the recommendation", ["ending with the recommendation", "it ended with the recommendation", "to end with the recommendation"]),
]

WHOM = [
    ("The archivist ________ we consulted confirmed the date of the letter.", "whom", ["who", "which", "whose"]),
    ("The conductor ________ the orchestra admired kept the tempo steady.", "whom", ["who", "which", "whose"]),
    ("The mechanic ________ they trusted explained the repair in plain words.", "whom", ["who", "which", "whose"]),
    ("The guide ________ the visitors followed knew every turn of the path.", "whom", ["who", "which", "whose"]),
    ("The editor ________ the author thanked caught a repeated paragraph.", "whom", ["who", "which", "whose"]),
    ("The nurse ________ the patients recognized had worked the night shift.", "whom", ["who", "which", "whose"]),
    ("The coach ________ the players chose spoke briefly after the game.", "whom", ["who", "which", "whose"]),
    ("The witness ________ the lawyer questioned answered without notes.", "whom", ["who", "which", "whose"]),
]

WHO = [
    ("The archivist ________ cataloged the letters retired in May.", "who", ["whom", "which", "whose"]),
    ("The student ________ wrote the code presented it to the class.", "who", ["whom", "which", "whose"]),
    ("The poet ________ read last spoke about a single image.", "who", ["whom", "which", "whose"]),
    ("The ranger ________ found the nest marked it on the map.", "who", ["whom", "which", "whose"]),
    ("The delegate ________ proposed the amendment explained the change.", "who", ["whom", "which", "whose"]),
    ("The driver ________ knew the road avoided the flooded bend.", "who", ["whom", "which", "whose"]),
]

COMPOUND = [
    ("Yesterday the editor and the intern ________ the missing caption.", "revised", ["revises", "will revise", "has revised"]),
    ("Yesterday the coach and the captain ________ the lineup.", "posted", ["posts", "will post", "has posted"]),
    ("Last night the baker and the apprentice ________ the ovens.", "cleaned", ["cleans", "will clean", "has cleaned"]),
    ("In 2014 the city and the county ________ the old bridge.", "replaced", ["replaces", "will replace", "has replaced"]),
    ("Last spring the poet and the printer ________ the chapbook.", "finished", ["finishes", "will finish", "has finished"]),
    ("Yesterday the nurse and the clerk ________ the intake form.", "signed", ["signs", "will sign", "has signed"]),
    ("In 1999 the school and the library ________ the reading room.", "opened", ["opens", "will open", "has opened"]),
    ("Last winter the plumber and the carpenter ________ the leak.", "found", ["finds", "will find", "has found"]),
    ("Yesterday the guide and the ranger ________ the washed-out trail.", "closed", ["closes", "will close", "has closed"]),
    ("In 1881 the inventor and the machinist ________ the first model.", "tested", ["tests", "will test", "has tested"]),
    ("Last week the author and the editor ________ the disputed date.", "checked", ["checks", "will check", "has checked"]),
    ("Yesterday the drummer and the pianist ________ before the doors opened.", "rehearsed", ["rehearses", "will rehearse", "has rehearsed"]),
]


def form_items():
    out = []
    wrong_sva = {
        "is": ["are", "were", "have been"],
        "was": ["were", "are", "have been"],
        "has": ["have", "is", "are"],
        "begins": ["begin", "began", "have begun"],
        "meets": ["meet", "met", "have met"],
        "works": ["work", "worked", "have worked"],
        "remains": ["remain", "remained", "have remained"],
    }
    for subj, verb, stim in SVA:
        wrongs = wrong_sva[verb]
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Medium",
                     [stim], STEMS["Form, Structure, and Sense"], [verb] + wrongs, verb,
                     family="singular subject, singular verb"))
    for stim, good, bad in NEITHER:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Hard",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="verb agrees with the nearer subject"))
    for stim, good, bad in ITS:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Easy",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="its, not it's"))
    for stim, good, bad in THEY:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Medium",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="plural pronoun they"))
    for stim, good, bad in MODS:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Medium",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="modifier next to the right noun"))
    for stim, good, bad in TENSE:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Easy",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="simple past after a past marker"))
    for stim, good, bad in PARALLEL:
        diff = "Hard" if stim.startswith("The plan") or "reading closely" in stim or stim.startswith("We can") or stim.startswith("The speech") else "Medium"
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", diff,
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="parallel structure"))
    for stim, good, bad in WHOM:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Hard",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="whom as the object"))
    for stim, good, bad in WHO:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Medium",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="who as the subject"))
    for stim, good, bad in COMPOUND:
        out.append(Q("Standard English Conventions", "Form, Structure, and Sense", "Medium",
                     [stim], STEMS["Form, Structure, and Sense"], [good] + bad, good,
                     family="compound subject joined by and"))
    return out


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------

TRANS_REL = {
    "result": ["As a result", "Therefore", "Consequently", "For this reason"],
    "contrast": ["However", "Nevertheless", "By contrast", "Even so"],
    "example": ["For example", "For instance"],
    "addition": ["In addition", "Furthermore", "Moreover"],
    "concession": ["Still", "All the same", "That said", "Nonetheless"],
    "sequence": ["Then", "Next", "After that", "Subsequently"],
}

CAUSES = [
    ("The kiln was heated too quickly", "the glaze blistered and pulled away from the clay"),
    ("The soil was sandy and drained within minutes", "the tomato plants wilted the day after each watering"),
    ("The invitation was sent to an old address", "several guests never received it"),
    ("Ice covered the front step", "the building manager closed the entrance"),
    ("The musician skipped two weeks of practice", "the difficult passage fell apart at the recital"),
    ("A page was missing from the score", "the quartet stopped in the third movement"),
    ("The filter had not been changed", "the pump overheated before noon"),
    ("The seedlings were left in full sun", "their leaves scorched by midafternoon"),
    ("The alarm clock failed", "Nora missed the first train"),
    ("Salt was left on the steel tools", "they rusted over the weekend"),
    ("The trail markers had been taken down", "the afternoon group lost the route"),
    ("The room had no working fan", "the paint fumes lingered for hours"),
    ("The lens was smudged", "every photograph from that roll looked hazy"),
    ("The deadline was never announced", "half the class missed it"),
    ("The gate latch was broken", "the sheep wandered into the lane"),
    ("The backup file was never saved", "the deleted paragraph could not be recovered"),
    ("The oven ran hot", "the loaves darkened before the centers were done"),
    ("The map omitted the new exit", "drivers continued to the next town"),
    ("The citation was incomplete", "the editor could not locate the source"),
    ("The plastic cover trapped moisture", "mold appeared on the sketches"),
    ("No one refilled the lamp", "the workshop went dark at dusk"),
    ("The adhesive was applied too thinly", "the label peeled off in a day"),
    ("The speech ran long", "the next speaker lost ten minutes"),
    ("The sample was left uncapped", "the solvent evaporated overnight"),
    ("The bus left eight minutes early", "three commuters missed it"),
    ("The stitches were uneven", "the seam opened after one wash"),
    ("The password was changed without notice", "the night clerk could not log in"),
    ("Heavy rain fell on the fresh plaster", "the wall streaked before it cured"),
    ("The translator skipped the footnote", "a key date disappeared from the English text"),
    ("The battery was already weak", "the recorder stopped during the interview"),
]

CONTRASTS = [
    ("The trail is steep for the first hour", "the last mile is nearly flat"),
    ("The first draft was disorganized", "the revision was tight and clear"),
    ("The sky was clear at dawn", "rain began before noon"),
    ("The device fits in a coat pocket", "it stores several thousand photographs"),
    ("The recipe looks elaborate", "it uses only four ingredients"),
    ("Attendance at the lectures fell in March", "it rose steadily in April"),
    ("The outer wall of the chapel is plain brick", "the interior is covered with painted figures"),
    ("The sample contained only twelve households", "the same pattern appeared in every one of them"),
    ("The novel opens in a quiet kitchen", "its last chapter is loud and abrupt"),
    ("The footbridge looks delicate", "it carries buses as well as pedestrians"),
    ("The instructions filled less than a page", "assembling the frame still took an hour"),
    ("The singer was unknown in January", "by June the hall was sold out"),
    ("The chemical is harmless in dry form", "it irritates skin when mixed with water"),
    ("The town's population is small", "its archive holds records going back to 1710"),
    ("The experiment failed on the first attempt", "the second attempt produced a clear result"),
    ("The poem is only fourteen lines", "students needed a full period to explain the closing image"),
    ("The apartment is far from the campus", "the commute takes less than fifteen minutes by train"),
    ("The paint looked dull in the can", "it dried to a bright finish"),
    ("The witness spoke softly", "every word was distinct in the recording"),
    ("The early reviews were harsh", "later critics treated the film as a major work"),
    ("The path is poorly marked", "local hikers can follow it without a map"),
    ("The machine is thirty years old", "it still meets the modern safety test"),
    ("The soup tasted bland at first", "the final spoonful was heavily salted"),
    ("The author avoids direct political statements", "the plot keeps returning to a contested election"),
    ("The battery is advertised as long-lasting", "in cold weather it drains before noon"),
]

EXAMPLES = [
    ("Several desert plants store water in their tissues", "the saguaro holds water in its pleated stem and swells after rain"),
    ("Some migratory birds travel thousands of miles without a long stop", "the bar-tailed godwit can fly from Alaska to New Zealand in a single journey"),
    ("A few city programs measure success by returns, not by fines", "after Reed dropped overdue fees, more books came back within a month"),
    ("Certain alloys expand very little when heated", "Invar, a nickel-iron alloy, is used where a change in length would ruin a measurement"),
    ("Some archives preserve sound as well as paper", "the library holds wax cylinders of speeches recorded in the 1890s"),
    ("A number of coastal towns have moved houses away from eroding bluffs", "in 2018 North Haven relocated six cottages farther inland"),
    ("Several painters ground their own pigments", "Joan Mitchell's studio notes list the stones she crushed for a blue"),
    ("Some bridges are designed to flex in high wind", "the deck of the river bridge can sway slightly without cracking"),
    ("A few mathematical proofs are short enough to fit in a margin", "the modern proof that there are infinitely many primes takes only a few lines"),
    ("Some foods were dried to last through winter", "apple rings hung in the farmhouse attic until spring"),
    ("Certain plays depend on a single stage object", "in this production a wooden chair is the only furniture"),
    ("Some letters reveal more in a postscript than in the body", "a note added at the bottom of the 1864 letter names the person the writer would not mention above"),
    ("A few laboratories keep null results on file", "the lab's 2016 folder records a reading-speed study that found no difference between two typefaces"),
    ("Some trails are rebuilt with water bars to slow runoff", "the switchbacks above Mill Creek now include a low log at every turn"),
    ("Certain oral histories correct a date printed in the newspaper", "Mrs. Adelman's interview places the fire on a Tuesday, not on the Thursday the headline claimed"),
]

ADDITIONS = [
    ("The trail is steep", "the last mile is unmarked"),
    ("The novel quotes two diaries", "it includes a map of the 1850 route"),
    ("The lab replaced the cracked beakers", "it ordered a backup thermometer"),
    ("The city planted oaks along the avenue", "it widened the sidewalks"),
    ("The essay cites the 1910 speech", "it quotes a letter written the same week"),
    ("The bakery stopped using the old oven", "it hired a second baker for the morning shift"),
    ("The museum repaired the torn canvas", "it improved the lighting in that gallery"),
    ("The class read the poem aloud", "the students annotated the final couplet"),
    ("The engineer shortened the bolt", "she added a lock washer"),
    ("The report describes the survey method", "it prints the questionnaire in an appendix"),
    ("The garden lost its tomatoes to frost", "the basil turned black"),
    ("The archive digitized the letters", "it transcribed the ones written in faded ink"),
    ("The team measured the bridge at dawn", "they measured it again at midafternoon"),
    ("The cookbook explains the dough", "it shows a photograph of the finished loaf"),
    ("The policy caps class size", "it adds a study hour after school"),
    ("The film restores the missing scene", "it corrects the color of the night shots"),
    ("The biologist tagged twenty turtles", "she recorded the temperature of each nest"),
    ("The library extended its hours", "it started a weekend homework desk"),
    ("The composer cut eight measures", "she changed the key of the chorus"),
    ("The farmer rotated the crops", "he planted a strip of native grass along the ditch"),
]

CONCESSIONS = [
    ("The Cedar Dock survey covered only one winter", "the same crack pattern showed up in the spring photographs"),
    ("The first batch from Kiln B was small", "every later batch from that kiln cracked in the same place"),
    ("Room 12 has only twelve desks", "the workshop still finished the census of the ledgers"),
    ("The Mill Creek notes are written in a hard hand", "the dates in them match the newspaper"),
    ("The North Haven sample left out the newest cottages", "the erosion line still moved inland in every older lot"),
    ("The chapbook used a cheap paper", "the poems were the ones the class kept quoting"),
    ("The night clerk had only a pencil", "she recorded every temperature the kiln reached"),
    ("The footbridge sways when a bus crosses", "it has passed the safety test for six years"),
    ("The caption is only eight words", "visitors stop at that case longer than at the others"),
    ("The 1910 speech fills less than a page", "the letter written that week depends on it"),
    ("The tomato starts were crowded in the tray", "nearly all of them survived the move outside"),
    ("The recorder battery was down to one bar", "the interview was captured through the last question"),
    ("The trail map is a decade old", "the switchbacks above Mill Creek are still where it draws them"),
    ("The glaze recipe skips the brand of clay", "potters who follow the times and temperatures get the same finish"),
    ("The orchestra had not rehearsed the new ending", "the chorus stayed together at the concert"),
    ("The archive copy is missing page 4", "the argument of the letter is clear from the pages that remain"),
]

SEQUENCES = [
    ("At 6:10 the night clerk unlocked the Cedar Room", "she logged the temperature of Kiln B"),
    ("The archivist set the mill ledger on a cushion", "she copied the 1881 date onto a card"),
    ("Jonah wiped the rim of the bowl", "he dipped the piece in the glaze"),
    ("The crew chalked the east wall", "they measured the studs a second time"),
    ("Maya rosined the bow", "she played the four measures without stopping"),
    ("The baker scored the top of the loaf", "he slid it onto the hot stone"),
    ("Omar printed the chart for Room 12", "he taped it beside the door"),
    ("The guide filled the bottles at the pump", "she handed one to each hiker"),
    ("The editor read the last paragraph aloud", "she cut the repeated sentence"),
    ("The nurse checked the wristband", "she logged the dose on the chart"),
    ("The mechanic lifted the wheel", "he tightened the loose bolt"),
    ("The student underlined the claim", "she wrote a question in the margin"),
    ("The gardener coiled the hose", "he mulched the tomato beds"),
    ("The clerk stamped the form", "she returned the carbon copy"),
    ("Lina saved the caption file", "she sent it to the printer"),
    ("The quartet turned to the third movement", "they started at the top of the page"),
]


def transitions():
    out = []
    pools = {
        "result": CAUSES,
        "contrast": CONTRASTS,
        "example": EXAMPLES,
        "addition": ADDITIONS,
        "concession": CONCESSIONS,
        "sequence": SEQUENCES,
    }
    difficulty = {
        "result": "Easy",
        "contrast": "Medium",
        "example": "Hard",
        "addition": "Easy",
        "concession": "Hard",
        "sequence": "Medium",
    }
    labels = {
        "result": "cause and result",
        "contrast": "contrast",
        "example": "example",
        "addition": "addition",
        "concession": "concession",
        "sequence": "sequence",
    }
    for rel, pairs in pools.items():
        words = TRANS_REL[rel]
        other_rels = [r for r in TRANS_REL if r != rel]
        for i, (s1, s2) in enumerate(pairs):
            good = words[i % len(words)]
            bads = []
            for j, orel in enumerate(other_rels[:3]):
                bads.append(TRANS_REL[orel][(i + j) % len(TRANS_REL[orel])])
            out.append(Q(
                "Expression of Ideas", "Transitions", difficulty[rel],
                [f"{s1}. ________, {s2}."],
                STEMS["Transitions"],
                [good] + bads, good,
                family=labels[rel],
            ))
    return out


# ---------------------------------------------------------------------------
# Words in context
# ---------------------------------------------------------------------------

def load_vocab():
    import re
    from vocab_data import VOCAB
    out = []
    for diff, sentence, word, d1, d2, d3 in VOCAB:
        hits = re.findall(r"\b" + re.escape(word) + r"\b", sentence)
        if len(hits) != 1:
            raise SystemExit(f"vocab blank error: {word!r} in {sentence!r}")
        stim = re.sub(r"\b" + re.escape(word) + r"\b", "________", sentence, count=1)
        choices = [word, d1, d2, d3]
        out.append(Q(
            "Craft and Structure", "Words in Context", diff,
            [stim], STEMS["Words in Context"], choices, word,
            family="precise word",
        ))
    easy = [q for q in out if q["difficulty"] == "Easy"]
    med = [q for q in out if q["difficulty"] == "Medium"]
    hard = [q for q in out if q["difficulty"] == "Hard"]
    # 20 easy + 70 medium + 70 hard = 160
    return easy + med[:70] + hard[:70]


def cap_first(s):
    return s[0].upper() + s[1:] if s else s


def reading_from_seeds():
    from seeds_data import SEEDS
    central, purpose, function, infer, support, weaken, cross = [], [], [], [], [], [], []
    detail, limit_fn, differ, complete, quote = [], [], [], [], []
    for i, raw in enumerate(SEEDS):
        area, person, subject, claim, method, evidence, followup, limit, t2, t2point = raw
        last = last_name(person)
        t2last = last_name(t2)
        passage = (
            f"{person} has studied {subject}. "
            f"{last} claims that {claim}. "
            f"In the study, {method}. "
            f"The results showed that {evidence}."
        )
        passage_s = (
            f"{person} claims that {claim}. "
            f"In the study, {method}. "
            f"The results showed that {evidence}. "
            f"{followup}."
        )
        passage_i = passage + f" {last} notes, however, that {limit}."
        central.append(Q(
            "Information and Ideas", "Central Ideas and Details", "Easy" if i % 3 == 0 else "Medium",
            [passage],
            "Which choice best states the main idea of the text?",
            [
                f"{last}'s study supports the claim that {claim}.",
                f"The text is mainly a set of instructions for how to carry out the following procedure: {method}.",
                f"{last} concludes that it is not the case that {claim}.",
                f"The text's main point is that {limit}.",
            ],
            f"{last}'s study supports the claim that {claim}.",
            family="main idea of a study",
        ))
        detail.append(Q(
            "Information and Ideas", "Central Ideas and Details", "Easy" if i % 2 == 0 else "Medium",
            [passage],
            "According to the text, which statement is true?",
            [
                cap_first(evidence) + ".",
                cap_first("it was not the case that " + evidence) + ".",
                f"The text states that {limit}.",
                f"{last} reports that no result was collected.",
            ],
            cap_first(evidence) + ".",
            family="stated detail",
        ))
        purpose.append(Q(
            "Craft and Structure", "Text Structure and Purpose", "Medium",
            [passage_s],
            "Which choice best describes the overall structure of the text?",
            [
                "It states a claim, describes a study and its result, and then adds a later observation consistent with the claim.",
                "It states a claim and then rejects the claim because the study produced no result.",
                "It presents a debate between two researchers and does not report a finding.",
                "It defines a technical term and then traces the history of a field from ancient times to the present.",
            ],
            "It states a claim, describes a study and its result, and then adds a later observation consistent with the claim.",
            family="overall structure",
        ))
        function.append(Q(
            "Craft and Structure", "Text Structure and Purpose", "Medium" if i % 2 == 0 else "Hard",
            [passage_s],
            "Which choice best describes the function of the third sentence in the overall structure of the text?",
            [
                "It reports a result that supports the claim stated in the first sentence.",
                "It introduces a new claim that contradicts the first sentence.",
                "It explains why the study could not be completed.",
                "It defines a technical term that the last sentence depends on.",
            ],
            "It reports a result that supports the claim stated in the first sentence.",
            family="function of the result sentence",
        ))
        limit_fn.append(Q(
            "Craft and Structure", "Text Structure and Purpose", "Hard",
            [passage_i],
            "Which choice best describes the function of the last sentence in the overall structure of the text?",
            [
                f"It marks a limit by noting that {limit}.",
                "It repeats the method of the study in different words.",
                f"It rejects the result by claiming that {evidence} never happened.",
                "It introduces a second study that uses a different method.",
            ],
            f"It marks a limit by noting that {limit}.",
            family="function of a limiting sentence",
        ))
        infer.append(Q(
            "Information and Ideas", "Inferences", "Hard" if i % 2 else "Medium",
            [passage_i],
            "Which choice is most strongly supported by the text?",
            [
                f"In the cases the study describes, the reported result lines up with the claim that {claim}, though the text also marks a limit.",
                f"The study proves that {claim} in every place and in every year.",
                "The study was abandoned before any results were collected.",
                f"Because {limit}, the result described in the text cannot be stated at all.",
            ],
            f"In the cases the study describes, the reported result lines up with the claim that {claim}, though the text also marks a limit.",
            family="inference with a stated limit",
        ))
        complete.append(Q(
            "Information and Ideas", "Inferences", "Hard" if i % 3 == 0 else "Medium",
            [
                f"{person} claims that {claim}. In the study, {method}. "
                f"The results showed that {evidence}. A further observation pointed the same way: {followup}. "
                "The most reasonable conclusion is that ________."
            ],
            "Which choice most logically completes the text?",
            [
                f"the result, that {evidence}, and the later observation point the same way.",
                "the later observation cancels the result, so the text supports no conclusion.",
                f"the study never measured anything related to {subject}.",
                f"the result contradicts the claim that {claim}.",
            ],
            f"the result, that {evidence}, and the later observation point the same way.",
            family="complete the inference",
        ))
        support.append(Q(
            "Information and Ideas", "Command of Evidence (Textual)", "Medium",
            [f"{person} claims that {claim}."],
            "Which finding, if true, would most directly support the claim?",
            [
                cap_first(evidence) + ".",
                cap_first("it was not the case that " + evidence) + ".",
                "The research team included graduate students.",
                cap_first(limit) + ".",
            ],
            cap_first(evidence) + ".",
            family="new finding that supports a claim",
        ))
        weaken.append(Q(
            "Information and Ideas", "Command of Evidence (Textual)", "Hard",
            [f"{person} claims that {claim}."],
            "Which finding, if true, would most directly weaken the claim?",
            [
                cap_first("it was not the case that " + evidence) + ".",
                cap_first(evidence) + ".",
                "The research team included graduate students.",
                f"The study was conducted in the area of {subject}.",
            ],
            cap_first("it was not the case that " + evidence) + ".",
            family="new finding that weakens a claim",
        ))
        quote.append(Q(
            "Information and Ideas", "Command of Evidence (Textual)", "Medium" if i % 2 == 0 else "Hard",
            [passage],
            "Which quotation from the text most directly supports the claim in the first sentence?",
            [
                f"The results showed that {evidence}.",
                f"The results showed that it was not the case that {evidence}.",
                f"{person} has studied {subject}.",
                f"In the study, {method}.",
            ],
            f"The results showed that {evidence}.",
            family="quotation that supports the claim",
        ))
        cross.append(Q(
            "Craft and Structure", "Cross-Text Connections", "Hard",
            [
                f"Text 1\n{person} claims that {claim}. The reported evidence is that {evidence}.",
                f"Text 2\n{t2} reports a further check: {t2point}.",
            ],
            f"Based on the texts, how would {t2last} most likely respond to the claim in Text 1?",
            [
                f"{t2last} would say the pattern in Text 1 may not hold under every condition, pointing out that {t2point}.",
                f"{t2last} would say the evidence in Text 1 was invented and should be ignored.",
                f"{t2last} would agree that there are no exceptions to the claim in Text 1.",
                f"{t2last} is writing about an unrelated subject and would have no response to the claim.",
            ],
            f"{t2last} would say the pattern in Text 1 may not hold under every condition, pointing out that {t2point}.",
            family="how the second text would respond",
        ))
        differ.append(Q(
            "Craft and Structure", "Cross-Text Connections", "Medium" if i % 2 == 0 else "Hard",
            [
                f"Text 1\n{person} claims that {claim}. The reported evidence is that {evidence}.",
                f"Text 2\n{t2} reports a further check: {t2point}.",
            ],
            "Based on the texts, which choice best describes a difference between them?",
            [
                f"Text 1 reports that {evidence}, while Text 2 adds that {t2point}.",
                f"Both texts report the same further check, that {t2point}.",
                "Text 2 repeats Text 1's method and adds no observation of its own.",
                f"The texts disagree about whether any result was reported for {subject}.",
            ],
            f"Text 1 reports that {evidence}, while Text 2 adds that {t2point}.",
            family="difference between two texts",
        ))
    return {
        "central": central,
        "detail": detail,
        "purpose": purpose,
        "function": function,
        "limit_fn": limit_fn,
        "infer": infer,
        "complete": complete,
        "support": support,
        "weaken": weaken,
        "quote": quote,
        "cross": cross,
        "differ": differ,
    }


def reading_from_lit():
    from lit_data import LIT
    central, purpose, function, infer = [], [], [], []
    for i, L in enumerate(LIT):
        central.append(Q(
            "Information and Ideas", "Central Ideas and Details", "Medium",
            [L["passage"]],
            "Which choice best states the main idea of the text?",
            [L["main"], L["narrow"], L["opposite"], L["off"]],
            L["main"],
            family="main idea of a literary text",
        ))
        purpose.append(Q(
            "Craft and Structure", "Text Structure and Purpose", "Medium",
            [L["passage"]],
            "Which choice best states the main purpose of the text?",
            [L["purpose"]] + L["purpose_wrongs"],
            L["purpose"],
            family="purpose of a literary text",
        ))
        function.append(Q(
            "Craft and Structure", "Text Structure and Purpose", "Hard",
            [L["passage"]],
            f"Which choice best describes the function of {L['function_of']} in the text?",
            [L["function"]] + L["function_wrongs"],
            L["function"],
            family="function of a sentence in literature",
        ))
        infer.append(Q(
            "Information and Ideas", "Inferences", "Hard",
            [L["passage"]],
            "Which choice is most strongly supported by the text?",
            [L["infer"]] + L["infer_wrongs"],
            L["infer"],
            family="inference from a literary text",
        ))
    return central, purpose, function, infer


def rhetoric():
    from seeds_data import SEEDS
    out = []
    for i, raw in enumerate(SEEDS):
        area, person, subject, claim, method, evidence, followup, limit, t2, t2point = raw
        last = last_name(person)
        notes = (
            "While researching a paper, a student took the following notes:\n"
            f"- Subject studied: {subject}.\n"
            f"- Researcher: {person}.\n"
            f"- Result reported: {evidence}.\n"
            f"- Caution the researcher notes: {limit}.\n"
            f"- A later observation: {followup}."
        )
        good_a = f"{last} reports that {evidence}, but cautions that {limit}."
        bad_a = [
            f"{last} reports that {evidence}, which removes any need for caution about the finding.",
            f"{followup}.",
            f"{last} reports that it was not the case that {evidence}.",
        ]
        out.append(Q(
            "Expression of Ideas", "Rhetorical Synthesis", "Medium" if i % 2 == 0 else "Hard",
            [notes + "\n\nThe student wants to mention the result and acknowledge a limit of the finding."],
            STEMS["Rhetorical Synthesis"],
            [good_a] + bad_a,
            good_a,
            family="result plus a limit",
        ))
        good_b = f"{last} reports that {evidence}."
        bad_b = [
            f"{last} cautions that {limit}.",
            f"{last} reports that it was not the case that {evidence}.",
            f"{followup}, and {last} cautions that {limit}.",
        ]
        out.append(Q(
            "Expression of Ideas", "Rhetorical Synthesis", "Easy" if i % 3 == 0 else "Medium",
            [notes + "\n\nThe student wants to report the study's result only, without discussing its limits or later observations."],
            STEMS["Rhetorical Synthesis"],
            [good_b] + bad_b,
            good_b,
            family="result only",
        ))
        good_c = f"{person} studies {subject}."
        bad_c = [
            f"{person} studies {subject} and reports that {evidence}.",
            f"{last} cautions that {limit}.",
            f"{followup}.",
        ]
        out.append(Q(
            "Expression of Ideas", "Rhetorical Synthesis", "Easy" if i % 2 == 0 else "Medium",
            [notes + "\n\nThe student wants to introduce the researcher and the subject only, without a result, a caution, or a later observation."],
            STEMS["Rhetorical Synthesis"],
            [good_c] + bad_c,
            good_c,
            family="researcher and subject only",
        ))
        good_d = f"{last} reports that {evidence}, whereas a later observation was that {followup}."
        bad_d = [
            f"{last} reports that {evidence}.",
            f"{followup}.",
            f"{last} reports that {evidence}, but cautions that {limit}.",
        ]
        out.append(Q(
            "Expression of Ideas", "Rhetorical Synthesis", "Hard",
            [notes + "\n\nThe student wants to contrast the result with the later observation."],
            STEMS["Rhetorical Synthesis"],
            [good_d] + bad_d,
            good_d,
            family="result contrasted with a later observation",
        ))
        good_e = f"{last} cautions that {limit}."
        bad_e = [
            f"{last} reports that {evidence}.",
            f"{followup}.",
            f"{last} reports that it was not the case that {limit}.",
        ]
        out.append(Q(
            "Expression of Ideas", "Rhetorical Synthesis", "Medium",
            [notes + "\n\nThe student wants to state the caution only, without the result or the later observation."],
            STEMS["Rhetorical Synthesis"],
            [good_e] + bad_e,
            good_e,
            family="caution only",
        ))
    return out


def quantitative():
    specs = [
        ("Mean quiz score", "points", "hours of sleep the night before", ["6 hours", "7 hours", "8 hours", "9 hours"], "students who slept more would have higher mean quiz scores"),
        ("Mean commute", "minutes", "distance from campus", ["under 1 mile", "1 to 3 miles", "3 to 6 miles", "over 6 miles"], "longer distances would come with longer mean commutes"),
        ("Seedlings sprouted", "percent", "daytime temperature", ["15 C", "20 C", "25 C", "30 C"], "a warmer daytime temperature would come with a higher percent sprouted"),
        ("Books returned", "number", "week after fines ended", ["week 1", "week 2", "week 3", "week 4"], "returns would rise across the four weeks"),
        ("Bridge gap", "millimeters", "afternoon temperature", ["10 C", "20 C", "30 C", "35 C"], "hotter afternoons would come with narrower joint gaps"),
        ("Battery range", "miles", "morning temperature", ["-5 C", "5 C", "15 C", "25 C"], "warmer mornings would come with more miles of range"),
        ("Soil caught", "grams", "canopy cover", ["10 percent", "25 percent", "40 percent", "60 percent"], "more canopy would come with less soil caught below the field"),
        ("Words recalled", "number", "hours after reading", ["1 hour", "4 hours", "1 day", "1 week"], "recall would be lower after more time had passed"),
        ("Nest boxes occupied", "percent", "height of the box", ["1 meter", "2 meters", "3 meters", "4 meters"], "higher boxes would be occupied less often"),
        ("Bus trip time", "minutes", "month after the lane opened", ["month 1", "month 2", "month 3", "month 4"], "trip times would fall across the four months"),
        ("Algae cover", "percent", "weeks since the heat wave", ["week 1", "week 2", "week 3", "week 4"], "algae cover would fall across the four weeks"),
        ("Attendance", "percent", "start time", ["7:15", "7:45", "8:15", "8:45"], "a later start would come with higher attendance"),
        ("Cracked pots", "percent", "shell temper added", ["none", "5 percent", "10 percent", "15 percent"], "more shell temper would come with a lower percent of cracked pots"),
        ("Page tears", "number", "age of the iron-gall letters", ["20 years", "50 years", "80 years", "120 years"], "older letters would show more tears along the ink"),
        ("Visitor time", "minutes", "caption length", ["10 words", "25 words", "50 words", "80 words"], "longer captions would come with more minutes spent at the case"),
    ]
    # descending claims: index 4 soil, 6 words, 7 nests, 8 bus, 9 algae, 11 pots. I'll set direction per spec.
    # direction +1 means values increase as the claim says "higher"; -1 means claim says lower and values decrease.
    directions = {
        "Mean quiz score": 1,
        "Mean commute": 1,
        "Seedlings sprouted": 1,
        "Books returned": 1,
        "Bridge gap": -1,
        "Battery range": 1,
        "Soil caught": -1,
        "Words recalled": -1,
        "Nest boxes occupied": -1,
        "Bus trip time": -1,
        "Algae cover": -1,
        "Attendance": 1,
        "Cracked pots": -1,
        "Page tears": 1,
        "Visitor time": 1,
    }
    out = []
    n = 0
    for unit, ylab, xlab, groups, claim in specs:
        direction = directions[unit]
        # two support tables (monotonic) and one challenge table (dip) where possible
        bases = [12, 18, 7]
        for b_i, base in enumerate(bases):
            vals = []
            for k in range(4):
                step = (k + 1) * (3 + (n % 3))
                vals.append(base + step if direction == 1 else base + 40 - step)
            # support item
            a, b = 0, 3
            va, vb = vals[a], vals[b]
            higher = groups[a] if va > vb else groups[b]
            lower = groups[b] if va > vb else groups[a]
            hi_v = max(va, vb)
            lo_v = min(va, vb)
            word = "higher" if direction == 1 else "lower"
            # claim matches direction across the ends
            if direction == 1:
                assert vals[3] > vals[0]
            else:
                assert vals[3] < vals[0]
            correct = f"{groups[3]} shows a {word} value ({vals[3]} {ylab}) than {groups[0]} ({vals[0]} {ylab})."
            # false readings
            false1 = f"{groups[0]} shows a {word} value ({vals[0]} {ylab}) than {groups[3]} ({vals[3]} {ylab})."
            false2 = f"{groups[1]} and {groups[2]} show the same value."
            false3 = f"{groups[3]} shows a value of {vals[0]} {ylab}."
            assert vals[1] != vals[2]
            table = {
                "caption": f"{unit} by {xlab}",
                "headers": [xlab, unit],
                "rows": list(zip(groups, [str(v) for v in vals])),
            }
            stim_parts = [
                f"A student claims that {claim}.",
                table,
            ]
            out.append(Q(
                "Information and Ideas", "Command of Evidence (Quantitative)",
                "Easy" if b_i == 0 else "Medium",
                stim_parts,
                "Which choice most effectively uses data from the table to support the student's claim?",
                [correct, false1, false2, false3],
                correct,
                family="data that support a claim",
            ))
            n += 1
            if b_i == 0:
                if vals[3] > vals[1]:
                    g_hi, g_lo, v_hi, v_lo = groups[3], groups[1], vals[3], vals[1]
                else:
                    g_hi, g_lo, v_hi, v_lo = groups[1], groups[3], vals[1], vals[3]
                correct_c = f"{g_hi} shows a higher value ({v_hi} {ylab}) than {g_lo} ({v_lo} {ylab})."
                false_c1 = f"{g_lo} shows a higher value ({v_lo} {ylab}) than {g_hi} ({v_hi} {ylab})."
                false_c2 = f"{groups[0]} and {groups[2]} show the same value."
                false_c3 = f"{groups[3]} shows a value of {vals[0]} {ylab}."
                assert len({correct_c, false_c1, false_c2, false_c3}) == 4
                out.append(Q(
                    "Information and Ideas", "Command of Evidence (Quantitative)",
                    "Medium",
                    [f"The table shows {unit.lower()} by {xlab}.", table],
                    "Which choice most accurately uses data from the table?",
                    [correct_c, false_c1, false_c2, false_c3],
                    correct_c,
                    family="true comparison from a table",
                ))
                n += 1
            # challenge item: insert a dip that breaks "every step"
            cvals = list(vals)
            # swap middle so it is not monotonic
            cvals[2] = cvals[1] - direction * (4 + n % 3)
            # ensure the end still matches overall claim but a middle step reverses
            if direction == 1:
                # want cvals[2] < cvals[1], and cvals[3] > cvals[0]
                if not (cvals[2] < cvals[1] and cvals[3] > cvals[0]):
                    cvals = [10, 16, 13, 22]
            else:
                if not (cvals[2] > cvals[1] and cvals[3] < cvals[0]):
                    cvals = [40, 34, 37, 28]
            if direction == 1:
                assert cvals[2] < cvals[1] and cvals[3] > cvals[0]
                true_challenge = f"{groups[2]} is lower ({cvals[2]} {ylab}) than {groups[1]} ({cvals[1]} {ylab})."
                false_a = f"{groups[1]} is lower ({cvals[1]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                false_b = f"{groups[3]} is lower ({cvals[3]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                # true but does not challenge a claim of steady increase: overall end is higher
                true_support = f"{groups[3]} is higher ({cvals[3]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                assert cvals[1] > cvals[0]
                assert cvals[3] > cvals[0]
            else:
                assert cvals[2] > cvals[1] and cvals[3] < cvals[0]
                true_challenge = f"{groups[2]} is higher ({cvals[2]} {ylab}) than {groups[1]} ({cvals[1]} {ylab})."
                false_a = f"{groups[1]} is higher ({cvals[1]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                false_b = f"{groups[3]} is higher ({cvals[3]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                true_support = f"{groups[3]} is lower ({cvals[3]} {ylab}) than {groups[0]} ({cvals[0]} {ylab})."
                assert cvals[1] < cvals[0]
                assert cvals[3] < cvals[0]
            ctable = {
                "caption": f"{unit} by {xlab}",
                "headers": [xlab, unit],
                "rows": list(zip(groups, [str(v) for v in cvals])),
            }
            steady = "rose at every step" if direction == 1 else "fell at every step"
            out.append(Q(
                "Information and Ideas", "Command of Evidence (Quantitative)",
                "Hard",
                [f"A student claims that the {unit.lower()} {steady} from {groups[0]} to {groups[3]}.", ctable],
                "Which choice most effectively uses data from the table to challenge the student's claim?",
                [true_challenge, false_a, false_b, true_support],
                true_challenge,
                family="data that challenge a claim",
            ))
            n += 1
    return out


def spread_take(got, n, label):
    """Keep every task family, then fill. Easy items of a family come first."""
    if len(got) < n:
        raise SystemExit(f"{label}: have {len(got)}, need {n}")
    rank = {"Easy": 0, "Medium": 1, "Hard": 2}
    buckets = {}
    order = []
    for q in sorted(got, key=lambda q: (rank[q["difficulty"]], q.get("family") or "")):
        fam = q.get("family") or q["skill"]
        if fam not in buckets:
            buckets[fam] = []
            order.append(fam)
        buckets[fam].append(q)
    chosen = []
    while len(chosen) < n:
        progressed = False
        for fam in order:
            if buckets[fam]:
                chosen.append(buckets[fam].pop(0))
                progressed = True
                if len(chosen) == n:
                    break
        if not progressed:
            break
    if len(chosen) != n:
        raise SystemExit(f"{label}: spread produced {len(chosen)}")
    return chosen


def assemble():
    pools = { (d, s): [] for d, s, _ in QUOTAS }
    for q in boundaries():
        pools[(q["domain"], q["skill"])].append(q)
    for q in form_items():
        pools[(q["domain"], q["skill"])].append(q)
    for q in transitions():
        pools[(q["domain"], q["skill"])].append(q)
    for q in load_vocab():
        pools[(q["domain"], q["skill"])].append(q)
    R = reading_from_seeds()
    lc, lp, lf, li = reading_from_lit()
    pools[("Information and Ideas", "Central Ideas and Details")] = lc + R["central"] + R["detail"]
    pools[("Craft and Structure", "Text Structure and Purpose")] = lp + R["purpose"] + lf + R["function"] + R["limit_fn"]
    pools[("Information and Ideas", "Inferences")] = li + R["infer"] + R["complete"]
    pools[("Information and Ideas", "Command of Evidence (Textual)")] = R["support"] + R["weaken"] + R["quote"]
    pools[("Craft and Structure", "Cross-Text Connections")] = R["cross"] + R["differ"]
    pools[("Expression of Ideas", "Rhetorical Synthesis")] = rhetoric()
    pools[("Information and Ideas", "Command of Evidence (Quantitative)")] = quantitative()

    ordered = []
    for domain, skill, n in QUOTAS:
        chosen = spread_take(pools[(domain, skill)], n, f"{domain} / {skill}")
        ordered.extend(chosen)
    if len(ordered) != 1000:
        raise SystemExit(f"count {len(ordered)}")
    # shuffle choices deterministically
    for i, q in enumerate(ordered):
        rng = random.Random(SEED + i * 17)
        paired = list(zip(q["choices"], [c == q["correct"] for c in q["choices"]]))
        rng.shuffle(paired)
        q["choices"] = [p[0] for p in paired]
        q["key"] = "ABCD"[next(k for k, p in enumerate(paired) if p[1])]
        if q["choices"]["ABCD".index(q["key"])] != q["correct"]:
            raise SystemExit("key mismatch")
    return ordered


def tex_escape(s):
    s = s.replace("—", "---").replace("–", "--").replace("’", "'").replace("“", "``").replace("”", "''")
    out = []
    for ch in s:
        out.append({
            "\\": r"\textbackslash{}",
            "&": r"\&",
            "%": r"\%",
            "$": r"\$",
            "#": r"\#",
            "_": r"\_",
            "{": r"\{",
            "}": r"\}",
            "~": r"\textasciitilde{}",
            "^": r"\textasciicircum{}",
        }.get(ch, ch))
    return "".join(out)


def tex_parts(parts):
    chunks = []
    for p in parts:
        if isinstance(p, str):
            text = tex_escape(p).replace("________", r"\underline{\hspace{1.5cm}}")
            text = text.replace("\n\n", "\n\n\\medskip\n").replace("\n", "\\par\n")
            chunks.append(text + "\n")
        else:
            rows = " \\\\\n".join(
                " & ".join(tex_escape(str(c)) for c in (p["headers"] if False else row))
                for row in p["rows"]
            )
            # rebuild properly
            head = " & ".join(tex_escape(h) for h in p["headers"]) + r" \\"
            body = " \\\\\n".join(" & ".join(tex_escape(str(c)) for c in row) for row in p["rows"])
            chunks.append(
                "\\begin{center}\\small\n"
                + tex_escape(p["caption"]) + "\\\\\n"
                "\\begin{tabular}{lc}\n\\hline\n"
                + head + " \\hline\n" + body + " \\\\\n\\hline\n\\end{tabular}\n\\end{center}\n"
            )
    return "\n".join(chunks)


def write_tex(qs, path):
    lines = []
    lines.append(r"""\documentclass[11pt]{article}
\usepackage[margin=0.85in]{geometry}
\usepackage{lmodern}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{microtype}
\usepackage{enumitem}
\usepackage{multicol}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\lhead{Digital SAT Reading and Writing}
\rhead{1,000 practice questions}
\cfoot{\thepage}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.35em}
\begin{document}
\begin{center}
{\LARGE\bfseries Digital SAT Reading and Writing}\\[0.4em]
{\Large 1,000 Practice Questions}\\[0.8em]
\end{center}

This booklet is original practice in the style of the Digital SAT Reading and Writing section. It is not produced by the College Board and is not an official SAT. Each question has its own short text and four choices, as on the current test. The mix follows the College Board's domain weights: Craft and Structure about 28 percent, Information and Ideas about 26 percent, Standard English Conventions about 26 percent, and Expression of Ideas about 20 percent. Within each skill, the label under the question number names the task family (the kind of move the question asks for) and the difficulty. Families are different jobs, not the same job with new numbers. Questions in a skill move through those families. The answer key is at the end.

Passages, studies, and data are written for practice. Do not treat the fictional studies as real research findings.

\section*{How the section is weighted}
\begin{center}
\begin{tabular}{lr}
\hline
Craft and Structure & 280 questions \\
Information and Ideas & 260 questions \\
Standard English Conventions & 260 questions \\
Expression of Ideas & 200 questions \\
\hline
\end{tabular}
\end{center}
""")
    current = None
    for i, q in enumerate(qs, start=1):
        if q["skill"] != current:
            current = q["skill"]
            lines.append(f"\\section*{{{tex_escape(q['domain'])}: {tex_escape(q['skill'])}}}\n")
        lines.append("\\noindent\\begin{minipage}{\\textwidth}\\raggedright\n")
        fam = q.get("family") or ""
        label = tex_escape(q["difficulty"] + ((" --- " + fam) if fam else ""))
        lines.append(f"{{\\bfseries {i}.}} \\textit{{{label}}}\\par\n")
        lines.append(tex_parts(q["parts"]) + "\n")
        lines.append("\\medskip\n" + tex_escape(q["stem"]) + "\\par\n")
        lines.append("\\begin{enumerate}[label=\\Alph*), leftmargin=1.6em, itemsep=0.15em, topsep=0.3em]\n")
        for c in q["choices"]:
            lines.append("\\item " + tex_escape(c).replace("________", r"\underline{\hspace{1.5cm}}") + "\n")
        lines.append("\\end{enumerate}\n\\end{minipage}\\vspace{0.85em}\n")
    lines.append("\\clearpage\n\\section*{Answer key}\n\\begin{multicols}{5}\\raggedcolumns\\small\n")
    for i, q in enumerate(qs, start=1):
        lines.append(f"{i}. {q['key']}\\par\n")
    lines.append("\\end{multicols}\n\\end{document}\n")
    with open(path, "w", encoding="utf-8") as f:
        f.write("".join(lines))


def main():
    qs = assemble()
    counts = Counter((q["domain"], q["skill"]) for q in qs)
    for domain, skill, n in QUOTAS:
        got = counts[(domain, skill)]
        print(f"{got:4} {domain} / {skill} (need {n})")
        if got != n:
            raise SystemExit("quota miss")
    # uniqueness of stems+first part
    sigs = []
    for q in qs:
        first = q["parts"][0] if isinstance(q["parts"][0], str) else str(q["parts"][0])
        sigs.append(first + "||" + q["stem"] + "||" + q["correct"])
    print("unique stimuli", len(set(sigs)), "of", len(sigs))
    path = "/workspace/sat_rw/Digital_SAT_RW_1000.tex"
    write_tex(qs, path)
    print("wrote", path)


if __name__ == "__main__":
    main()

