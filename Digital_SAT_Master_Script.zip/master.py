#!/usr/bin/env python3
"""Palmer Grove Digital SAT master script.

Reads the Fall 2026 Bluebook structure (54 Reading and Writing questions,
44 Math questions) and builds 1,000 original math items and 1,000 original
Reading and Writing items in those proportions. Official practice tests are
used only as a map of skills and command words. No College Board item is copied.

Then every math answer that can be recomputed from the stem is recomputed
by a second solver, and every Reading and Writing item is checked for a
single keyed choice. The run fails if a check fails.
"""

import re
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
if (HERE / "generate_sat_math.py").exists():
    sys.path.insert(0, str(HERE))
else:
    sys.path.insert(0, str(HERE.parent / "public" / "maths" / "sat"))
    sys.path.insert(0, str(HERE.parent / "sat_rw"))

# Fall 2026 Bluebook Test Directions, section 1.5, and the scoring sheet
# on the nondigital forms of the digital practice tests (raw scores 0-27
# and 0-22). Domain shares are the College Board operational weights.
BLUEPRINT = {
    "reading_writing": {
        "questions": 54,
        "modules": 2,
        "per_module": 27,
        "minutes_per_module": 32,
        "format": "four-option multiple choice, one best answer",
        "domains": {
            "Craft and Structure": 0.28,
            "Information and Ideas": 0.26,
            "Standard English Conventions": 0.26,
            "Expression of Ideas": 0.20,
        },
        "order_in_a_module": [
            "Craft and Structure",
            "Information and Ideas",
            "Standard English Conventions",
            "Expression of Ideas",
        ],
        "stems": {
            "Words in Context": "Which choice completes the text with the most logical and precise word or phrase?",
            "Boundaries": "Which choice completes the text so that it conforms to the conventions of Standard English?",
            "Form, Structure, and Sense": "Which choice completes the text so that it conforms to the conventions of Standard English?",
            "Transitions": "Which choice completes the text with the most logical transition?",
            "Rhetorical Synthesis": "Which choice most effectively uses relevant information from the notes to accomplish this goal?",
        },
    },
    "math": {
        "questions": 44,
        "modules": 2,
        "per_module": 22,
        "minutes_per_module": 35,
        "calculator": "allowed on every question",
        "multiple_choice": 0.75,
        "student_produced": 0.25,
        "spr_rules": "positive answers up to 5 characters; negative answers up to 6, including the sign; no mixed numbers; no percent sign, comma, or dollar sign",
        "domains": {
            "Algebra": 0.35,
            "Advanced Math": 0.35,
            "Problem-Solving and Data Analysis": 0.15,
            "Geometry and Trigonometry": 0.15,
        },
        "reference": ["A=lw", "A=1/2 bh", "A=pi r^2", "C=2 pi r", "V=lwh", "V=pi r^2 h", "V=4/3 pi r^3", "V=1/3 pi r^2 h", "V=1/3 lwh", "c^2=a^2+b^2", "30-60-90", "45-45-90", "360 degrees", "2 pi radians", "triangle 180"],
    },
}


def F(n):
    return Fraction(n).limit_denominator()


def parse_value(text):
    text = text.strip().replace(" ", "")
    text = text.replace(r"\(", "").replace(r"\)", "")
    sign = 1
    if text.startswith("-"):
        sign = -1
        text = text[1:]
    elif text.startswith("+"):
        text = text[1:]
    m = re.fullmatch(r"\\frac\{(-?\d+)\}\{(-?\d+)\}", text)
    if m:
        return sign * F(int(m.group(1))) / F(int(m.group(2)))
    m = re.fullmatch(r"\d+/\d+", text)
    if m:
        return sign * F(text)
    m = re.fullmatch(r"\d+(?:\.\d+)?", text)
    if m:
        return sign * F(text)
    return None


def _coef(tok, one_if_empty=False):
    if tok is None:
        return F(0)
    tok = tok.replace(" ", "")
    if tok in ("", "+"):
        return F(1 if one_if_empty else 0)
    if tok == "-":
        return F(-1 if one_if_empty else 0)
    sign = 1
    if tok[0] in "+-":
        sign = -1 if tok[0] == "-" else 1
        tok = tok[1:]
    if tok.startswith("(") and tok.endswith(")") and "/" in tok:
        return sign * F(tok[1:-1])
    if tok == "":
        return sign * F(1 if one_if_empty else 0)
    return sign * F(tok)


def parse_lin(expr):
    """Return (a, b) for ax+b. Accepts '5x + 11', '\\frac{1}{2}x - 3', '2(x+4)'."""
    e = expr.strip().replace(" ", "")
    e = e.replace(r"\left", "").replace(r"\right", "")
    m = re.fullmatch(r"(-?\d+)\(x([+-]\d+)\)", e)
    if m:
        a = int(m.group(1))
        inside = int(m.group(2))
        return F(a), F(a * inside)
    e = re.sub(
        r"\\frac\{(-?\d+)\}\{(-?\d+)\}",
        lambda mm: f"({mm.group(1)}/{mm.group(2)})",
        e,
    )
    m = re.fullmatch(
        r"([+-]?(?:\(\-?\d+/\-?\d+\)|\d*))x([+-](?:\(\-?\d+/\-?\d+\)|\d+))?",
        e,
    )
    if m:
        return _coef(m.group(1), one_if_empty=True), _coef(m.group(2) or "0")
    m2 = re.fullmatch(r"([+-]?(?:\(\-?\d+/\-?\d+\)|\d+))", e)
    if m2:
        return F(0), _coef(m2.group(1))
    return None


def keyed(item):
    if item.kind == "SPR":
        return parse_value(item.key), item.key
    choice = item.choices["ABCD".index(item.key)]
    return parse_value(choice), choice


def solve_equation(left, right):
    L = parse_lin(left)
    R = parse_lin(right)
    if not L or not R:
        return None
    a, b = L
    c, d = R
    if a == c:
        return "infinite" if b == d else "none"
    return F(d - b) / F(a - c)


NUM = r"(-?\d+)"


def grab(pattern, stem):
    m = re.search(pattern, stem.replace("\n", " "))
    return m


def quad_roots(expr):
    e = expr.replace(" ", "")
    if not e.startswith("x^2"):
        return None
    rest = e[3:]
    b = 0
    c = 0
    if rest:
        m = re.fullmatch(r"([+-])(\d+)x(?:([+-])(\d+))?", rest)
        if m:
            b = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
            if m.group(3):
                c = int(m.group(4)) * (1 if m.group(3) == "+" else -1)
        else:
            m = re.fullmatch(r"([+-])(\d+)", rest)
            if not m:
                return None
            c = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
    disc = b * b - 4 * c
    if disc < 0:
        return None
    root = int(round(disc ** 0.5))
    if root * root != disc:
        return None
    return F(-b + root) / 2, F(-b - root) / 2


def parse_xy(expr):
    e = expr.replace(" ", "")
    m = re.fullmatch(r"([+-]?(?:\d*))x([+-](?:\d*))y=(-?\d+)", e)
    if not m:
        return None
    return _coef(m.group(1), True), _coef(m.group(2), True), F(int(m.group(3)))


def expand_side(expr):
    e = expr.replace(" ", "")
    m = re.fullmatch(r"(-?\d+)\((.+)\)", e)
    if m:
        inner = parse_lin(m.group(2))
        if not inner:
            return None
        k = int(m.group(1))
        return k * inner[0], k * inner[1]
    return parse_lin(e)


def solve_math(item):
    s = item.stem.replace("\n", " ")
    m = grab(rf"solution to the equation \\?\(?{NUM}x \+ {NUM} = {NUM}", s)
    if m:
        a, b, c = map(int, m.groups())
        return F(c - b) / a
    m = grab(rf"solution to the equation \\?\(?{NUM}x - {NUM} = {NUM}", s)
    if m and "satisfies" not in s:
        a, b, c = map(int, m.groups())
        return F(c + b) / a
    m = grab(rf"value of \\?\(x\\?\) satisfies the equation \\?\(?(.+?) = (.+?)\\?\)\?", s)
    if m:
        return solve_equation(m.group(1), m.group(2))
    m = grab(rf"solution to \\?\(?{NUM}\(x \+ {NUM}\) = (.+?)\\?\)\?", s)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        right = parse_lin(m.group(3))
        if not right:
            return None
        c, d = right
        # a(x+b) = cx+d
        if a == c:
            return None
        return F(d - a * b) / F(a - c)
    m = grab(rf"solution set of \\?\(?{NUM}x - {NUM} < {NUM}", s)
    if m:
        a, b, c = map(int, m.groups())
        # ax - b < c
        bound = F(c + b) / a
        return f"x < {bound}" if a > 0 else f"x > {bound}"
    m = grab(rf"solution set of \\?\(?{NUM}x \+ {NUM} < {NUM}", s)
    if m:
        a, b, c = map(int, m.groups())
        # ax + b < c
        if a == 0:
            return None
        bound = F(c - b) / a
        return f"x < {bound}" if a > 0 else f"x > {bound}"
    m = grab(r"slope of the line through \\\(\((-?\d+), (-?\d+)\)\\\) and \\\(\((-?\d+), (-?\d+)\)\\\)", s)
    if m:
        x1, y1, x2, y2 = map(int, m.groups())
        return F(y2 - y1) / F(x2 - x1)
    m = grab(rf"perpendicular to the line \\?\(?y = (.+?)\\?\)", s)
    if m:
        coef = parse_lin(m.group(1).replace("x", "x"))
        if not coef or coef[0] == 0:
            return None
        return -1 / F(coef[0])
    m = grab(rf"line with equation \\?\(?y = (.+?)\\?\) passes through the point \\?\(?\({NUM}, k\)", s)
    if m:
        coef = parse_lin(m.group(1))
        if not coef:
            return None
        x = int(m.group(2))
        return F(coef[0]) * x + coef[1]
    m = grab(rf"system \\?\(?x \+ y = {NUM}\\?\) and \\?\(?x - y = {NUM}", s)
    if m:
        sm, df = int(m.group(1)), int(m.group(2))
        return F(sm + df) / 2
    m = grab(r"perimeter of a rectangle is \\?\(?(\d+)\\?\) and the width is \\?\(?(\d+)", s)
    if m:
        p, w = int(m.group(1)), int(m.group(2))
        return F(p - 2 * w) / 2
    m = grab(r"travels \\?\(?(\d+)\\?\) miles in \\?\(?(\d+)\\?\) hours", s)
    if m:
        return F(int(m.group(1))) / int(m.group(2))
    m = grab(r"costs \\\$(\d+)\. During a sale the price is reduced by (\d+)\\%", s)
    if m:
        return F(int(m.group(1)) * (100 - int(m.group(2)))) / 100
    m = grab(r"listed at \\\$(\d+)\. It is discounted by (\d+)\\%, and then a (\d+)\\% sales tax", s)
    if m:
        price, pct, tax = map(int, m.groups())
        return F(price * (100 - pct) * (100 + tax)) / 10000
    m = grab(r"ratio of red marbles to blue marbles .* is \\?\(?(\d+):(\d+)\\?\). There are \\?\(?(\d+)\\?\) red", s)
    if m:
        r, b, red = map(int, m.groups())
        return F(red) / r * (r + b)
    m = grab(r"mean of the numbers ([\d, ]+), and \\?\(?x\\?\) is \\?\(?(\d+)", s)
    if m:
        nums = [int(x) for x in re.findall(r"\d+", m.group(1))]
        mean = int(m.group(2))
        return F(mean * (len(nums) + 1) - sum(nums))
    m = grab(r"median of the data set ([\d, ]+)", s)
    if m:
        nums = sorted(int(x) for x in re.findall(r"\d+", m.group(1)))
        return F(nums[len(nums) // 2])
    m = grab(r"bag has (\d+) red, (\d+) blue, and (\d+) green.*probability that it is red", s)
    if m and "not green" not in s:
        r, b, g = map(int, m.groups())
        return F(r) / (r + b + g)
    m = grab(r"bag has (\d+) red, (\d+) blue, and (\d+) green.*not green.*probability that it is red", s)
    if m:
        r, b, g = map(int, m.groups())
        return F(r) / (r + b)
    m = grab(r"line of best fit .*?y = (.+?)\\?\),.*\\?\(?x = (\d+)", s)
    if m:
        coef = parse_lin(m.group(1))
        if coef:
            return coef[0] * int(m.group(2)) + coef[1]
    m = grab(r"Two angles of a triangle measure \\?\(?(\d+)\^\\circ\\?\) and \\?\(?(\d+)\^\\circ", s)
    if m:
        return F(180 - int(m.group(1)) - int(m.group(2)))
    m = grab(r"hypotenuse of length (\d+) and one leg of length (\d+)", s)
    if m:
        h, a = map(int, m.groups())
        return F(int((h * h - a * a) ** 0.5))
    m = grab(r"right triangle has legs of length (\d+) and (\d+)", s)
    if m:
        a, b = map(int, m.groups())
        return F(int((a * a + b * b) ** 0.5))
    m = grab(r"rectangle has length (\d+) and width (\d+). What is its area", s)
    if m:
        return F(int(m.group(1)) * int(m.group(2)))
    m = grab(r"triangle has a base of length (\d+) and a corresponding height of (\d+)", s)
    if m:
        return F(int(m.group(1)) * int(m.group(2))) / 2
    m = grab(r"rectangular prism has length (\d+), width (\d+), and height (\d+)", s)
    if m:
        a, b, c = map(int, m.groups())
        return a * b * c
    m = grab(r"circle has radius (\d+). The circumference is", s)
    if m:
        return F(2 * int(m.group(1)))
    m = grab(r"cylinder has radius (\d+) and height (\d+). The volume is", s)
    if m:
        r, h = map(int, m.groups())
        return F(r * r * h)
    m = grab(r"\\tan A\\?", s)
    if m:
        opp = grab(r"opposite angle \\?\(?A\\?\) has length (\d+)", s)
        adj = grab(r"adjacent to angle \\?\(?A\\?\) has length (\d+)", s)
        return F(int(opp.group(1))) / int(adj.group(1))
    m = grab(r"\\sin A\\?", s)
    if m:
        opp = grab(r"opposite angle \\?\(?A\\?\) has length (\d+)", s)
        hyp = grab(r"hypotenuse has length (\d+)", s)
        return F(int(opp.group(1))) / int(hyp.group(1))
    m = grab(r"\\cos A\\?", s)
    if m:
        adj = grab(r"adjacent to angle \\?\(?A\\?\) has length (\d+)", s)
        hyp = grab(r"hypotenuse has length (\d+)", s)
        return F(int(adj.group(1))) / int(hyp.group(1))
    m = grab(r"minimum value of \\?\(?f\\?\)", s)
    if m:
        mm = grab(rf"f\(x\) = x\^2 - {NUM}x \+ {NUM}", s)
        if mm:
            b, c = int(mm.group(1)), int(mm.group(2))
            # vertex at x=b/2, value c - (b/2)^2
            return F(c) - F(b * b) / 4
    m = grab(r"sum of the solutions of \\?\(?(x\^2 [^=]+)= ([^\\]+)", s)
    if m:
        # for x^2 + bx + c = d, sum of roots = -b
        poly = m.group(1).replace(" ", "")
        # x^2+bx+c or x^2-bx+c or x^2-b or x^2+bx
        bm = re.search(r"x\^2([+-]\d+)x", poly)
        if bm:
            return F(-int(bm.group(1)))
        if re.fullmatch(r"x\^2([+-]\d+)?", poly):
            return F(0)
    m = grab(r"positive \\?\(?x\\?\)-coordinate of that other point", s)
    if m:
        mm = grab(rf"y = {NUM}x", s)
        if mm:
            return F(int(mm.group(1)))
    m = grab(r"\\?\(?y\\?\)-coordinate of that other point", s)
    if m:
        mm = grab(rf"y = {NUM}x", s)
        if mm:
            k = int(mm.group(1))
            return F(k * k)
    m = grab(rf"equivalent to \\?\(?\(x \+ {NUM}\)\(x \+ {NUM}\)\\?\)", s)
    if m:
        p, q = int(m.group(1)), int(m.group(2))
        return f"x^2 + {p+q}x + {p*q}"
    m = grab(rf"equivalent to \\?\(?x\^2 \+ {NUM}x \+ {NUM}\\?\)", s)
    if m:
        ssum, prod = int(m.group(1)), int(m.group(2))
        return ("factor", ssum, prod)
    m = grab(r"random sample of (\d+) voters, (\d+)\\% supported.*margin of error .* is (\d+)", s)
    if m:
        pct, moe = int(m.group(2)), int(m.group(3))
        return f"{pct - moe} to {pct + moe}"
    m = grab(r"consecutive interior angle", s)
    if m:
        ang = grab(r"measures \\?\(?(\d+)\^\\circ", s)
        return F(180 - int(ang.group(1)))
    m = grab(r"alternate interior angle", s)
    if m:
        ang = grab(r"measures \\?\(?(\d+)\^\\circ", s)
        return F(int(ang.group(1)))

    # Quadratics written as x^2 ± bx ± c = 0. Sum, greater root, or how many roots.
    qm = grab(r"\\?\(?(x\^2(?: [+-] \d+x)?(?: [+-] \d+)?) = 0\\?\)", s)
    if qm and any(w in s for w in ("sum of the solutions", "greater solution", "distinct real solutions")):
        roots = quad_roots(qm.group(1))
        if roots is None and "distinct real solutions" in s:
            return "q0"
        if roots is not None:
            r1, r2 = roots
            if "sum of the solutions" in s:
                return r1 + r2
            if "greater solution" in s:
                return max(r1, r2)
            if "distinct real solutions" in s:
                n = 1 if r1 == r2 else 2
                return {0: "q0", 1: "q1", 2: "q2"}[n]
    if "distinct real solutions" in s and "x^2" in s:
        qm = grab(r"\\?\(?(x\^2(?: [+-] \d+x)?(?: [+-] \d+)?) = 0", s)
        if qm and quad_roots(qm.group(1)) is None:
            return "q0"

    m = grab(r"solution of \\?\(?\\sqrt\{x \+ (\d+)\} = (\d+)", s)
    if m:
        add, b = int(m.group(1)), int(m.group(2))
        return F(b * b - add)
    m = grab(r"satisfies \\?\(?\\dfrac\{x \+ (-?\d+)\}\{x \+ (-?\d+)\} = (\d+)", s)
    if m:
        a, b, c = map(int, m.groups())
        # (x+a)/(x+b) = c
        if c == 1:
            return None
        return F(c * b - a) / F(1 - c)
    m = grab(r"satisfies \\?\(?\\dfrac\{x - (\d+)\}\{x \+ (-?\d+)\} = (\d+)", s)
    if m:
        a, b, c = int(m.group(1)), int(m.group(2)), int(m.group(3))
        # (x-a)/(x+b) = c
        if c == 1:
            return None
        return F(c * b + a) / F(1 - c)

    m = grab(r"f\(t\) = (\d+)\\cdot (\d+)\^\{t\}\\?\), what is the value of \\?\(?f\((\d+)\)", s)
    if m:
        a, b, t = map(int, m.groups())
        return F(a * (b ** t))
    m = grab(r"P\(t\) = (\d+)\\cdot (\d+)\^\{t\}\\?\).*What is \\?\(?P\((\d+)\)", s)
    if m:
        a, b, t = map(int, m.groups())
        return F(a * (b ** t))
    m = grab(r"P\(t\) = a \\cdot (\d+)\^\{t\}\\?\). If \\?\(?P\((\d+)\) = (\d+)", s)
    if m:
        b, t, val = map(int, m.groups())
        return F(val) / F(b ** t)

    m = grab(r"If \\?\(?f\(x\) = (.+?)\\?\), what is the value of \\?\(?f\((-?\d+)\)", s)
    if m and "g(x)" not in s:
        coef = parse_lin(m.group(1))
        if coef:
            x = int(m.group(2))
            return coef[0] * x + coef[1]
    m = grab(r"f\(x\) = (.+?)\\?\) and \\?\(?g\(x\) = (.+?)\\?\).*f\(g\((-?\d+)\)\)", s)
    if m:
        fcoef, gcoef = parse_lin(m.group(1)), parse_lin(m.group(2))
        if fcoef and gcoef:
            x = int(m.group(3))
            gx = gcoef[0] * x + gcoef[1]
            return fcoef[0] * gx + fcoef[1]
    m = grab(r"g\(x\) = f\(x - (\d+)\)\\?\). If \\?\(?f\((-?\d+)\) = (-?\d+)\\?\), what is the value of \\?\(?g\((\d+)\)", s)
    if m:
        h, arg, fv, t = int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
        if arg != t - h:
            return ("bad", f"shift argument {arg} is not {t}-{h}")
        return F(fv)

    m = grab(r"equivalent to \\?\(?x\^\{(\d+)\} \\cdot x\^\{(\d+)\}", s)
    if m:
        return ("pow", int(m.group(1)) + int(m.group(2)))
    m = grab(r"equivalent to \\?\(?\(x\^\{(\d+)\}\)\^\{(\d+)\}", s)
    if m:
        return ("pow", int(m.group(1)) * int(m.group(2)))
    m = grab(r"equivalent to \\?\(?\(x - (\d+)\)\(x \+ (-?\d+)\) - (\d+)\(x - (\d+)\)", s)
    if m:
        a, b, k, a2 = map(int, m.groups())
        if a != a2:
            return ("bad", "structure factors do not match")
        return ("struct", a, b - k)

    m = grab(r"value of \\?\(?(x(?: \+ y)?)\\?\) in the solution of \\?\(?(.+?)\\?\) and \\?\(?(.+?)\\?\)\?", s)
    if m:
        ask, left, right = m.group(1), m.group(2), m.group(3)
        eqs = [parse_xy(left), parse_xy(right)]
        if eqs[0] and eqs[1]:
            (a1, b1, c1), (a2, b2, c2) = eqs
            det = a1 * b2 - a2 * b1
            if det != 0:
                x = (c1 * b2 - c2 * b1) / det
                y = (a1 * c2 - a2 * c1) / det
                return x + y if "y" in ask else x

    m = grab(r"How many solutions does the system \\?\(?y = (.+?)\\?\) and \\?\(?(\d*)y = (.+?)\\?\) have", s)
    if m:
        left = parse_lin(m.group(1))
        k = int(m.group(2) or "1")
        right = parse_lin(m.group(3))
        if left and right and k != 0:
            slope = right[0] / k
            intercept = right[1] / k
            if slope != left[0]:
                return "one_sys"
            return "infinite" if intercept == left[1] else "none"

    m = grab(r"How many solutions does the equation \\?\(?(.+?) = (.+?)\\?\) have", s)
    if m:
        left, right = expand_side(m.group(1)), expand_side(m.group(2))
        if left and right:
            if left[0] == right[0]:
                return "infinite" if left[1] == right[1] else "none"
            return "one_sys"

    if "is a solution of the inequality" in s and item.choices:
        m = grab(r"inequality \\?\(?(-?\d+)x \+ (-?\d+)y > (-?\d+)", s)
        if m:
            p, q, k = map(int, m.groups())
            goods = []
            for ch in item.choices:
                pm = re.search(r"\((-?\d+), (-?\d+)\)", ch)
                if pm and p * int(pm.group(1)) + q * int(pm.group(2)) > k:
                    goods.append(ch)
            if len(goods) != 1:
                return ("bad", f"inequality has {len(goods)} solutions among the choices")
            return ("exact", goods[0])

    if "amount remaining after" in s and item.choices:
        m = grab(r"gives ([a-z]), the amount remaining after ([a-z]) ", s)
        nums = [int(n) for n in re.findall(r"\d+", s.split("Which")[0])]
        if m and len(nums) >= 2 and any(w in s for w in ("drains", "spends", "loses")):
            dep, ind = m.group(1), m.group(2)
            start, rate = nums[0], nums[1]
            expect = f"{dep} = {start} - {rate}{ind}"
            return ("exact_flat", expect)

    if "radius of the circle" in s:
        m = grab(r"\(x ([+-]) (\d+)\)\^2 \+ \(y ([+-]) (\d+)\)\^2 = (\d+)", s)
        if m:
            return F(int(int(m.group(5)) ** 0.5)) if int(int(m.group(5)) ** 0.5) ** 2 == int(m.group(5)) else None
        m = grab(r"x\^2 - (\d+)x \+ y\^2 \+ (\d+)y = (-?\d+)", s)
        if m:
            h2, k2, right = map(int, m.groups())
            if h2 % 2 or k2 % 2:
                return None
            h, k = h2 // 2, k2 // 2
            r2 = right + h * h + k * k
            root = int(r2 ** 0.5)
            if root * root == r2:
                return F(root)

    m = grab(r"corresponding sides measure (\d+) and (\d+)\. Another side of the smaller triangle measures (\d+)", s)
    if m:
        a, ak, b = map(int, m.groups())
        if a == 0:
            return None
        return F(ak) / a * b
    m = grab(r"hypotenuse of length \\?\(?(\d+)\\sqrt\{2\}", s)
    if m:
        return F(int(m.group(1)))
    m = grab(r"opposite the \\?\(?30\^\\circ\\?\) angle has length (\d+)", s)
    if m:
        return F(2 * int(m.group(1)))
    m = grab(r"radius (\d+)\. What is the length of a (\d+)\\?\(\^\\circ\\?\) arc", s)
    if m:
        r, deg = int(m.group(1)), int(m.group(2))
        return Fraction(deg * r, 180)

    m = grab(r"Among juniors, (\d+) joined and (\d+) did not. Among seniors, (\d+) joined and (\d+) did not", s)
    if m and "joined the club" in s:
        a, b, c, d = map(int, m.groups())
        return Fraction(a, a + c)

    if item.skill == "Evaluating statistical claims" and item.choices:
        rules = (
            ("homework format", "Randomly assign students at the school"),
            ("warm-up", "Randomly assign athletes"),
            ("chess club", "already differ"),
            ("live on campus", "random sample of students from the college"),
            ("margin of error", "Increase the sample size"),
            ("reading program", "support a conclusion about the effect of the program"),
        )
        for needle, phrase in rules:
            if needle in s:
                return ("contains", phrase)
    return None


def spr_ok(text):
    if re.search(r"\d+ \d+/\d+", text):
        return False
    if any(ch in text for ch in "%$, "):
        return False
    body = text[1:] if text.startswith("-") else text
    limit = 6 if text.startswith("-") else 5
    return 1 <= len(text) <= limit and len(body) <= 5


def check_math(items):
    fails = []
    checked = 0
    skipped = []
    for i, it in enumerate(items, 1):
        if it.kind == "MC":
            if len(it.choices) != 4 or len(set(it.choices)) != 4:
                fails.append((i, "choice set", it.stem[:80]))
                continue
        else:
            if not spr_ok(it.key):
                fails.append((i, "SPR format", it.key))
        got = solve_math(it)
        if got is None:
            skipped.append(it.skill)
            continue
        checked += 1
        value, raw = keyed(it)
        if isinstance(got, tuple):
            kind = got[0]
            if kind == "factor":
                _, ssum, prod = got
                signed = re.findall(r"x\s*([+-])\s*(\d+)", raw)
                if len(signed) >= 2:
                    n1 = int(signed[0][1]) * (1 if signed[0][0] == "+" else -1)
                    n2 = int(signed[1][1]) * (1 if signed[1][0] == "+" else -1)
                    if n1 + n2 == ssum and n1 * n2 == prod:
                        continue
                fails.append((i, "factor", raw, got))
            elif kind == "bad":
                fails.append((i, "bad item", got[1], it.stem[:140]))
            elif kind == "exact":
                if raw != got[1]:
                    fails.append((i, "choice", raw, got[1]))
            elif kind == "exact_flat":
                def flat(t):
                    return t.replace("\\(", "").replace("\\)", "").replace(" ", "")
                if flat(raw) != flat(got[1]):
                    fails.append((i, "model", raw, got[1]))
            elif kind == "contains":
                if got[1] not in raw:
                    fails.append((i, "claim", raw, got[1]))
            elif kind == "pow":
                if f"x^{{{got[1]}}}" not in raw:
                    fails.append((i, "exponent", raw, got[1]))
            elif kind == "struct":
                a, second = got[1], got[2]
                want = f"(x - {a})(x + {second})"
                if want.replace(" ", "") not in raw.replace(" ", ""):
                    fails.append((i, "structure", raw, want))
            else:
                fails.append((i, "unhandled", got))
            continue
        if isinstance(got, str) and got.startswith("x "):
            if got.replace(" ", "") not in raw.replace(" ", "").replace("\\", ""):
                bound = got.split()[-1]
                if bound not in raw:
                    fails.append((i, "inequality", raw, got))
            continue
        if got == "infinite":
            if "infinit" not in raw.lower():
                fails.append((i, "solutions", raw, got))
            continue
        if got == "none":
            low = raw.lower().strip()
            if not (low.startswith("none") or low.startswith("no solution")):
                fails.append((i, "solutions", raw, got))
            continue
        if got == "one_sys":
            if "exactly one" not in raw.lower():
                fails.append((i, "solutions", raw, got))
            continue
        if got == "q0" and raw.strip().lower() != "none":
            fails.append((i, "roots", raw, got))
            continue
        if got == "q0":
            continue
        if got == "q1" and "exactly one" not in raw.lower():
            fails.append((i, "roots", raw, got))
            continue
        if got == "q1":
            continue
        if got == "q2" and "exactly two" not in raw.lower():
            fails.append((i, "roots", raw, got))
            continue
        if got == "q2":
            continue
        if isinstance(got, str) and " to " in got:
            lo, hi = got.split(" to ")
            if lo not in raw or hi not in raw:
                fails.append((i, "margin", raw, got))
            continue
        if isinstance(got, str) and got.startswith("x^2"):
            compact = raw.replace(" ", "").replace("\\", "")
            if got.replace(" ", "") not in compact and got.replace(" ", "") not in raw:
                fails.append((i, "expand", raw, got))
            continue
        if value is None:
            skipped.append(it.skill + " text")
            checked -= 1
            continue
        if F(value) != F(got):
            fails.append((i, it.skill, raw, got, it.stem[:160]))
    return fails, checked, Counter(skipped)


def _flat_choice(text):
    return " ".join(text.split())


def rw_meaning(q):
    """Re-derive what the keyed choice must do. Does not trust the stored index."""
    reasons = []
    skill = q["skill"]
    correct = q["correct"]
    stim = " ".join(p for p in q["parts"] if isinstance(p, str))
    official = BLUEPRINT["reading_writing"]["stems"]
    if skill in official and q["stem"] != official[skill]:
        reasons.append("command stem is not the Digital SAT wording")

    if skill == "Form, Structure, and Sense":
        reasons.extend(form_rule(stim, correct, q["choices"]))
    elif skill == "Boundaries":
        reasons.extend(boundary_rule(stim, correct, q["choices"]))
    elif skill == "Command of Evidence (Quantitative)":
        reasons.extend(quant_rule(q))
    elif skill == "Rhetorical Synthesis":
        reasons.extend(rhetoric_rule(stim, correct))
    elif skill == "Transitions":
        reasons.extend(transition_rule(stim, correct))
    elif skill == "Words in Context":
        if "________" not in stim:
            reasons.append("words-in-context item has no blank")
    return reasons


def form_rule(stim, correct, choices):
    out = []
    if "it's" in choices and "its" in choices and correct != "its":
        out.append("singular possessive must be its, not it's")
    if "who" in choices and "whom" in choices and "________" in stim:
        after = stim.split("________", 1)[1].strip()
        first = after.split()[0].lower() if after else ""
        expect = "whom" if first in {"we", "they", "he", "she", "i"} or first == "the" else "who"
        if correct != expect:
            out.append(f"who/whom should be {expect}")
    if "they" in choices and correct != "they":
        plural = ("visitors", "players", "students", "drivers", "guests", "interns", "musicians", "hikers", "authors", "jurors", "cooks", "neighbors")
        head = stim.split("________")[0]
        if any(p in head for p in plural):
            out.append("a plural noun needs they, not a shift of person")
    if re.search(r"\b(In \d{4}|Yesterday|Last)\b", stim) and re.search(
        r"\b(reached|passed|opened|closed|planted|boarded|mixed|published|forgot|banned|knocked|tested|froze|adopted|returned|printed)\b",
        stim,
    ):
        if correct.startswith("will") or correct.startswith("has ") or (correct.endswith("s") and correct not in {"was", "has"}):
            out.append("a past-time clause joined by and needs the simple past")
    if re.search(r"\bto \w[\w ]*, to \w[\w ]*, and ________", stim) and not correct.startswith("to "):
        out.append("the series is to-infinitives")
    if re.search(r"\b(raising|reading|washing|identifying) ", stim) and "and ________" in stim:
        if stim.startswith("The plan calls") or "reading closely" in stim:
            if not correct.endswith("ing") and "ing " not in correct:
                out.append("the series is gerunds")
    m = re.search(r"(?:neither|either) the (.+?) (?:nor|or) the (.+?) ________", stim)
    if m:
        near = m.group(2).strip().split()[-1]
        plural = near.endswith("s")
        if plural and correct in {"was", "is", "has been"}:
            out.append("the nearer subject is plural")
        if not plural and correct in {"were", "are", "have been"}:
            out.append("the nearer subject is singular")
    if re.match(r"(The|Each|Every|Neither|One|Nobody|Everybody|Half|A group|A |Not one|Two-thirds|Mathematics|The news)", stim) and correct in {"are", "were", "have"}:
        if "________" in stim and not re.search(r"(?:nor|or) the \w+s ________", stim):
            out.append("the grammatical head is singular")
    return out


def boundary_rule(stim, correct, choices):
    out = []
    blob = " ".join(choices)
    if "therefore" in blob and correct != "; therefore, ":
        out.append("a conjunctive adverb between clauses needs a semicolon and a comma")
    if "however" in blob and "therefore" not in blob and correct != "; however, ":
        out.append("a conjunctive adverb between clauses needs a semicolon and a comma")
    word_sets = [tuple(re.findall(r"[A-Za-z0-9']+", c)) for c in choices]
    if len(set(word_sets)) == 1 and len(word_sets[0]) >= 2:
        wrapped = [
            c for c in choices
            if (t := c.strip()).startswith(",") and t.endswith(",") and t.strip(",").strip()
        ]
        if wrapped and correct not in wrapped:
            out.append("a nonrestrictive appositive needs commas on both sides")
    return out


def quant_rule(q):
    table = next((p for p in q["parts"] if isinstance(p, dict) and "rows" in p), None)
    if not table:
        return ["quantitative item has no table"]
    rows = [(r[0], int(r[1])) for r in table["rows"]]
    lookup = dict(rows)
    text = q["correct"]
    m = re.search(r"^(.+?) (?:shows a|is) (higher|lower)(?: value)? \((\d+)\b", text)
    m2 = re.search(r" than (.+?) \((\d+)\b", text)
    if not m or not m2:
        return ["quantitative key does not cite two table values"]
    g1, word, n1 = m.group(1), m.group(2), int(m.group(3))
    g2, n2 = m2.group(1), int(m2.group(2))
    if lookup.get(g1) != n1 or lookup.get(g2) != n2:
        return [f"cited numbers do not match the table ({g1}={lookup.get(g1)}, {g2}={lookup.get(g2)})"]
    if (word == "higher" and not n1 > n2) or (word == "lower" and not n1 < n2):
        return ["the comparison in the key is false for those numbers"]
    labels = [r[0] for r in rows]
    if "support" in q["stem"]:
        if g1 != labels[-1] or g2 != labels[0]:
            return ["a support answer should compare the last row with the first in the direction of the claim"]
    if "challenge" in q["stem"]:
        if {g1, g2} == {labels[0], labels[-1]}:
            return ["an end-to-end comparison does not challenge a claim that every step moved the same way"]
        if abs(labels.index(g1) - labels.index(g2)) != 1:
            return ["a challenge should point at one reversed step"]
    return []


def rhetoric_rule(stim, correct):
    res = re.search(r"Result reported: (.+?)\.\n?", stim)
    lim = re.search(r"Caution the researcher notes: (.+?)\.\n?", stim)
    later = re.search(r"A later observation: (.+?)\.\n?", stim)
    if not (res and lim and later):
        return ["rhetorical notes could not be read"]
    evidence, limit, follow = res.group(1), lim.group(1), later.group(1)
    if "acknowledge a limit" in stim:
        if evidence not in correct or limit not in correct:
            return ["the goal asks for the result and the caution, and the key omits one"]
        if "not the case" in correct or "removes any need" in correct:
            return ["the key denies the result or the caution"]
    elif "result only" in stim:
        if evidence not in correct:
            return ["the goal asks for the result, and the key omits it"]
        if limit in correct or (follow in correct and follow not in evidence):
            return ["the goal says not to add a limit or a later observation"]
        if "not the case" in correct:
            return ["the key denies the result"]
    return []


def transition_rule(stim, correct):
    import build_rw
    found = None
    for rel, pairs in (
        ("result", build_rw.CAUSES),
        ("contrast", build_rw.CONTRASTS),
        ("example", build_rw.EXAMPLES),
        ("addition", build_rw.ADDITIONS),
    ):
        for a, b in pairs:
            if a in stim and b in stim:
                found = rel
                break
        if found:
            break
    if not found:
        return ["transition pair was not recognized"]
    allowed = build_rw.TRANS_REL[found]
    if correct not in allowed:
        return [f"the two sentences are a {found} relation, so the transition cannot be {correct}"]
    return []


def check_rw(items):
    fails = []
    domains = Counter()
    for i, q in enumerate(items, 1):
        domains[q["domain"]] += 1
        if len(q["choices"]) != 4 or len(set(q["choices"])) != 4:
            fails.append((i, "choices", q["skill"]))
        if q["correct"] not in q["choices"]:
            fails.append((i, "key missing", q["skill"]))
        if q["choices"]["ABCD".index(q["key"])] != q["correct"]:
            fails.append((i, "letter", q["skill"]))
        if not q["stem"] or not q["parts"]:
            fails.append((i, "empty", q["skill"]))
        # Boundaries: a comma splice is never the keyed answer when a semicolon or comma-FANBOYS is available.
        if q["skill"] == "Boundaries" and q["correct"].strip() in {",", " , "}:
            fails.append((i, "comma splice keyed", q["parts"]))
        for reason in rw_meaning(q):
            fails.append((i, reason, q["skill"]))
    expect = {
        "Craft and Structure": 280,
        "Information and Ideas": 260,
        "Standard English Conventions": 260,
        "Expression of Ideas": 200,
    }
    for name, n in expect.items():
        if domains[name] != n:
            fails.append((0, "quota", name, domains[name], n))
    return fails, domains


def main():
    import generate_sat_math as math_bank
    import build_rw

    math_items = math_bank.build()
    rw_items = build_rw.assemble()
    assert len(math_items) == 1000, len(math_items)
    assert len(rw_items) == 1000, len(rw_items)

    m_fail, m_checked, m_skip = check_math(math_items)
    r_fail, r_domains = check_rw(rw_items)
    kinds = Counter(it.kind for it in math_items)
    diffs = Counter(it.difficulty for it in math_items)
    rw_diff = Counter(q["difficulty"] for q in rw_items)

    report = HERE / "AUDIT.md"
    lines = [
        "# Digital SAT bank audit",
        "",
        "Original items. Official Bluebook directions (Fall 2026) and practice tests 2, 3, 4, 5, 6, and 11 were used for structure only. No College Board question is reprinted.",
        "",
        "## Blueprint used",
        "",
        "- Reading and Writing: 54 questions, two modules of 27, 32 minutes each. All four-option, one best answer.",
        "- Math: 44 questions, two modules of 22, 35 minutes each. Calculator allowed throughout. About 75% multiple choice and about 25% student-produced response.",
        "- A module cannot be reopened. Figures are drawn to scale unless marked. SPR answers reject mixed numbers and symbols.",
        "",
        "The practice banks scale those weights to 1,000 items each.",
        "",
        "## Math",
        "",
        f"- Items: {len(math_items)}",
        f"- Multiple choice / student-produced: {kinds['MC']} / {kinds['SPR']}",
        f"- Difficulty: {dict(diffs)}",
        f"- Independently recomputed from the stem: {m_checked}",
        f"- Not recomputed: {sum(m_skip.values())}",
        f"- Mismatches: {len(m_fail)}",
        "",
        "Numeric math answers were recomputed from the printed stem by a second solver, not by replaying the generator. That covers linear equations and inequalities, slopes, systems, percent, ratio, mean, median, probability, quadratics, radicals, rational equations, exponents, function values, circles, similarity, special right triangles, arc length, and the statistical-claim designs.",
        "",
        "Reading and Writing keys were checked against the grammar or the data, not against the stored index: subject-verb agreement, who/whom, its/it's, parallel structure, past-tense coordination, neither/nor with the nearer subject, conjunctive adverbs, nonrestrictive appositives, transition family, rhetorical-synthesis goals, and every number cited from a table.",
        "",
        "## Reading and Writing",
        "",
        f"- Items: {len(rw_items)}",
        f"- Domains: {dict(r_domains)}",
        f"- Difficulty: {dict(rw_diff)}",
        f"- Key and choice failures: {len(r_fail)}",
        "",
    ]
    if m_fail:
        lines.append("### Math mismatches")
        lines.append("")
        for row in m_fail[:30]:
            lines.append(f"- {row}")
        lines.append("")
    if r_fail:
        lines.append("### Reading and Writing failures")
        lines.append("")
        for row in r_fail[:30]:
            lines.append(f"- {row}")
        lines.append("")
    if not m_fail and not r_fail:
        lines.append("No mismatch was found between a recomputed answer and the printed key.")
        lines.append("")
    report.write_text("\n".join(lines))
    print(report.read_text())
    print("SKIP", m_skip.most_common())
    if m_fail or r_fail:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
