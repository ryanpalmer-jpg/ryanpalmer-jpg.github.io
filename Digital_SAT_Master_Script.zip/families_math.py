"""Distinct Digital SAT math families.

Each family is a different task (a different unknown, a different representation,
or a different decision), not the same equation with new coefficients. Counts
follow the College Board domain weights: Algebra 350, Advanced Math 350,
Problem-Solving and Data Analysis 150, Geometry and Trigonometry 150.
"""

from fractions import Fraction

rng = emit = emit_text_mc = F = lin = None


def init(rng_, emit_, emit_text_mc_, F_, lin_):
    global rng, emit, emit_text_mc, F, lin
    rng, emit, emit_text_mc, F, lin = rng_, emit_, emit_text_mc_, F_, lin_


def quad_tex(s, p):
    expr = "x^2"
    if s > 0:
        expr += f" - {s}x"
    elif s < 0:
        expr += f" + {-s}x"
    if p > 0:
        expr += f" + {p}"
    elif p < 0:
        expr += f" - {-p}"
    return expr


def roots_pair():
    r1 = rng.randint(-5, 8)
    r2 = rng.randint(-4, 9)
    if r1 == r2:
        r2 += 3
    return r1, r2


# ---------- Algebra ----------

def alg_one_step(diff):
    a = rng.choice([2, 3, 4, 5, 6, 8, 9])
    x = rng.randint(2, 14)
    b = rng.randint(1, 12)
    stem = f"What is the solution to the equation \\({lin(a, b)} = {a * x + b}\\)?"
    return emit("Algebra", "Linear equations in one variable: one step", diff, stem, x, [x + 1, x - 1, b, a * x])


def alg_both_sides(diff):
    a = rng.randint(3, 9)
    c = rng.randint(1, a - 1)
    x = rng.randint(-6, 12) or 4
    b = rng.randint(-8, 10)
    d = (a - c) * x + b
    stem = f"What value of \\(x\\) satisfies the equation \\({lin(a, b)} = {lin(c, d)}\\)?"
    return emit("Algebra", "Linear equations in one variable: both sides", diff, stem, x, [F(d - b), -x, x + c, b - d])


def alg_distribute(diff):
    a = rng.randint(2, 5)
    b = rng.randint(1, 6)
    c = rng.randint(2, 7)
    if a == c:
        c = a + 1
    x = rng.randint(-4, 9) or 3
    d = a * (x + b) - c * x
    stem = f"What is the solution to \\({a}(x + {b}) = {lin(c, d)}\\)?"
    return emit("Algebra", "Linear equations in one variable: distribution", diff, stem, x, [-x, x + a, x + b, d])


def alg_equation_count(diff):
    a = rng.randint(2, 8)
    b = rng.randint(1, 9)
    k = rng.randint(2, 4)
    infinite = rng.randrange(2) == 0
    if infinite:
        stem = f"How many solutions does the equation \\({k}({lin(a, b)}) = {lin(k * a, k * b)}\\) have?"
        idx = 3
    else:
        stem = f"How many solutions does the equation \\({lin(a, b)} = {lin(a, b + rng.randint(1, 6))}\\) have?"
        idx = 2
    choices = ["Exactly one solution", "Exactly two solutions", "No solution", "Infinitely many solutions"]
    return emit_text_mc("Algebra", "Linear equations in one variable: how many solutions", diff, stem, choices, idx)


def alg_slope_points(diff):
    x1, y1 = rng.randint(0, 5), rng.randint(0, 6)
    run = rng.choice([1, 2, 3, 4])
    rise = rng.choice([1, 2, 3, 4, 6, -2, -3])
    stem = f"What is the slope of the line through \\(({x1}, {y1})\\) and \\(({x1 + run}, {y1 + rise})\\)?"
    m = Fraction(rise, run)
    return emit("Algebra", "Linear equations in two variables: slope from two points", diff, stem, m, [Fraction(run, rise) if rise else 0, -m, rise, run])


def alg_point_on_line(diff):
    m = rng.choice([-4, -3, -2, -1, 1, 2, 3, 4, 5])
    b = rng.randint(-6, 8)
    x = rng.randint(-3, 6)
    y = m * x + b
    stem = f"The line with equation \\(y = {lin(m, b)}\\) passes through the point \\(({x}, k)\\). What is the value of \\(k\\)?"
    return emit("Algebra", "Linear functions: value on the line", diff, stem, y, [m * x - b, m + b, x + b, -y if y else 1])


def alg_parallel(diff):
    m = rng.choice([-4, -3, -2, 1, 2, 3, 4, 5])
    b = rng.randint(-5, 6)
    stem = f"A line is parallel to the line \\(y = {lin(m, b)}\\). What is the slope of the parallel line?"
    return emit("Algebra", "Linear equations in two variables: parallel slope", diff, stem, m, [-m, -1 / m if m else 1, m + 1, b])


def alg_perpendicular(diff):
    m = Fraction(rng.choice([1, 2, 3, 4]), rng.choice([1, 2, 3]))
    stem = f"A line is perpendicular to the line \\(y = {lin(m, rng.randint(-3, 4))}\\). What is the slope of the perpendicular line?"
    return emit("Algebra", "Linear equations in two variables: perpendicular slope", diff, stem, -1 / m, [m, -m, 1 / m, m + 1])


def alg_meaning_slope(diff):
    start = rng.choice([40, 60, 80, 100, 120, 150])
    rate = rng.choice([2, 3, 4, 5, 6, 8])
    stories = [
        ("water left in a tank, in gallons", "the number of minutes the tank has been draining"),
        ("money left, in dollars", "the number of weeks of spending"),
        ("charge left, in percent", "the number of hours of use"),
    ]
    what, ind = stories[rng.randrange(3)]
    stem = (
        f"In the equation \\(y = {start} - {rate}x\\), \\(y\\) is {what} and \\(x\\) is {ind}. "
        f"What does {rate} represent?"
    )
    choices = [
        f"The amount by which y decreases for each increase of 1 in x",
        f"The amount by which y increases for each increase of 1 in x",
        f"The value of y when x is 0",
        f"The value of x when y is 0",
    ]
    return emit_text_mc("Algebra", "Linear functions: meaning of the rate", diff, stem, choices, 0)


def alg_meaning_intercept(diff):
    start = rng.choice([40, 60, 80, 100, 120, 180])
    rate = rng.choice([2, 3, 4, 5, 8])
    stem = (
        f"In the equation \\(y = {start} - {rate}x\\), \\(y\\) is the amount remaining and \\(x\\) is the number of hours. "
        f"What does {start} represent?"
    )
    choices = [
        "The value of y when x is 0",
        f"The amount by which y decreases for each increase of 1 in x",
        "The value of x when y is 0",
        "The amount by which x increases for each increase of 1 in y",
    ]
    return emit_text_mc("Algebra", "Linear functions: meaning of the intercept", diff, stem, choices, 0)


def alg_which_model(diff):
    start = rng.choice([40, 60, 80, 120, 150, 200])
    rate = rng.choice([3, 4, 5, 6, 8, 10])
    contexts = [
        (f"A tank contains {start} gallons and drains at {rate} gallons per minute.", "g", "m", "minutes"),
        (f"A student has \\${start} and spends \\${rate} each week.", "d", "w", "weeks"),
        (f"A battery is at {start} percent and loses {rate} percentage points each hour.", "p", "h", "hours"),
    ]
    intro, dep, ind, ind_name = contexts[rng.randrange(3)]
    stem = f"{intro} Which equation gives {dep}, the amount remaining after {ind} {ind_name}?"
    choices = [
        f"\\({dep} = {start} - {rate}{ind}\\)",
        f"\\({dep} = {rate}{ind} - {start}\\)",
        f"\\({dep} = {start} + {rate}{ind}\\)",
        f"\\({dep} = {rate} - {start}{ind}\\)",
    ]
    return emit_text_mc("Algebra", "Linear functions: write the model", diff, stem, choices, 0)


def alg_inequality(diff):
    a = rng.choice([2, 3, 4, 5])
    bound = rng.randint(2, 12)
    b = rng.randint(1, 8)
    right = a * bound - b
    stem = f"What is the solution set of \\({lin(a, -b)} < {right}\\)?"
    return emit_text_mc(
        "Algebra", "Linear inequalities: one variable", diff, stem,
        [f"\\(x < {bound}\\)", f"\\(x > {bound}\\)", f"\\(x < {bound - 1}\\)", f"\\(x \\le {bound}\\)"],
        0,
    )


def alg_inequality_flip(diff):
    a = rng.choice([2, 3, 4, 5])
    bound = rng.randint(2, 10)
    b = rng.randint(1, 8)
    right = -a * bound + b
    stem = f"What is the solution set of \\({lin(-a, b)} < {right}\\)?"
    return emit_text_mc(
        "Algebra", "Linear inequalities: dividing by a negative", diff, stem,
        [f"\\(x > {bound}\\)", f"\\(x < {bound}\\)", f"\\(x > {bound + 1}\\)", f"\\(x \\ge {bound}\\)"],
        0,
    )


def alg_half_plane(diff):
    p, q = rng.choice([(2, 1), (1, 2), (3, 1), (2, 3), (4, 1)])
    x0, y0 = rng.randint(1, 6), rng.randint(1, 6)
    k = p * x0 + q * y0
    good = (x0 + 1, y0)
    bads = []
    for pt in [(x0 - 2, y0), (x0, y0 - 2), (0, 0), (x0 - 1, y0 - 1), (1, 0)]:
        if p * pt[0] + q * pt[1] <= k and pt not in bads:
            bads.append(pt)
        if len(bads) == 3:
            break
    stem = f"Which point \\((x, y)\\) is a solution of the inequality \\({p}x + {q}y > {k}\\)?"
    choices = [f"\\(({good[0]}, {good[1]})\\)"] + [f"\\(({a}, {b})\\)" for a, b in bads]
    return emit_text_mc("Algebra", "Linear inequalities: test a point", diff, stem, choices, 0)


def alg_system_add(diff):
    x = rng.randint(-4, 9)
    y = rng.randint(-4, 9)
    stem = (
        f"The solution of the system \\(x + y = {x + y}\\) and \\(x - y = {x - y}\\) is \\((x, y)\\). "
        f"What is the value of \\(x\\)?"
    )
    return emit("Algebra", "Systems: add and subtract", diff, stem, x, [y, x + y, x - y, -x])


def alg_system_x(diff):
    x = rng.randint(-3, 8)
    y = rng.randint(-3, 8)
    pairs = [(2, 3, 1, -1), (3, 2, 1, 2), (4, 1, 2, -1), (2, 5, 1, -2), (5, 2, 3, 1)]
    a, b, c, e = pairs[rng.randrange(len(pairs))]
    r1 = a * x + b * y
    r2 = c * x + e * y
    from generate_sat_math import coef_var
    second = f"{coef_var(c, 'x', True)}{coef_var(e, 'y')}"
    first = f"{coef_var(a, 'x', True)}{coef_var(b, 'y')}"
    stem = f"What is the value of \\(x\\) in the solution of \\({first} = {r1}\\) and \\({second} = {r2}\\)?"
    return emit("Algebra", "Systems: solve for one variable", diff, stem, x, [y, x + y, x - y, r1])


def alg_system_sum(diff):
    x = rng.randint(-2, 8)
    y = rng.randint(-2, 8)
    a, b, c, e = rng.choice([(2, 1, 1, 1), (3, 1, 1, 2), (2, 3, 1, 1), (4, 1, 1, 3)])
    r1 = a * x + b * y
    r2 = c * x + e * y
    from generate_sat_math import coef_var
    first = f"{coef_var(a, 'x', True)}{coef_var(b, 'y')}"
    second = f"{coef_var(c, 'x', True)}{coef_var(e, 'y')}"
    stem = f"What is the value of \\(x + y\\) in the solution of \\({first} = {r1}\\) and \\({second} = {r2}\\)?"
    return emit("Algebra", "Systems: value of x + y", diff, stem, x + y, [x, y, x - y, r1])


def alg_tickets(diff):
    adult = rng.randint(8, 18)
    student = rng.randint(4, 11)
    combos = [(2, 1, 1, 3), (3, 1, 1, 2), (2, 3, 1, 1), (4, 1, 1, 2)]
    a1, s1, a2, s2 = combos[rng.randrange(len(combos))]
    t1 = a1 * adult + s1 * student
    t2 = a2 * adult + s2 * student
    def nphrase(n, word):
        return f"{n} {word}" + ("" if n == 1 else "s")
    stem = (
        f"{nphrase(a1, 'adult ticket')} and {nphrase(s1, 'student ticket')} cost \\${t1}. "
        f"{nphrase(a2, 'adult ticket')} and {nphrase(s2, 'student ticket')} cost \\${t2}. "
        f"What is the price, in dollars, of one adult ticket?"
    )
    return emit("Algebra", "Systems: two purchases", diff, stem, adult, [student, adult + student, t1, t2])


def alg_system_count(diff):
    m = rng.choice([2, 3, 4, 5])
    b1 = rng.randint(-3, 6)
    if rng.randrange(2) == 0:
        k = rng.choice([2, 3])
        stem = f"How many solutions does the system \\(y = {lin(m, b1)}\\) and \\({k}y = {lin(k * m, k * b1)}\\) have?"
        idx = 3
    else:
        b2 = b1 + rng.choice([1, 2, 3, 4])
        stem = f"How many solutions does the system \\(y = {lin(m, b1)}\\) and \\(y = {lin(m, b2)}\\) have?"
        idx = 0
    choices = ["None", "Exactly one", "Exactly two", "Infinitely many"]
    return emit_text_mc("Algebra", "Systems: how many solutions", diff, stem, choices, idx)


def alg_table(diff):
    x1 = rng.choice([0, 1, 2])
    dx = rng.choice([2, 3, 4])
    slope = rng.choice([2, 3, 4, 5, -2, -3])
    y1 = rng.randint(3, 18)
    x2 = x1 + dx
    y2 = y1 + slope * dx
    x3 = x2 + dx
    y3 = y2 + slope * dx
    stem = f"A linear function satisfies \\(f({x1}) = {y1}\\) and \\(f({x2}) = {y2}\\). What is the value of \\(f({x3})\\)?"
    return emit("Algebra", "Linear functions: missing table value", diff, stem, y3, [y2, y1, slope, y3 + dx])


def alg_speed(diff):
    hours = rng.choice([2, 3, 4, 5, 6])
    rate = rng.randint(35, 70)
    stem = f"A car travels \\({rate * hours}\\) miles in \\({hours}\\) hours at a constant speed. What is the speed in miles per hour?"
    return emit("Algebra", "Linear functions: constant rate", diff, stem, rate, [rate * hours, hours, rate + hours, rate * 2])


def alg_perimeter(diff):
    length = rng.randint(4, 16)
    width = rng.randint(2, 10)
    p = 2 * (length + width)
    stem = f"The perimeter of a rectangle is \\({p}\\) and the width is \\({width}\\). What is the length?"
    return emit("Algebra", "Linear equations: solve a formula", diff, stem, length, [p - width, p // 2, width, length + width])


def alg_budget(diff):
    cost = rng.choice([3, 4, 5, 6, 8])
    fee = rng.choice([2, 4, 5, 6, 10])
    n = rng.randint(4, 12)
    rem = rng.choice([0, 1, 2])
    budget = cost * n + fee + rem
    stem = (
        f"Notebooks cost \\${cost} each, and shipping is a flat \\${fee}. "
        f"A student can spend at most \\${budget}. What is the greatest number of notebooks the student can buy?"
    )
    return emit("Algebra", "Linear inequalities: greatest integer in a budget", diff, stem, n, [n + 1, n - 1, budget // cost, fee])


def alg_parallel_intercept(diff):
    m = rng.choice([-3, -2, -1, 1, 2, 3, 4])
    b = rng.randint(-4, 5)
    x = rng.randint(-2, 5)
    y = rng.randint(-3, 12)
    intercept = y - m * x
    stem = (
        f"A line is parallel to \\(y = {lin(m, b)}\\) and passes through \\(({x}, {y})\\). "
        f"What is the \\(y\\)-intercept of the parallel line?"
    )
    return emit("Algebra", "Linear equations in two variables: parallel line through a point", diff, stem, intercept, [b, y, m, intercept + m])


def alg_sign_of_line(diff):
    # Four sign patterns. The stem names the pattern; the key is the matching equation.
    patterns = [
        ("a negative slope and a positive y-intercept", "\\(y = -2x + 5\\)", ["\\(y = 2x + 5\\)", "\\(y = -2x - 5\\)", "\\(y = 2x - 5\\)"]),
        ("a positive slope and a negative y-intercept", "\\(y = 3x - 4\\)", ["\\(y = -3x - 4\\)", "\\(y = 3x + 4\\)", "\\(y = -3x + 4\\)"]),
        ("a negative slope and a negative y-intercept", "\\(y = -4x - 1\\)", ["\\(y = 4x - 1\\)", "\\(y = -4x + 1\\)", "\\(y = 4x + 1\\)"]),
        ("a positive slope and a positive y-intercept", "\\(y = 2x + 7\\)", ["\\(y = -2x + 7\\)", "\\(y = 2x - 7\\)", "\\(y = -2x - 7\\)"]),
    ]
    words, good, bads = patterns[rng.randrange(4)]
    stem = f"Which equation has {words}?"
    return emit_text_mc("Algebra", "Linear equations in two variables: sign of slope and intercept", diff, stem, [good] + bads, 0)


# ---------- Advanced Math ----------

def adv_expand(diff):
    p, q = rng.randint(1, 9), rng.randint(1, 9)
    stem = f"Which expression is equivalent to \\((x + {p})(x + {q})\\)?"
    s, prod = p + q, p * q
    choices = [
        f"\\(x^2 + {s}x + {prod}\\)",
        f"\\(x^2 + {prod}x + {s}\\)",
        f"\\(x^2 + {s}x + {prod + 1}\\)",
        f"\\(x^2 - {s}x + {prod}\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions: expand a product", diff, stem, choices, 0)


def adv_factor(diff):
    p, q = rng.randint(1, 8), rng.randint(1, 8)
    stem = f"Which expression is equivalent to \\(x^2 + {p + q}x + {p * q}\\)?"
    choices = [
        f"\\((x + {p})(x + {q})\\)",
        f"\\((x + {p + q})(x + {p * q})\\)",
        f"\\((x + {p})(x - {q})\\)",
        f"\\((x - {p})(x - {q})\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions: factor a trinomial", diff, stem, choices, 0)


def adv_diff_squares(diff):
    a = rng.randint(2, 15)
    stem = f"Which expression is equivalent to \\(x^2 - {a * a}\\)?"
    choices = [
        f"\\((x - {a})(x + {a})\\)",
        f"\\((x - {a})(x - {a})\\)",
        f"\\((x + {a * a})(x - 1)\\)",
        f"\\(x(x - {a})\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions: difference of squares", diff, stem, choices, 0)


def adv_product_powers(diff):
    m, n = rng.randint(2, 9), rng.randint(2, 8)
    stem = f"Which expression is equivalent to \\(x^{{{m}}} \\cdot x^{{{n}}}\\) for \\(x \\ne 0\\)?"
    choices = [f"\\(x^{{{m + n}}}\\)", f"\\(x^{{{m * n}}}\\)", f"\\(x^{{{abs(m - n)}}}\\)", f"\\({m * n}x\\)"]
    return emit_text_mc("Advanced Math", "Equivalent expressions: product of powers", diff, stem, choices, 0)


def adv_power_power(diff):
    m, n = rng.randint(2, 8), rng.randint(2, 6)
    stem = f"Which expression is equivalent to \\((x^{{{m}}})^{{{n}}}\\)?"
    choices = [f"\\(x^{{{m * n}}}\\)", f"\\(x^{{{m + n}}}\\)", f"\\(x^{{{m}}}\\)", f"\\({m * n}x\\)"]
    return emit_text_mc("Advanced Math", "Equivalent expressions: power of a power", diff, stem, choices, 0)


def adv_sum_roots(diff):
    r1, r2 = roots_pair()
    stem = f"What is the sum of the solutions of \\({quad_tex(r1 + r2, r1 * r2)} = 0\\)?"
    return emit("Advanced Math", "Nonlinear equations: sum of solutions", diff, stem, r1 + r2, [r1 * r2, r1, r2, abs(r1 - r2)])


def adv_product_roots(diff):
    r1, r2 = roots_pair()
    stem = f"What is the product of the solutions of \\({quad_tex(r1 + r2, r1 * r2)} = 0\\)?"
    return emit("Advanced Math", "Nonlinear equations: product of solutions", diff, stem, r1 * r2, [r1 + r2, r1, r2, abs(r1 - r2)])


def adv_greater_root(diff):
    r1, r2 = roots_pair()
    bigger = max(r1, r2)
    stem = f"What is the greater solution of \\({quad_tex(r1 + r2, r1 * r2)} = 0\\)?"
    return emit("Advanced Math", "Nonlinear equations: greater solution", diff, stem, bigger, [min(r1, r2), r1 + r2, r1 * r2, bigger + 1])


def adv_minimum(diff):
    h = rng.randint(1, 8)
    k = rng.randint(-6, 9)
    stem = (
        f"The function \\(f(x) = x^2 - {2 * h}x + {h * h + k}\\) is defined for all real \\(x\\). "
        f"What is the minimum value of \\(f\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions: minimum value", diff, stem, k, [h, h * h + k, -h, 2 * h])


def adv_vertex_x(diff):
    h = rng.randint(1, 9)
    k = rng.randint(-5, 8)
    stem = (
        f"The function \\(f(x) = x^2 - {2 * h}x + {h * h + k}\\) is defined for all real \\(x\\). "
        f"What is the \\(x\\)-coordinate of the vertex?"
    )
    return emit("Advanced Math", "Nonlinear functions: x-coordinate of the vertex", diff, stem, h, [k, -h, 2 * h, h * h + k])


def adv_how_many_roots(diff):
    kind = rng.choice(["two", "one", "none"])
    if kind == "two":
        r1, r2 = roots_pair()
        eq = quad_tex(r1 + r2, r1 * r2)
        n = 2
    elif kind == "one":
        r = rng.randint(-6, 8)
        eq = quad_tex(2 * r, r * r)
        n = 1
    else:
        b = rng.randint(0, 6)
        c = (b * b) // 4 + rng.randint(2, 8)
        eq = quad_tex(-b, c)
        n = 0
    stem = f"How many distinct real solutions does \\({eq} = 0\\) have?"
    choices = ["None", "Exactly one", "Exactly two", "Infinitely many"]
    return emit_text_mc("Advanced Math", "Nonlinear equations: how many real solutions", diff, stem, choices, n)


def adv_exp_value(diff):
    a = rng.randint(2, 9)
    b = rng.choice([2, 3, 4])
    t = rng.choice([2, 3, 4])
    stem = f"If \\(f(t) = {a}\\cdot {b}^{{t}}\\), what is the value of \\(f({t})\\)?"
    val = a * (b ** t)
    return emit("Advanced Math", "Nonlinear functions: evaluate an exponential", diff, stem, val, [a * b * t, a + b ** t, b ** t, a * b + t])


def adv_exp_initial(diff):
    b = rng.choice([2, 3, 4])
    a = rng.randint(3, 15)
    t = 2
    stem = (
        f"A quantity grows by the model \\(P(t) = a \\cdot {b}^{{t}}\\). "
        f"If \\(P({t}) = {a * (b ** t)}\\), what is the value of \\(a\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions: initial value of an exponential", diff, stem, a, [a * b, b ** t, a + b, a * t])


def adv_which_exp(diff):
    start = rng.choice([20, 40, 50, 80, 100])
    factor = rng.choice([2, 3, 4])
    stem = (
        f"A population starts at {start} and is multiplied by {factor} each year. "
        f"Which expression gives the population after \\(t\\) years?"
    )
    choices = [
        f"\\({start} \\cdot {factor}^{{t}}\\)",
        f"\\({start} \\cdot t^{{{factor}}}\\)",
        f"\\({start + factor}t\\)",
        f"\\({factor} \\cdot {start}^{{t}}\\)",
    ]
    return emit_text_mc("Advanced Math", "Nonlinear functions: choose the exponential model", diff, stem, choices, 0)


def adv_half_life(diff):
    start = rng.choice([80, 120, 160, 240, 320])
    t = rng.choice([2, 3])
    # start must be divisible by 2^t
    if start % (2 ** t) != 0:
        start = 160 if t == 2 else 240
    val = start // (2 ** t)
    stem = (
        f"A sample starts at {start} grams and is halved each year. "
        f"How many grams remain after {t} years?"
    )
    return emit("Advanced Math", "Nonlinear functions: half-life", diff, stem, val, [start // 2, start - t, start * t, val * 2])


def adv_f_of(diff):
    a = rng.randint(2, 6)
    b = rng.randint(-5, 8)
    x = rng.randint(-3, 8)
    stem = f"If \\(f(x) = {lin(a, b)}\\), what is the value of \\(f({x})\\)?"
    return emit("Advanced Math", "Nonlinear functions: evaluate f(x)", diff, stem, a * x + b, [a * x - b, a + b + x, a * (x + 1)])


def adv_compose(diff):
    a, b = rng.randint(2, 5), rng.randint(-4, 6)
    c, d = rng.randint(1, 4), rng.randint(-3, 5)
    x = rng.randint(-2, 5)
    val = a * (c * x + d) + b
    stem = f"If \\(f(x) = {lin(a, b)}\\) and \\(g(x) = {lin(c, d)}\\), what is the value of \\(f(g({x}))\\)?"
    return emit("Advanced Math", "Nonlinear functions: composition", diff, stem, val, [a * x + b + c * x + d, (a + c) * x + (b + d), a * c * x])


def adv_shift(diff):
    h = rng.randint(1, 4)
    t = rng.randint(h + 2, 9)
    fv = rng.randint(-5, 14)
    stem = (
        f"The function \\(g\\) is defined by \\(g(x) = f(x - {h})\\). "
        f"If \\(f({t - h}) = {fv}\\), what is the value of \\(g({t})\\)?"
    )
    return emit("Advanced Math", "Nonlinear functions: horizontal shift", diff, stem, fv, [fv + h, fv - h, t - h, fv + t])


def adv_radical(diff):
    b = rng.randint(2, 9)
    add = rng.randint(1, 12)
    x = b * b - add
    if x <= 0:
        add = 1
        x = b * b - 1
    stem = f"What is the solution of \\(\\sqrt{{x + {add}}} = {b}\\)?"
    return emit("Advanced Math", "Nonlinear equations: radical", diff, stem, x, [b + add, b * b + add, b * b, add])


def adv_rational(diff):
    c = rng.choice([2, 3, 4])
    b = rng.randint(1, 6)
    x = rng.randint(-4, 8)
    if x + b == 0:
        x += 1
    a = c * (x + b) - x
    if a >= 0:
        stem = f"What value of \\(x\\) satisfies \\(\\dfrac{{x + {a}}}{{x + {b}}} = {c}\\), given that the expression is defined?"
    else:
        stem = f"What value of \\(x\\) satisfies \\(\\dfrac{{x - {-a}}}{{x + {b}}} = {c}\\), given that the expression is defined?"
    return emit("Advanced Math", "Nonlinear equations: rational", diff, stem, x, [-b, c * (x + b), x + c, a])


def adv_intersect_x(diff):
    a = rng.randint(2, 16)
    stem = (
        f"The graphs of \\(y = x^2\\) and \\(y = {a}x\\) intersect at the origin and one other point. "
        f"What is the positive \\(x\\)-coordinate of that other point?"
    )
    return emit("Advanced Math", "Nonlinear systems: x-coordinate", diff, stem, a, [a * a, a + 1, Fraction(a, 2), 0])


def adv_intersect_y(diff):
    a = rng.randint(2, 12)
    stem = (
        f"The graphs of \\(y = x^2\\) and \\(y = {a}x\\) intersect at the origin and one other point. "
        f"What is the \\(y\\)-coordinate of that other point?"
    )
    return emit("Advanced Math", "Nonlinear systems: y-coordinate", diff, stem, a * a, [a, 2 * a, 0, a + a])


def adv_structure(diff):
    a = rng.randint(2, 6)
    b = rng.randint(2, 8)
    k = rng.randint(2, 5)
    stem = f"Which expression is equivalent to \\((x - {a})(x + {b}) - {k}(x - {a})\\)?"
    choices = [
        f"\\((x - {a})(x + {b - k})\\)",
        f"\\((x - {a})(x + {b + k})\\)",
        f"\\((x + {a})(x + {b - k})\\)",
        f"\\((x - {a})(x - {b - k})\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions: common binomial factor", diff, stem, choices, 0)


def adv_abs_sum(diff):
    a = rng.randint(2, 12)
    b = rng.randint(1, 9)
    stem = f"The equation \\(|x - {a}| = {b}\\) has two solutions. What is the sum of those solutions?"
    return emit("Advanced Math", "Nonlinear equations: absolute value, sum of solutions", diff, stem, 2 * a, [a, b, a + b, a - b])


def adv_factor_theorem(diff):
    r = rng.randint(2, 6)
    b = rng.randint(1, 8)
    c = -r * r - b * r
    stem = f"The polynomial \\(x^2 + {b}x + c\\) has \\((x - {r})\\) as a factor. What is the value of \\(c\\)?"
    return emit("Advanced Math", "Nonlinear equations: factor theorem", diff, stem, c, [r, b, -c, r + b])


def adv_perfect_square(diff):
    a = rng.randint(2, 14)
    stem = f"Which expression is equivalent to \\((x + {a})^2\\)?"
    choices = [
        f"\\(x^2 + {2 * a}x + {a * a}\\)",
        f"\\(x^2 + {a}x + {a * a}\\)",
        f"\\(x^2 + {2 * a}x + {a}\\)",
        f"\\(x^2 + {a * a}x + {2 * a}\\)",
    ]
    return emit_text_mc("Advanced Math", "Equivalent expressions: perfect square", diff, stem, choices, 0)


def adv_zero_meaning(diff):
    t = rng.randint(2, 12)
    stem = (
        f"The height of an object above the ground, in meters, is modeled by a function of time in seconds. "
        f"A positive zero of the function is {t}. Which statement must be true?"
    )
    choices = [
        f"The object is at height 0 at {t} seconds.",
        f"The object's maximum height is {t} meters.",
        f"The object was launched from a height of {t} meters.",
        f"The object rises for {t} seconds and then falls for {t} seconds.",
    ]
    return emit_text_mc("Advanced Math", "Nonlinear functions: meaning of a zero", diff, stem, choices, 0)


# ---------- PSDA ----------

def ps_ratio(diff):
    a = rng.choice([2, 3, 4, 5])
    b = rng.choice([2, 3, 5, 6])
    mult = rng.choice([2, 3, 4, 5, 6])
    part = a * mult
    whole = (a + b) * mult
    stem = (
        f"The ratio of red marbles to blue marbles in a bag is \\({a}:{b}\\). "
        f"There are \\({part}\\) red marbles. How many marbles are in the bag?"
    )
    return emit("Problem-Solving and Data Analysis", "Ratios: part to whole", diff, stem, whole, [part + b, a * b, part * b, a + b])


def ps_speed(diff):
    hours = rng.choice([2, 3, 4, 5])
    rate = rng.randint(40, 75)
    stem = f"A train travels \\({rate * hours}\\) miles in \\({hours}\\) hours at a constant speed. What is the speed in miles per hour?"
    return emit("Problem-Solving and Data Analysis", "Rates: distance and time", diff, stem, rate, [rate * hours, hours, rate + hours, rate - hours])


def ps_map(diff):
    m = rng.choice([2, 3, 4, 5, 8])
    d = rng.randint(3, 12)
    stem = (
        f"On a map, 1 centimeter represents {m} kilometers. "
        f"A road measures {d} centimeters on the map. What is the actual length of the road, in kilometers?"
    )
    return emit("Problem-Solving and Data Analysis", "Rates: scale", diff, stem, d * m, [d + m, d, m, d * m + 1])


def ps_recipe(diff):
    # base serves s people and uses u cups. Ask cups for p people. p/s * u integer.
    s = rng.choice([4, 6, 8])
    u = rng.choice([2, 3, 4, 6])
    k = rng.choice([2, 3])
    p = s * k
    cups = u * k
    stem = (
        f"A recipe that serves {s} people uses {u} cups of rice. "
        f"How many cups of rice are needed to serve {p} people at the same rate?"
    )
    return emit("Problem-Solving and Data Analysis", "Proportions: scale a recipe", diff, stem, cups, [u, p, u + k, cups + u])


def ps_discount(diff):
    price = rng.choice([40, 60, 80, 100, 120, 200])
    pct = rng.choice([10, 15, 20, 25, 30])
    if (price * pct) % 100 != 0:
        price, pct = 80, 25
    sale = price * (100 - pct) // 100
    stem = f"A jacket costs \\${price}. During a sale the price is reduced by {pct}\\%. What is the sale price, in dollars?"
    return emit("Problem-Solving and Data Analysis", "Percentages: discount", diff, stem, sale, [price - pct, price * pct // 100, price + pct, pct])


def ps_increase(diff):
    price = rng.choice([40, 60, 80, 100, 120])
    pct = rng.choice([10, 15, 20, 25])
    if (price * pct) % 100 != 0:
        price, pct = 80, 25
    new = price * (100 + pct) // 100
    stem = f"A fee of \\${price} increases by {pct}\\%. What is the new fee, in dollars?"
    return emit("Problem-Solving and Data Analysis", "Percentages: increase", diff, stem, new, [price + pct, price - pct, price * pct // 100, pct])


def ps_discount_tax(diff):
    price = pct = tax = None
    for _ in range(30):
        price = rng.choice([40, 50, 60, 80, 100, 120, 160, 200])
        pct = rng.choice([10, 20, 25, 40, 50])
        tax = rng.choice([5, 8, 10, 20])
        if price * (100 - pct) * (100 + tax) % 10000 == 0:
            break
    else:
        price, pct, tax = 100, 20, 10
    final = price * (100 - pct) * (100 + tax) // 10000
    sale = price * (100 - pct) // 100
    stem = (
        f"A bike is listed at \\${price}. It is discounted by {pct}\\%, and then a {tax}\\% sales tax "
        f"is added to the discounted price. What is the final price, in dollars?"
    )
    return emit("Problem-Solving and Data Analysis", "Percentages: discount then tax", diff, stem, final, [sale, price - pct, sale + tax, price])


def ps_mean(diff):
    n = 5
    nums = [rng.randint(4, 18) for _ in range(n - 1)]
    target = rng.randint(8, 16)
    m = target * n - sum(nums)
    if m <= 0 or m > 40:
        nums = [8, 10, 12, 9]
        m = target * n - sum(nums)
    listed = ", ".join(str(v) for v in nums)
    stem = f"The mean of the numbers {listed}, and \\(x\\) is \\({target}\\). What is the value of \\(x\\)?"
    return emit("Problem-Solving and Data Analysis", "One-variable data: mean", diff, stem, m, [target, sum(nums) // 4, m + 2, target * 2])


def ps_median(diff):
    base = sorted(rng.sample(range(2, 30), 4))
    mid = rng.randint(base[1], base[2])
    data = sorted([base[0], base[1], mid, base[2], base[3]])
    listed = ", ".join(str(v) for v in data)
    stem = f"What is the median of the data set {listed}?"
    return emit("Problem-Solving and Data Analysis", "One-variable data: median", diff, stem, data[2], [data[0], data[-1], data[1], sum(data) // 5])


def ps_range(diff):
    data = sorted(rng.sample(range(2, 40), 5))
    listed = ", ".join(str(v) for v in data)
    span = data[-1] - data[0]
    stem = f"What is the range of the data set {listed}?"
    return emit("Problem-Solving and Data Analysis", "One-variable data: range", diff, stem, span, [data[-1], data[0], data[2], span + 1])


def ps_prob(diff):
    red, blue, green = rng.randint(3, 9), rng.randint(2, 8), rng.randint(1, 6)
    total = red + blue + green
    stem = (
        f"A bag has {red} red, {blue} blue, and {green} green counters. "
        f"One counter is drawn at random. What is the probability that it is red?"
    )
    ans = Fraction(red, total)
    return emit("Problem-Solving and Data Analysis", "Probability: one draw", diff, stem, ans, [Fraction(blue, total), Fraction(red, blue), Fraction(1, 3)])


def ps_conditional(diff):
    red, blue, green = rng.randint(3, 9), rng.randint(2, 8), rng.randint(1, 6)
    total = red + blue + green
    stem = (
        f"A bag has {red} red, {blue} blue, and {green} green counters. "
        f"One counter is drawn at random. Given that it is not green, what is the probability that it is red?"
    )
    ans = Fraction(red, red + blue)
    return emit("Problem-Solving and Data Analysis", "Probability: conditional", diff, stem, ans, [Fraction(red, total), Fraction(blue, red + blue), Fraction(green, total)])


def ps_complement(diff):
    num = rng.randint(1, 4)
    den = rng.choice([5, 6, 8, 10])
    if num >= den:
        num = 1
    stem = (
        f"The probability that a randomly selected marble is red is \\({num}/{den}\\). "
        f"What is the probability that it is not red?"
    )
    return emit("Problem-Solving and Data Analysis", "Probability: complement", diff, stem, Fraction(den - num, den), [Fraction(num, den), Fraction(1, den), Fraction(num, den - num)])


def ps_twoway(diff):
    a, b = rng.randint(8, 18), rng.randint(6, 16)
    c, d = rng.randint(5, 14), rng.randint(7, 16)
    stem = (
        f"Among juniors, {a} joined and {b} did not. Among seniors, {c} joined and {d} did not. "
        f"A student is chosen at random from those who joined the club. What is the probability that the student is a junior?"
    )
    return emit("Problem-Solving and Data Analysis", "Probability: two-way table", diff, stem, Fraction(a, a + c), [Fraction(a, a + b), Fraction(a, a + b + c + d), Fraction(c, a + c)])


def ps_predict(diff):
    m = rng.choice([2, 3, 4, 5, -2, -3])
    b = rng.randint(1, 12)
    x = rng.randint(3, 9)
    y = m * x + b
    stem = (
        f"A line of best fit for a data set is \\(y = {lin(m, b)}\\), "
        f"where \\(x\\) is the number of hours studied and \\(y\\) is the predicted score. "
        f"According to the model, what is the predicted score when \\(x = {x}\\)?"
    )
    return emit("Problem-Solving and Data Analysis", "Two-variable data: predict from a model", diff, stem, y, [m * x - b, b, m * x, m + x])


def ps_slope_meaning(diff):
    m = rng.choice([2, 3, 4, 5])
    b = rng.randint(10, 40)
    stem = (
        f"A line of best fit is \\(y = {m}x + {b}\\), where \\(x\\) is hours studied and \\(y\\) is the predicted score. "
        f"What does {m} represent?"
    )
    choices = [
        f"The predicted score increases by {m} points for each additional hour studied",
        f"The predicted score decreases by {m} points for each additional hour studied",
        f"A student who studies 0 hours is predicted to score {m}",
        f"The highest score in the data set is {m}",
    ]
    return emit_text_mc("Problem-Solving and Data Analysis", "Two-variable data: meaning of the slope", diff, stem, choices, 0)


def ps_margin(diff):
    n = rng.choice([400, 600, 800, 900, 1200])
    p = rng.choice([48, 52, 54, 57, 61, 63])
    m = rng.choice([3, 4, 5])
    stem = (
        f"In a random sample of {n} voters, {p}\\% supported a proposal. "
        f"The margin of error for this estimate is {m} percentage points. Which conclusion is best supported?"
    )
    choices = [
        f"It is plausible that between {p - m}\\% and {p + m}\\% of all voters support the proposal.",
        f"Exactly {p}\\% of all voters support the proposal.",
        f"The margin of error would stay {m} percentage points if the sample size were much smaller.",
        "The result proves that the proposal will pass.",
    ]
    return emit_text_mc("Problem-Solving and Data Analysis", "Inference: margin of error", diff, stem, choices, 0)


def ps_cause(diff):
    bank = [
        (
            "A researcher wants to know whether a new homework format causes higher quiz scores at one school. Which design best supports a cause-and-effect conclusion?",
            "Randomly assign students at the school to the new format or the current format, then compare quiz scores.",
            [
                "Ask volunteers to try the new format and compare them with students who kept the old format.",
                "Survey a random sample of students about which format they prefer.",
                "Compare this year's quiz scores with last year's after the school changes the format for everyone.",
            ],
        ),
        (
            "A coach wants to test whether a new warm-up causes faster sprint times. Which design best supports a cause-and-effect conclusion?",
            "Randomly assign athletes to the new warm-up or the usual warm-up, then compare sprint times.",
            [
                "Let the fastest athletes choose the new warm-up and compare them with the others.",
                "Survey athletes about which warm-up they like.",
                "Use the new warm-up for the whole team and compare this season with last season.",
            ],
        ),
        (
            "A school claims that students who join the chess club have higher math grades, so the club causes the higher grades. Why is that claim not well supported?",
            "Students who choose the club may already differ from students who do not.",
            [
                "The school did not report the margin of error of a poll.",
                "A mean cannot be computed from letter grades.",
                "Observational results are never allowed to include numbers.",
            ],
        ),
        (
            "To estimate the proportion of all students at a college who live on campus, which method is most appropriate?",
            "Take a random sample of students from the college and record whether each lives on campus.",
            [
                "Ask only the students in one dormitory.",
                "Assign a random half of the college to move on campus.",
                "Survey students at a different college.",
            ],
        ),
        (
            "Researchers randomly select classrooms, then randomly assign those classrooms to a new reading program or the current program. The random assignment is useful mainly because it helps",
            "support a conclusion about the effect of the program.",
            [
                "remove the need to record any scores.",
                "guarantee that every student in the country is represented.",
                "make the margin of error equal to zero.",
            ],
        ),
        (
            "A garden club says members have healthier plants than nonmembers, so membership causes healthier plants. Why is that claim not well supported?",
            "People who choose to join may already garden differently from people who do not.",
            [
                "A percent cannot be computed from a plant.",
                "The club did not name the margin of error.",
                "An experiment is never allowed to use a control group.",
            ],
        ),
    ]
    stem, good, bads = bank[rng.randrange(len(bank))]
    return emit_text_mc("Problem-Solving and Data Analysis", "Statistical claims: experiment or observation", diff, stem, [good] + bads, 0)


def ps_sample_size(diff):
    bank = [
        (
            "A poll uses a random sample of city residents. Which change would be expected to reduce the margin of error?",
            ["Increase the sample size.", "Ask the question in a different order only.", "Replace the random sample with volunteers.", "Report the result as a fraction instead of a percent."],
        ),
        (
            "A school surveys a random sample of students about a new schedule. Which change would be expected to reduce the margin of error?",
            ["Survey a larger random sample.", "Ask only the students who already like the schedule.", "Change the font on the questionnaire.", "Report the result in words instead of numbers."],
        ),
        (
            "A city estimates the percent of households with a garden from a random sample. Which change would be expected to reduce the margin of error?",
            ["Increase the number of households in the random sample.", "Replace the random sample with people who call in.", "Ask the question twice to the same households and average the words.", "Round the percent to the nearest ten."],
        ),
        (
            "A researcher estimates a population percent from a random sample. Which change would be expected to reduce the margin of error?",
            ["Use a larger random sample from the same population.", "Use a smaller random sample.", "Switch from a random sample to a convenience sample.", "Leave the sample size the same and drop the percent sign."],
        ),
    ]
    stem, choices = bank[rng.randrange(len(bank))]
    return emit_text_mc("Problem-Solving and Data Analysis", "Inference: what shrinks a margin of error", diff, stem, choices, 0)


def ps_per_hour(diff):
    n = rng.randint(2, 15)
    stem = f"A printer produces {n} pages each minute at a constant rate. How many pages does it produce in one hour?"
    return emit("Problem-Solving and Data Analysis", "Units: per minute to per hour", diff, stem, n * 60, [n, 60, n + 60, n * 30])


# ---------- Geometry ----------

def geo_third(diff):
    a = rng.randint(30, 80)
    b = rng.randint(25, 70)
    c = 180 - a - b
    if c < 20 or c > 120:
        a, b, c = 50, 60, 70
    stem = f"Two angles of a triangle measure \\({a}^\\circ\\) and \\({b}^\\circ\\). What is the measure, in degrees, of the third angle?"
    return emit("Geometry and Trigonometry", "Triangles: third angle", diff, stem, c, [a + b, 360 - a - b, 90, a])


def geo_consecutive(diff):
    a = rng.randint(35, 145)
    if a == 90:
        a = 96
    stem = (
        f"Two parallel lines are cut by a transversal. One interior angle measures \\({a}^\\circ\\). "
        f"What is the measure, in degrees, of the consecutive interior angle on the same side of the transversal?"
    )
    return emit("Geometry and Trigonometry", "Parallel lines: consecutive interior angle", diff, stem, 180 - a, [a, 90, 360 - a, abs(a - 90)])


def geo_alternate(diff):
    a = rng.randint(32, 150)
    stem = (
        f"Two parallel lines are cut by a transversal. One angle measures \\({a}^\\circ\\). "
        f"What is the measure, in degrees, of the alternate interior angle?"
    )
    return emit("Geometry and Trigonometry", "Parallel lines: alternate interior angle", diff, stem, a, [180 - a, 90, 360 - a, a + 2])


def geo_corresponding(diff):
    a = rng.randint(28, 152)
    stem = (
        f"Two parallel lines are cut by a transversal. One angle measures \\({a}^\\circ\\). "
        f"What is the measure, in degrees, of the corresponding angle?"
    )
    return emit("Geometry and Trigonometry", "Parallel lines: corresponding angle", diff, stem, a, [180 - a, 90, 360 - a, a // 2])


def geo_vertical(diff):
    a = rng.randint(20, 160)
    stem = f"Two lines intersect and form a {a}\\(^\\circ\\) angle. What is the measure, in degrees, of the vertical angle?"
    return emit("Geometry and Trigonometry", "Angles: vertical angles", diff, stem, a, [180 - a, 90, 360 - a, a // 2 if a % 2 == 0 else a - 1])


def geo_leg(diff):
    triples = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (9, 12, 15), (6, 8, 10), (9, 40, 41), (12, 16, 20), (12, 35, 37), (20, 21, 29)]
    a, b, c = triples[rng.randrange(len(triples))]
    stem = f"A right triangle has a hypotenuse of length {c} and one leg of length {a}. What is the length of the other leg?"
    return emit("Geometry and Trigonometry", "Right triangles: missing leg", diff, stem, b, [c - a, a + c, c, a])


def geo_hyp(diff):
    triples = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (6, 8, 10), (9, 12, 15), (20, 21, 29)]
    a, b, c = triples[rng.randrange(len(triples))]
    stem = f"A right triangle has legs of length {a} and {b}. What is the length of the hypotenuse?"
    return emit("Geometry and Trigonometry", "Right triangles: hypotenuse", diff, stem, c, [a + b, abs(b - a), a * b, c + 1])


def geo_45(diff):
    k = rng.randint(2, 18)
    stem = f"An isosceles right triangle has a hypotenuse of length \\({k}\\sqrt{{2}}\\). What is the length of each leg?"
    return emit("Geometry and Trigonometry", "Special right triangles: 45-45-90", diff, stem, k, [2 * k, k * k, Fraction(k, 2), k + 2])


def geo_30(diff):
    k = rng.randint(2, 18)
    stem = (
        f"In a \\(30^\\circ\\)-\\(60^\\circ\\)-\\(90^\\circ\\) triangle, the side opposite the \\(30^\\circ\\) angle has length {k}. "
        f"What is the length of the hypotenuse?"
    )
    return emit("Geometry and Trigonometry", "Special right triangles: 30-60-90", diff, stem, 2 * k, [k, 3 * k, k * k, 60])


def geo_rect(diff):
    L, W = rng.randint(4, 15), rng.randint(3, 12)
    stem = f"A rectangle has length {L} and width {W}. What is its area?"
    return emit("Geometry and Trigonometry", "Area: rectangle", diff, stem, L * W, [2 * (L + W), L + W, 2 * L * W, L * W + 2])


def geo_tri(diff):
    b = rng.randint(4, 16)
    h = rng.choice([4, 6, 8, 10, 12])
    stem = f"A triangle has a base of length {b} and a corresponding height of {h}. What is the area of the triangle?"
    return emit("Geometry and Trigonometry", "Area: triangle", diff, stem, Fraction(b * h, 2), [b * h, b + h, Fraction(b * h, 4), 2 * b * h])


def geo_prism(diff):
    L, W, H = rng.randint(3, 10), rng.randint(3, 8), rng.randint(2, 9)
    stem = f"A rectangular prism has length {L}, width {W}, and height {H}. What is the volume of the prism?"
    return emit("Geometry and Trigonometry", "Volume: rectangular prism", diff, stem, L * W * H, [L + W + H, L * W, L * H, 2 * (L + W + H)])


def geo_cylinder(diff):
    r = rng.choice([2, 3, 4, 5, 6])
    h = rng.randint(4, 12)
    stem = f"A right circular cylinder has radius {r} and height {h}. The volume is \\(k\\pi\\). What is the value of \\(k\\)?"
    return emit("Geometry and Trigonometry", "Volume: cylinder, coefficient of pi", diff, stem, r * r * h, [2 * r * h, r * h, r * r + h, 2 * r * r * h])


def geo_circ(diff):
    r = rng.randint(3, 14)
    stem = f"A circle has radius {r}. The circumference is \\(k\\pi\\). What is the value of \\(k\\)?"
    return emit("Geometry and Trigonometry", "Circles: circumference coefficient", diff, stem, 2 * r, [r, r * r, r + 2, 2 * r * r])


def geo_radius(diff):
    h, k = rng.randint(1, 6), rng.randint(1, 6)
    r = rng.choice([2, 3, 4, 5, 6, 7])
    stem = f"What is the radius of the circle with equation \\((x - {h})^2 + (y - {k})^2 = {r * r}\\)?"
    return emit("Geometry and Trigonometry", "Circles: radius from the equation", diff, stem, r, [r * r, 2 * r, h, k])


def geo_complete(diff):
    h = rng.choice([2, 3, 4, 5])
    k = rng.choice([1, 2, 3, 4])
    r = rng.choice([3, 4, 5, 6])
    right = r * r - h * h - k * k
    stem = f"What is the radius of the circle with equation \\(x^2 - {2 * h}x + y^2 + {2 * k}y = {right}\\)?"
    return emit("Geometry and Trigonometry", "Circles: complete the square", diff, stem, r, [r * r, h, k, 2 * r])


def geo_similar(diff):
    k = rng.choice([2, 3, 4])
    a = rng.randint(3, 8)
    b = a + rng.randint(2, 6)
    stem = (
        f"Two triangles are similar. A pair of corresponding sides measure {a} and {a * k}. "
        f"Another side of the smaller triangle measures {b}. "
        f"What is the length of the corresponding side of the larger triangle?"
    )
    return emit("Geometry and Trigonometry", "Triangles: similarity scale", diff, stem, b * k, [b + k, a * b, Fraction(b, k), b * k + a])


def geo_trig(diff):
    triples = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (6, 8, 10), (9, 12, 15), (20, 21, 29), (12, 16, 20)]
    a, b, c = triples[rng.randrange(len(triples))]
    which = rng.choice(["sin", "cos", "tan"])
    name = {"sin": "\\sin", "cos": "\\cos", "tan": "\\tan"}[which]
    stem = (
        f"In a right triangle, the side opposite angle \\(A\\) has length {a}, "
        f"the side adjacent to angle \\(A\\) has length {b}, and the hypotenuse has length {c}. "
        f"What is the value of \\({name} A\\)?"
    )
    ans = {"sin": Fraction(a, c), "cos": Fraction(b, c), "tan": Fraction(a, b)}[which]
    return emit("Geometry and Trigonometry", "Right-triangle trigonometry", diff, stem, ans, [Fraction(b, c), Fraction(a, b), Fraction(b, a), Fraction(c, a)])


def geo_arc(diff):
    r = rng.choice([6, 9, 12])
    deg = rng.choice([60, 90, 120])
    k = Fraction(deg, 180) * r
    stem = (
        f"A circle has radius {r}. What is the length of a {deg}\\(^\\circ\\) arc of the circle, "
        f"expressed as \\(k\\pi\\)? Enter the value of \\(k\\)."
    )
    return emit("Geometry and Trigonometry", "Circles: arc length coefficient", diff, stem, k, [Fraction(deg, 360), r, Fraction(deg * r, 360), 2 * r])


def geo_inscribed(diff):
    central = rng.choice([40, 50, 60, 70, 80, 100, 120, 140])
    stem = (
        f"A central angle measures {central} degrees and intercepts an arc. "
        f"An inscribed angle intercepts the same arc. What is the measure, in degrees, of the inscribed angle?"
    )
    return emit("Geometry and Trigonometry", "Circles: inscribed angle", diff, stem, central // 2, [central, 2 * central, 180 - central, 90])


def geo_scale_volume(diff):
    k = rng.choice([2, 3])
    v = rng.choice([5, 6, 8, 10, 12])
    stem = (
        f"Every length of a rectangular prism is multiplied by {k}. The original volume is {v}. "
        f"What is the volume of the new prism?"
    )
    return emit("Geometry and Trigonometry", "Volume: scale factor", diff, stem, v * k * k * k, [v * k, v + k, v * k * k, k * k * k])


def geo_cofunction(diff):
    num, den = rng.choice([(3, 5), (5, 13), (8, 17), (7, 25), (4, 5), (9, 41)])
    stem = (
        f"In a right triangle, \\(\\sin A = {num}/{den}\\). "
        f"Angle \\(B\\) is the other acute angle. What is \\(\\cos B\\)?"
    )
    return emit("Geometry and Trigonometry", "Trigonometry: cofunction of the other acute angle", diff, stem, Fraction(num, den), [Fraction(den - num, den), Fraction(den, num), Fraction(num, den - num), Fraction(1, den)])


PLAN = [
    (alg_one_step, "Easy", 16),
    (alg_both_sides, "Medium", 16),
    (alg_distribute, "Hard", 16),
    (alg_equation_count, "Medium", 20),
    (alg_slope_points, "Easy", 20),
    (alg_point_on_line, "Medium", 14),
    (alg_parallel, "Medium", 12),
    (alg_perpendicular, "Hard", 14),
    (alg_meaning_slope, "Medium", 16),
    (alg_meaning_intercept, "Medium", 14),
    (alg_which_model, "Easy", 16),
    (alg_inequality, "Easy", 14),
    (alg_inequality_flip, "Hard", 12),
    (alg_half_plane, "Medium", 12),
    (alg_system_add, "Easy", 14),
    (alg_system_x, "Medium", 16),
    (alg_system_sum, "Hard", 14),
    (alg_tickets, "Medium", 14),
    (alg_system_count, "Medium", 12),
    (alg_table, "Medium", 14),
    (alg_speed, "Easy", 14),
    (alg_perimeter, "Easy", 12),
    (alg_budget, "Medium", 12),
    (alg_parallel_intercept, "Hard", 12),
    (alg_sign_of_line, "Easy", 4),
    (adv_expand, "Easy", 18),
    (adv_factor, "Medium", 18),
    (adv_diff_squares, "Medium", 12),
    (adv_product_powers, "Easy", 12),
    (adv_power_power, "Medium", 12),
    (adv_sum_roots, "Easy", 18),
    (adv_product_roots, "Medium", 12),
    (adv_greater_root, "Medium", 14),
    (adv_minimum, "Hard", 14),
    (adv_vertex_x, "Medium", 12),
    (adv_how_many_roots, "Medium", 14),
    (adv_exp_value, "Easy", 14),
    (adv_exp_initial, "Hard", 12),
    (adv_which_exp, "Medium", 12),
    (adv_half_life, "Medium", 8),
    (adv_f_of, "Easy", 14),
    (adv_compose, "Medium", 14),
    (adv_shift, "Hard", 12),
    (adv_radical, "Medium", 14),
    (adv_rational, "Hard", 14),
    (adv_intersect_x, "Medium", 12),
    (adv_intersect_y, "Hard", 10),
    (adv_structure, "Hard", 12),
    (adv_abs_sum, "Medium", 14),
    (adv_factor_theorem, "Hard", 12),
    (adv_perfect_square, "Easy", 10),
    (adv_zero_meaning, "Medium", 10),
    (ps_ratio, "Easy", 10),
    (ps_speed, "Easy", 8),
    (ps_map, "Medium", 8),
    (ps_recipe, "Medium", 8),
    (ps_discount, "Easy", 10),
    (ps_increase, "Medium", 8),
    (ps_discount_tax, "Hard", 8),
    (ps_mean, "Easy", 8),
    (ps_median, "Easy", 8),
    (ps_range, "Medium", 6),
    (ps_prob, "Easy", 8),
    (ps_conditional, "Hard", 6),
    (ps_complement, "Medium", 6),
    (ps_twoway, "Medium", 8),
    (ps_predict, "Medium", 8),
    (ps_slope_meaning, "Medium", 6),
    (ps_margin, "Medium", 8),
    (ps_cause, "Hard", 6),
    (ps_sample_size, "Easy", 4),
    (ps_per_hour, "Easy", 8),
    (geo_third, "Easy", 10),
    (geo_consecutive, "Medium", 8),
    (geo_alternate, "Medium", 6),
    (geo_corresponding, "Easy", 4),
    (geo_vertical, "Easy", 4),
    (geo_leg, "Medium", 8),
    (geo_hyp, "Hard", 6),
    (geo_45, "Medium", 8),
    (geo_30, "Medium", 6),
    (geo_rect, "Easy", 6),
    (geo_tri, "Easy", 8),
    (geo_prism, "Easy", 8),
    (geo_cylinder, "Hard", 6),
    (geo_circ, "Easy", 6),
    (geo_radius, "Medium", 8),
    (geo_complete, "Hard", 6),
    (geo_similar, "Medium", 8),
    (geo_trig, "Medium", 8),
    (geo_arc, "Medium", 8),
    (geo_inscribed, "Hard", 6),
    (geo_scale_volume, "Hard", 6),
    (geo_cofunction, "Hard", 6),
]


def generate_items():
    from collections import Counter
    assert sum(n for _, _, n in PLAN) == 1000, sum(n for _, _, n in PLAN)
    items = []
    seen = set()
    for fn, diff, count in PLAN:
        made = 0
        tries = 0
        while made < count:
            tries += 1
            if tries > count * 60:
                raise RuntimeError(f"could not fill {fn.__name__} {diff}: {made}/{count}")
            item = fn(diff)
            if item.stem in seen:
                continue
            if item.kind == "MC" and (len(item.choices) != 4 or len(set(item.choices)) != 4):
                continue
            if item.kind == "SPR" and len(item.key) > 6:
                continue
            seen.add(item.stem)
            items.append(item)
            made += 1
    domains = Counter(it.domain for it in items)
    assert domains["Algebra"] == 350, domains
    assert domains["Advanced Math"] == 350, domains
    assert domains["Problem-Solving and Data Analysis"] == 150, domains
    assert domains["Geometry and Trigonometry"] == 150, domains
    families = {it.skill for it in items}
    if len(families) < 70:
        raise RuntimeError(f"only {len(families)} families")
    return items
